import {Component} from '@angular/core';
import {Attribute, Flows, Globals, List, Procedure} from '@innowake/gen';
import {BusinessSystemDefaults} from '../business-system-defaults';
import * as Entities from '../../../entities';

@Component({
    selector: 'app-cmChildSupportEnfMenu',
    templateUrl: './cmChildSupportEnfMenu.component.html',
    styleUrls: ['../cmCaseManagement.css', './cmChildSupportEnfMenu.component.css'],
})
export class CmChildSupportEnfMenuComponent implements Procedure.Proxy {

    globals = new Globals();

    readonly pfLocalKeys: Procedure.KeyMapping = {
        'F9': { 'value': 'INVALID', 'displayOnPFKeyLine': false },
        'F13': { 'value': 'INVALID', 'displayOnPFKeyLine': false },
        'F7': { 'value': 'INVALID', 'displayOnPFKeyLine': false },
        'F12': { 'value': 'INVALID', 'displayOnPFKeyLine': false },
        'F21': { 'value': 'INVALID', 'displayOnPFKeyLine': false },
        'F3': { 'value': 'EXIT', 'displayOnPFKeyLine': false },
        'F19': { 'value': 'INVALID', 'displayOnPFKeyLine': false },
        'F4': { 'value': 'INVALID', 'displayOnPFKeyLine': false },
        'F20': { 'value': 'INVALID', 'displayOnPFKeyLine': false },
        'Enter': { 'value': 'ENTER', 'displayOnPFKeyLine': false },
        'F8': { 'value': 'INVALID', 'displayOnPFKeyLine': false },
        'F1': { 'value': 'HELP', 'displayOnPFKeyLine': false },
        'F5': { 'value': 'INVALID', 'displayOnPFKeyLine': false },
        'F24': { 'value': 'INVALID', 'displayOnPFKeyLine': false },
        'F23': { 'value': 'INVALID', 'displayOnPFKeyLine': false },
        'F22': { 'value': 'INVALID', 'displayOnPFKeyLine': false },
        'F18': { 'value': 'INVALID', 'displayOnPFKeyLine': false },
        'F17': { 'value': 'INVALID', 'displayOnPFKeyLine': false },
        'F16': { 'value': 'INVALID', 'displayOnPFKeyLine': false },
        'F15': { 'value': 'INVALID', 'displayOnPFKeyLine': false },
        'F14': { 'value': 'INVALID', 'displayOnPFKeyLine': false },
        'F11': { 'value': 'INVALID', 'displayOnPFKeyLine': false },
        'F10': { 'value': 'INVALID', 'displayOnPFKeyLine': false },
        'F6': { 'value': 'INVALID', 'displayOnPFKeyLine': false },
        'F2': { 'value': 'INVALID', 'displayOnPFKeyLine': false }
    };

    readonly businessSystemDefaults = BusinessSystemDefaults;

    imports = {
        inputAa0014Menu: {
            selection: Attribute.optional(Entities.Aa0014Menu.Selection)
        },

        inputFastpath: {
            fastpathCommand: Attribute.optional(Entities.Fastpath.FastpathCommand)
        },

        inputMember: {
            identifier1: Attribute.optional(Entities.Member.Identifier1)
        },

        inputDocket: {
            identifier1: Attribute.optional(Entities.Docket.Identifier1)
        },

        inputCase1: {
            identifier1: Attribute.optional(Entities.Case1.Identifier1)
        }
    };

    exports = {
        outputAa0014Menu: {
            selection: Attribute.view(Entities.Aa0014Menu.Selection)
        },

        outputFastpath: {
            fastpathCommand: Attribute.view(Entities.Fastpath.FastpathCommand)
        },

        outputMember: {
            identifier1: Attribute.view(Entities.Member.Identifier1)
        },

        outputDocket: {
            identifier1: Attribute.view(Entities.Docket.Identifier1)
        },

        outputCase1: {
            identifier1: Attribute.view(Entities.Case1.Identifier1)
        }
    };

    readonly flows: Flows = [
        {
            toScreenId: 'CiInterstateMenu',
            type: 'link',
            flowsOn: [
                {exitState: 'CmCaseManagement.CM645_L_INTERSTATE', autoFlow: ''}
            ],
            executeFirst: true,
            mapping: (from, to) => {
                Procedure.copyAttributes(from.exports.outputMember, to.imports.inputMember);
                Procedure.copyAttributes(from.exports.outputDocket, to.imports.inputDocket);
                Procedure.copyAttributes(from.exports.outputCase1, to.imports.inputCase1);
                to.globals.command = 'FIRSTIME'; 
            },
            returnsOn: [
                {exitState: 'AaAdsCommonObjects.AA740_R_RETURN', autoFlow: 'EXIT'}
            ],
            onReturnExecuteFirst: true,
            returnMapping: (from, to) => {
                Procedure.copyAttributes(from.exports.outputMember, to.imports.inputMember);
                Procedure.copyAttributes(from.exports.outputDocket, to.imports.inputDocket);
                Procedure.copyAttributes(from.exports.outputCase1, to.imports.inputCase1);
                to.globals.command = 'FIRSTIME'; 
            }
        },
        {
            toScreenId: 'AdFinancialMgmtMenu',
            type: 'link',
            flowsOn: [
                {exitState: 'CmCaseManagement.CM629_L_FINANCIAL', autoFlow: ''}
            ],
            executeFirst: true,
            mapping: (from, to) => {
                Procedure.copyAttributes(from.exports.outputMember, to.imports.inputMember);
                Procedure.copyAttributes(from.exports.outputDocket, to.imports.inputDocket);
                Procedure.copyAttributes(from.exports.outputCase1, to.imports.inputCase1);
                to.globals.command = 'FIRSTIME'; 
            },
            returnsOn: [
                {exitState: 'AaAdsCommonObjects.AA740_R_RETURN', autoFlow: 'EXIT'}
            ],
            onReturnExecuteFirst: true,
            returnMapping: (from, to) => {
                Procedure.copyAttributes(from.exports.outputMember, to.imports.inputMember);
                Procedure.copyAttributes(from.exports.outputDocket, to.imports.inputDocket);
                Procedure.copyAttributes(from.exports.outputCase1, to.imports.inputCase1);
                to.globals.command = 'FIRSTIME'; 
            }
        },
        {
            toScreenId: 'CiCaseInitAndUpdateMenu',
            type: 'link',
            flowsOn: [
                {exitState: 'CmCaseManagement.CM609_L_CASE_INITIATION_AND_UPDT', autoFlow: ''}
            ],
            executeFirst: true,
            mapping: (from, to) => {
                Procedure.copyAttributes(from.exports.outputMember, to.imports.inputMember);
                Procedure.copyAttributes(from.exports.outputDocket, to.imports.inputDocket);
                Procedure.copyAttributes(from.exports.outputCase1, to.imports.inputCase1);
                to.globals.command = 'FIRSTIME'; 
            },
            returnsOn: [
                {exitState: 'AaAdsCommonObjects.AA740_R_RETURN', autoFlow: 'EXIT'}
            ],
            onReturnExecuteFirst: true,
            returnMapping: (from, to) => {
                Procedure.copyAttributes(from.exports.outputMember, to.imports.inputMember);
                Procedure.copyAttributes(from.exports.outputDocket, to.imports.inputDocket);
                Procedure.copyAttributes(from.exports.outputCase1, to.imports.inputCase1);
                to.globals.command = 'FIRSTIME'; 
            }
        },
        {
            toScreenId: 'CiLocateMenu',
            type: 'link',
            flowsOn: [
                {exitState: 'CmCaseManagement.CM654_L_LOCATE', autoFlow: ''}
            ],
            executeFirst: true,
            mapping: (from, to) => {
                Procedure.copyAttributes(from.exports.outputMember, to.imports.inputMember);
                Procedure.copyAttributes(from.exports.outputDocket, to.imports.inputDocket);
                Procedure.copyAttributes(from.exports.outputCase1, to.imports.inputCase1);
                to.globals.command = 'FIRSTIME'; 
            },
            returnsOn: [
                {exitState: 'AaAdsCommonObjects.AA740_R_RETURN', autoFlow: 'EXIT'}
            ],
            onReturnExecuteFirst: true,
            returnMapping: (from, to) => {
                Procedure.copyAttributes(from.exports.outputMember, to.imports.inputMember);
                Procedure.copyAttributes(from.exports.outputDocket, to.imports.inputDocket);
                Procedure.copyAttributes(from.exports.outputCase1, to.imports.inputCase1);
                to.globals.command = 'FIRSTIME'; 
            }
        },
        {
            toScreenId: 'CmCaseManagementMainMenu',
            type: 'link',
            flowsOn: [
                {exitState: 'CmCaseManagement.CM611_L_CASE_MANAGEMENT', autoFlow: ''}
            ],
            executeFirst: true,
            mapping: (from, to) => {
                Procedure.copyAttributes(from.exports.outputMember, to.imports.inputMember);
                Procedure.copyAttributes(from.exports.outputDocket, to.imports.inputDocket);
                Procedure.copyAttributes(from.exports.outputCase1, to.imports.inputCase1);
                to.globals.command = 'FIRSTIME'; 
            },
            returnsOn: [
                {exitState: 'AaAdsCommonObjects.AA740_R_RETURN', autoFlow: 'EXIT'}
            ],
            onReturnExecuteFirst: true,
            returnMapping: (from, to) => {
                Procedure.copyAttributes(from.exports.outputMember, to.imports.inputMember);
                Procedure.copyAttributes(from.exports.outputDocket, to.imports.inputDocket);
                Procedure.copyAttributes(from.exports.outputCase1, to.imports.inputCase1);
                to.globals.command = 'FIRSTIME'; 
            }
        },
        {
            toScreenId: 'LeEstablishmentMenu',
            type: 'link',
            flowsOn: [
                {exitState: 'CmCaseManagement.CM627_L_ESTABLISHMENT', autoFlow: ''}
            ],
            executeFirst: true,
            mapping: (from, to) => {
                Procedure.copyAttributes(from.exports.outputMember, to.imports.deleteMeMember);
                Procedure.copyAttributes(from.exports.outputDocket, to.imports.inputDocket);
                Procedure.copyAttributes(from.exports.outputCase1, to.imports.inputCase1);
                to.globals.command = 'FIRSTIME'; 
            },
            returnsOn: [
                {exitState: 'AaAdsCommonObjects.AA740_R_RETURN', autoFlow: 'EXIT'}
            ],
            onReturnExecuteFirst: true,
            returnMapping: (from, to) => {
                Procedure.copyAttributes(from.exports.outputMember, to.imports.inputMember);
                Procedure.copyAttributes(from.exports.outputDocket, to.imports.inputDocket);
                Procedure.copyAttributes(from.exports.outputCase1, to.imports.inputCase1);
                to.globals.command = 'FIRSTIME'; 
            }
        },
        {
            toScreenId: 'LeEnforcementMenu',
            type: 'link',
            flowsOn: [
                {exitState: 'CmCaseManagement.CM625_L_ENFORCEMENT', autoFlow: ''}
            ],
            executeFirst: true,
            mapping: (from, to) => {
                Procedure.copyAttributes(from.exports.outputMember, to.imports.deleteMeMember);
                Procedure.copyAttributes(from.exports.outputCase1, to.imports.inputHiddenFastpathCase1);
                Procedure.copyAttributes(from.exports.outputDocket, to.imports.inputHiddenFastpathDocket);
                to.globals.command = 'FIRSTIME'; 
            },
            returnsOn: [
                {exitState: 'AaAdsCommonObjects.AA740_R_RETURN', autoFlow: 'EXIT'}
            ],
            onReturnExecuteFirst: true,
            returnMapping: (from, to) => {
                Procedure.copyAttributes(from.exports.outputHiddenFastpathCase1, to.imports.inputCase1);
                Procedure.copyAttributes(from.exports.outputHiddenFastpathDocket, to.imports.inputDocket);
                Procedure.copyAttributes(from.exports.outputHiddenFastpathMember, to.imports.inputMember);
                to.globals.command = 'FIRSTIME'; 
            }
        },
        {
            toScreenId: 'Ps00SecurityMenu',
            type: 'transfer',
            flowsOn: [
                {exitState: 'CmCaseManagement.CM698_L_LINK_TO_SECURITY_MENU', autoFlow: ''}
            ],
            executeFirst: false,
            mapping: (from, to) => {
                 to.globals.command = ''; 
            }
        },
        {
            toScreenId: 'CmCsesSecurityWarning',
            type: 'link',
            flowsOn: [
                {exitState: 'CmCaseManagement.CM706_L_LINK_TO_CSES_WARNING', autoFlow: ''}
            ],
            executeFirst: true,
            mapping: (from, to) => {
                 to.globals.command = ''; 
            },
            returnsOn: [
                {exitState: 'CmCaseManagement.CM520_I_LINK_TO_CLD_SPT_ENF_MENU', autoFlow: ''}
            ],
            onReturnExecuteFirst: true,
            returnMapping: (from, to) => {
                to.globals.command = 'FIRSTIME'; 
            }
        }
    ];

    readonly clearScreenInput = [
        {
              keyword: ['C'],
              mapping: {attribute: this.imports.inputCase1.identifier1}
        },
        {
              keyword: ['D'],
              mapping: {attribute: this.imports.inputDocket.identifier1}
        },
        {
              keyword: ['M'],
              mapping: {attribute: this.imports.inputMember.identifier1}
        },
        {
              keyword: [],
              mapping: {attribute: this.globals.command}
        }
    ];
}
