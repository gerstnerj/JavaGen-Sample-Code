package gov.nm.cses.gen.procedures;

import static com.innowake.gen.Functions.*;

import com.innowake.gen.*;
import com.innowake.gen.attributes.*;
import com.innowake.gen.Attribute.VideoAttribute;
import com.innowake.gen.utils.*;
import gov.nm.cses.gen.globals.GlobalCommand;
import gov.nm.cses.gen.globals.exitstate.*;
import gov.nm.cses.gen.entities.*;
import gov.nm.cses.gen.actions.*;
import java.util.Iterator;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.annotation.RequestScope;
import org.springframework.http.MediaType;

/**
  * Desc:
  * 
  * Functions:
  * 
  * Exit States:
  * 
  */ 
@RestController
@RequestScope
public class CmChildSupportEnfMenu extends IntermediateProcedureStep<CmChildSupportEnfMenu.Imports, CmChildSupportEnfMenu.Exports> {

     
    public static final class Imports extends ImportContainer {

         
        public static final class InputAa0014Menu extends EntityView<Aa0014Menu > {
             public Aa0014Menu.Selection selection = new Aa0014Menu.Selection();
        }
         
        public static final class InputFastpath extends EntityView<Fastpath > {
             public Fastpath.FastpathCommand fastpathCommand = new Fastpath.FastpathCommand();
        }
         
        public static final class InputMember extends EntityView<Member > {
             public Member.Identifier1 identifier1 = new Member.Identifier1();
        }
         
        public static final class InputDocket extends EntityView<Docket > {
             public Docket.Identifier1 identifier1 = new Docket.Identifier1();
        }
         
        public static final class InputCase1 extends EntityView<Case1 > {
             public Case1.Identifier1 identifier1 = new Case1.Identifier1();
        }

        public final InputAa0014Menu inputAa0014Menu = new InputAa0014Menu();
        public final InputFastpath inputFastpath = new InputFastpath();
        public final InputMember inputMember = new InputMember();
        public final InputDocket inputDocket = new InputDocket();
        public final InputCase1 inputCase1 = new InputCase1();
    }

    public static final class Exports extends ExportContainer {

         
        public static final class OutputAa0014Menu extends EntityView<Aa0014Menu > {
             public Aa0014Menu.Selection selection = new Aa0014Menu.Selection();
        }
         
        public static final class OutputFastpath extends EntityView<Fastpath > {
             public Fastpath.FastpathCommand fastpathCommand = new Fastpath.FastpathCommand();
        }
         
        public static final class OutputMember extends EntityView<Member > {
             public Member.Identifier1 identifier1 = new Member.Identifier1();
        }
         
        public static final class OutputDocket extends EntityView<Docket > {
             public Docket.Identifier1 identifier1 = new Docket.Identifier1();
        }
         
        public static final class OutputCase1 extends EntityView<Case1 > {
             public Case1.Identifier1 identifier1 = new Case1.Identifier1();
        }

        public final OutputAa0014Menu outputAa0014Menu = new OutputAa0014Menu();
        public final OutputFastpath outputFastpath = new OutputFastpath();
        public final OutputMember outputMember = new OutputMember();
        public final OutputDocket outputDocket = new OutputDocket();
        public final OutputCase1 outputCase1 = new OutputCase1();
    }

    private Imports imports = new Imports();
    private Exports exports = new Exports();



    @Override
    public void run() {
        // --------------------------------------------
        // Andersen Consulting  1994.
        // Change Log:
        // 
        // Date   4/11/94   Initial Creation
        // Damian Kelly
        // --------------------------------------------
        // 
        move(imports.inputCase1).to(exports.outputCase1);
        move(imports.inputDocket).to(exports.outputDocket);
        move(imports.inputMember).to(exports.outputMember);
        move(imports.inputFastpath).to(exports.outputFastpath);




        // -----------------
        // Fastpath Logic
        // -----------------
        escape60402983:
        if (! imports.inputFastpath.fastpathCommand.equals(TextAttribute.of(Constant.SPACES))) {
            escape60402985:
            if (getCommand().equals(GlobalCommand.ENTER)) {
                escape60402988:
                if (imports.inputAa0014Menu.selection.equals(TextAttribute.of(Constant.SPACES))) {
                    use(action(AaFastpathCab.class)
                            .whichImportsView(imports.inputFastpath).to(imports -> imports.inputFastpath)
                            .whichImportsView(imports.inputMember).to(imports -> imports.inputMember)
                            .whichImportsView(imports.inputDocket).to(imports -> imports.inputDocket)
                            .whichImportsView(imports.inputCase1).to(imports -> imports.inputCase1)
                        );

                    escape60402989:
                    if (! getExitState().equals(AaAdsCommonObjects.AA524_I_NEXTTRAN_SET)) {
                        make(exports.outputFastpath.fastpathCommand, VideoAttribute.COLOR_NORMAL, VideoAttribute.INTENSITY_NORMAL, VideoAttribute.HIGHLIGHTING_NORMAL, VideoAttribute.ERROR, VideoAttribute.UNPROTECTED);
                    }
                } else {
                    // ---------------------------------------------
                    // User entered a fastpath command and a menu
                    // selection  Flag as error
                    // ---------------------------------------------
                    make(exports.outputAa0014Menu.selection, VideoAttribute.COLOR_NORMAL, VideoAttribute.INTENSITY_NORMAL, VideoAttribute.HIGHLIGHTING_NORMAL, VideoAttribute.ERROR, VideoAttribute.UNPROTECTED);
                    make(exports.outputFastpath.fastpathCommand, VideoAttribute.COLOR_NORMAL, VideoAttribute.INTENSITY_NORMAL, VideoAttribute.HIGHLIGHTING_NORMAL, VideoAttribute.ERROR, VideoAttribute.UNPROTECTED);
                    setExitState(AaAdsCommonObjects.AA050_E_INVALID_FASTPATH_ACTION);
                }
            } else {
                // -------------------------------
                // User entered an invalid command
                // or menu choice instead of ENTER
                // -------------------------------
                make(exports.outputFastpath.fastpathCommand, VideoAttribute.COLOR_NORMAL, VideoAttribute.INTENSITY_NORMAL, VideoAttribute.HIGHLIGHTING_NORMAL, VideoAttribute.ERROR, VideoAttribute.UNPROTECTED);
                setExitState(AaAdsCommonObjects.AA041_E_INVALID_CMD_FOR_FASTPATH);
            }

            escape60402986:
            if (getExitState().equals(AaAdsCommonObjects.AA524_I_NEXTTRAN_SET)) {
                return;
            } else {
                setCommand(GlobalCommand.BYPASS);
            }
        }
        escape60402984:
        if (getCommand().equals(TextAttribute.of(Constant.SPACES))) {
            setExitState(CmCaseManagement.CM706_L_LINK_TO_CSES_WARNING);
            return;
        } else if (getCommand().equals(GlobalCommand.FIRSTIME)) {
            setExitState(AaAdsCommonObjects.AA559_I_ALL_OK);


            setCommand(TextAttribute.of(Constant.SPACES));

        } else if (getCommand().equals(GlobalCommand.BYPASS)) {
            move(imports.inputAa0014Menu).to(exports.outputAa0014Menu);
        } else if (getCommand().equals(GlobalCommand.EXIT)) {
            // --------------------------------------------
            // An Autoflow should be set for the command
            // EXIT and associated with the EXIT STATE
            // aa_xfer_to_menu on the flow to the next
            // higher menu.  The flow should be set to
            // DISPLAY FIRST.  If this flow is not set up
            // correctly, this procedure will not execute
            // when the command is EXIT
            // New Mexico does not have the VTAM menus we
            // will not need to flow to any other menu when
            // PF3 is pressed.    12/08/95 Danny Bryce
            // --------------------------------------------


            use(action(TaExitIef.class)
                );

            // --------------------------------------------
            // When an EXIT is requested from the highest
            // level menu in a Business System, control is
            // passed to the Dynamic Business System Menu.
            // If you do NOT have a System Level Menu that
            // has each Business System as an option, you
            // should delete this "CASE exit" logic
            // --------------------------------------------

        } else if (getCommand().equals(GlobalCommand.ENTER)) {
            escape60402987:
            if (imports.inputAa0014Menu.selection.equals(TextAttribute.of("1"))) {
                setExitState(CmCaseManagement.CM609_L_CASE_INITIATION_AND_UPDT);
            } else if (imports.inputAa0014Menu.selection.equals(TextAttribute.of("2"))) {
                setExitState(CmCaseManagement.CM654_L_LOCATE);
            } else if (imports.inputAa0014Menu.selection.equals(TextAttribute.of("3"))) {
                setExitState(CmCaseManagement.CM611_L_CASE_MANAGEMENT);
            } else if (imports.inputAa0014Menu.selection.equals(TextAttribute.of("4"))) {
                setExitState(CmCaseManagement.CM645_L_INTERSTATE);
            } else if (imports.inputAa0014Menu.selection.equals(TextAttribute.of("5"))) {
                setExitState(CmCaseManagement.CM627_L_ESTABLISHMENT);
            } else if (imports.inputAa0014Menu.selection.equals(TextAttribute.of("6"))) {
                setExitState(CmCaseManagement.CM625_L_ENFORCEMENT);
            } else if (imports.inputAa0014Menu.selection.equals(TextAttribute.of("7"))) {
                setExitState(CmCaseManagement.CM629_L_FINANCIAL);
            } else if (imports.inputAa0014Menu.selection.equals(TextAttribute.of("8"))) {
                setExitState(CmCaseManagement.CM698_L_LINK_TO_SECURITY_MENU);
            } else {
                move(imports.inputAa0014Menu).to(exports.outputAa0014Menu);
                make(exports.outputAa0014Menu.selection, VideoAttribute.COLOR_NORMAL, VideoAttribute.INTENSITY_NORMAL, VideoAttribute.HIGHLIGHTING_NORMAL, VideoAttribute.ERROR, VideoAttribute.UNPROTECTED);
                setExitState(AaAdsCommonObjects.AA061_E_INVALID_OPTION);
            }

        } else {
            setExitState(AaAdsCommonObjects.AA053_E_INVALID_FUNCTION_KEY);
        }
        setCommand(TextAttribute.of(Constant.SPACES));
    }


    protected void setImports(Imports imports) {
        this.imports = imports;
    }

    @Override
    public Imports getImports() {
        return imports;
    }

    @Override
    public Exports getExports() {
        return exports;
    }

    @Override
    protected void resetExports() {
        this.exports = new Exports();
    }

    @Override
    protected String getTranCode() {
        return "HGHI";
    }

    @PostMapping(value = "/cm_child_support_enf_menu", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    ProcedureStep<Imports, Exports>.ProcedureStepOut serviceExecute(@RequestBody ProcedureStateIn<Imports> in) {
        return executeProcedureStep(in);
    }
}