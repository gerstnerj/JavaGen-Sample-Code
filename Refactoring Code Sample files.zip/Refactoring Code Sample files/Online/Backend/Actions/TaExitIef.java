package gov.nm.cses.gen.actions;

import static com.innowake.gen.Functions.*;

import com.innowake.gen.*;
import com.innowake.gen.attributes.*;
import com.innowake.gen.utils.*;
import com.innowake.gen.annotation.ExternalActionBlock;
import com.innowake.gen.annotation.ExternalActionBlock.GenerateMissingFlags;
import gov.nm.cses.gen.globals.*;
import gov.nm.cses.gen.globals.exitstate.*;

import static gov.nm.cses.gen.globals.GlobalCommand.*;

import gov.nm.cses.gen.entities.*;
import com.innowake.gen.integration.MeeIntegrationBean;
import gov.nm.cses.gen.eab.HSTANRCC;

/**
  * This external action block will exit the user out of IEF and log them out 
  * of CICS.  This external will be accessed when PF3 is pressed on the screen.
  * 
  */ 
@ExternalActionBlock(generateMissingFlags = GenerateMissingFlags.TRUE)
public final class TaExitIef extends IntermediateAction<TaExitIef.Imports, TaExitIef.Exports> {

    /**
      * This external action block will exit the user out of IEF and log them out 
      * of CICS.  This external will be accessed when PF3 is pressed on the screen.
      * 
      */ 
    public static final class Imports extends ImportContainer {


    }

    public static final class Exports extends ExportContainer {


    }

    private Imports imports = new Imports();
    private Exports exports = new Exports();



    @Override
    public void run() {
        MeeIntegrationBean integrationBean = getGlobal().getMeeIntegrationBean();
        integrationBean.runProgram(HSTANRCC.class, integrationBean.getLinkage(this));
    }

    @Override
    public void setImports(Imports imports) {
        this.imports = imports;
    }

    @Override
    public Imports getImports() {
        return this.imports;
    }

    @Override
    public Exports getExports() {
        return this.exports;
    }
}