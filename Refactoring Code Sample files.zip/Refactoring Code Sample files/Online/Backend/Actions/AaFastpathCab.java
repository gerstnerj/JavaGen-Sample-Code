package gov.nm.cses.gen.actions;

import static com.innowake.gen.Functions.*;

import com.innowake.gen.*;
import com.innowake.gen.attributes.*;
import com.innowake.gen.utils.*;
import gov.nm.cses.gen.globals.*;
import gov.nm.cses.gen.globals.exitstate.*;

import static gov.nm.cses.gen.globals.GlobalCommand.*;

import gov.nm.cses.gen.entities.*;

/**
  * This CAB handles fastpathing logic.  It sets the nexttran based on fastpath 
  * command passed in by the calling program.  It works by taking the four 
  * character mnuemonic and reading a table to decode the IMS transaction code.
  *   It then checks for a case id, member id, and docket id in the fastpath line.  If one is not found, the value passed in the PDA is used to string into the nexttran line.  Procedures should have their clear screen input set up with case id, docket id, member id, and ief command accepted in that order.
  */ 
public final class AaFastpathCab extends IntermediateAction<AaFastpathCab.Imports, AaFastpathCab.Exports> {

    /**
      * This CAB handles fastpathing logic.  It sets the nexttran based on fastpath 
      * command passed in by the calling program.  It works by taking the four 
      * character mnuemonic and reading a table to decode the IMS transaction code.
      *   It then checks for a case id, member id, and docket id in the fastpath line.  If one is not found, the value passed in the PDA is used to string into the nexttran line.  Procedures should have their clear screen input set up with case id, docket id, member id, and ief command accepted in that order.
      */ 
    public static final class Imports extends ImportContainer {

         
        public static final class InputFastpath extends EntityView<Fastpath > {
             public Fastpath.FastpathCommand fastpathCommand = new Fastpath.FastpathCommand();
        }
         
        public static final class InputCase1 extends EntityView<Case1 > {
             public Case1.Identifier1 identifier1 = new Case1.Identifier1();
        }
         
        public static final class InputMember extends EntityView<Member > {
             public Member.Identifier1 identifier1 = new Member.Identifier1();
        }
         
        public static final class InputDocket extends EntityView<Docket > {
             public Docket.Identifier1 identifier1 = new Docket.Identifier1();
        }

        public final InputFastpath inputFastpath = new InputFastpath();
        public final InputCase1 inputCase1 = new InputCase1();
        public final InputMember inputMember = new InputMember();
        public final InputDocket inputDocket = new InputDocket();
    }

    public static final class Exports extends ExportContainer {


    }

    private Imports imports = new Imports();
    private Exports exports = new Exports();

     
    public static final class LocalTempFastpath extends EntityView<Fastpath >  {
         public Fastpath.FastpathCommand fastpathCommand = new Fastpath.FastpathCommand();
    }
     
    public static final class LocalAa0012FastpathWorkSet extends EntityView<Aa0012FastpathWorkSet >  {
         public Aa0012FastpathWorkSet.DocketIdText docketIdText = new Aa0012FastpathWorkSet.DocketIdText();
         public Aa0012FastpathWorkSet.MemberIdText memberIdText = new Aa0012FastpathWorkSet.MemberIdText();
         public Aa0012FastpathWorkSet.CaseIdText caseIdText = new Aa0012FastpathWorkSet.CaseIdText();
         public Aa0012FastpathWorkSet.MnemonicCode mnemonicCode = new Aa0012FastpathWorkSet.MnemonicCode();
         public Aa0012FastpathWorkSet.TransactionCode transactionCode = new Aa0012FastpathWorkSet.TransactionCode();
    }
     
    public static final class LocalDocketFastpath extends EntityView<Fastpath >  {
         public Fastpath.FastpathCommand fastpathCommand = new Fastpath.FastpathCommand();
    }
     
    public static final class LocalMemberFastpath extends EntityView<Fastpath >  {
         public Fastpath.FastpathCommand fastpathCommand = new Fastpath.FastpathCommand();
    }
     
    public static final class LocalCaseFastpath extends EntityView<Fastpath >  {
         public Fastpath.FastpathCommand fastpathCommand = new Fastpath.FastpathCommand();
    }
     
    public static final class LocalIdBeginIefSupplied extends EntityView<IefSupplied >  {
         public IefSupplied.Count count = new IefSupplied.Count();
    }
     
    public static final class LocalIdEndIefSupplied extends EntityView<IefSupplied >  {
         public IefSupplied.Count count = new IefSupplied.Count();
    }
     
    public static final class LocalFastpath extends EntityView<Fastpath >  {
         public Fastpath.FastpathCommand fastpathCommand = new Fastpath.FastpathCommand();
    }
     
    public static final class LocalTrancodeLengthIefSupplied extends EntityView<IefSupplied >  {
         public IefSupplied.Count count = new IefSupplied.Count();
    }
     
    public static final class LocalSubstrIefSupplied extends EntityView<IefSupplied >  {
         public IefSupplied.Count count = new IefSupplied.Count();
    }
     
    public static final class LocalIdFoundIefSupplied extends EntityView<IefSupplied >  {
         public IefSupplied.Flag flag = new IefSupplied.Flag();
    }
     
    public static final class ActionTran extends PersistentEntityView<Tran > {
         public Tran.MnemonicCode mnemonicCode = new Tran.MnemonicCode();
         public Tran.Code code = new Tran.Code();
    }
    public final LocalTempFastpath localTempFastpath = new LocalTempFastpath();
    public final LocalAa0012FastpathWorkSet localAa0012FastpathWorkSet = new LocalAa0012FastpathWorkSet();
    public final LocalDocketFastpath localDocketFastpath = new LocalDocketFastpath();
    public final LocalMemberFastpath localMemberFastpath = new LocalMemberFastpath();
    public final LocalCaseFastpath localCaseFastpath = new LocalCaseFastpath();
    public final LocalIdBeginIefSupplied localIdBeginIefSupplied = new LocalIdBeginIefSupplied();
    public final LocalIdEndIefSupplied localIdEndIefSupplied = new LocalIdEndIefSupplied();
    public final LocalFastpath localFastpath = new LocalFastpath();
    public final LocalTrancodeLengthIefSupplied localTrancodeLengthIefSupplied = new LocalTrancodeLengthIefSupplied();
    public final LocalSubstrIefSupplied localSubstrIefSupplied = new LocalSubstrIefSupplied();
    public final LocalIdFoundIefSupplied localIdFoundIefSupplied = new LocalIdFoundIefSupplied();
    public final ActionTran actionTran = new ActionTran();

    @Override
    public void run() {
        // ---------------------------------------------
        // Andersen Consulting
        // 
        // Modifcations:
        // 1.  1/5/95     	Bill Feidt
        // Added additional validation logic.
        // 2.  1/30/97	S Hillje
        // Added FOR loops to traverse the input
        // fastpath view. This replaces uses of the
        // find command, which is incompatible with
        // the Ver. 5.2 upgrade
        // ---------------------------------------------

        setExitState(AaAdsCommonObjects.AA559_I_ALL_OK);

        escape60435893:
        if (imports.inputFastpath.fastpathCommand.equals(TextAttribute.of(Constant.SPACES))) {
            setExitState(AaAdsCommonObjects.AA051_E_INVALID_FASTPATH_CALL);
        } else {
            localSubstrIefSupplied.count.setValue(NumericAttribute.of(1));
            escape60445611:
            for (NumericAttribute i60445611 = NumericAttribute.of(65); localSubstrIefSupplied.count.lessThanOrEqual(i60445611) ; localSubstrIefSupplied.count.setValue(localSubstrIefSupplied.count.plus(NumericAttribute.of(1)))) {
                escape60445618:
                if (substr(imports.inputFastpath.fastpathCommand, localSubstrIefSupplied.count, NumericAttribute.of(1)).equals(TextAttribute.of(" "))) {
                    localTrancodeLengthIefSupplied.count.setValue(localSubstrIefSupplied.count);
                    break escape60445611;
                }
            }


            escape60435894:
            if (localTrancodeLengthIefSupplied.count.compareTo(NumericAttribute.of(5)) <= 0) {
                localAa0012FastpathWorkSet.mnemonicCode.setValue(substr(imports.inputFastpath.fastpathCommand, NumericAttribute.of(1), localTrancodeLengthIefSupplied.count));

                escape60493517:
                try {
                    read( actionTran ).allowMultiple().where(
                        that(actionTran).attribute(actionTran.mnemonicCode).isEqualTo(valueOf(localAa0012FastpathWorkSet.mnemonicCode)) );
                    localAa0012FastpathWorkSet.transactionCode.setValue(actionTran.code);
                } catch (NotFoundException e60493517) {
                    setExitState(AaAdsCommonObjects.AA051_E_INVALID_FASTPATH_CALL);
                    break escape60435893;
                }
            } else {
                setExitState(AaAdsCommonObjects.AA051_E_INVALID_FASTPATH_CALL);
                break escape60435893;
            }

            // *
            // * The nexttran action will formatted as
            // * TRANCODE C(123456789) D(1234567890123) M(123456789) FIRSTTIME.
            // * The order is case id, docket id, member id, and command.
            // * The command is set so that all procedures
            // * will be execute first and will build the screen
            // * for any case, member, or docket that is passed in
            // * to it.
            // *

            // ---------------------------------------------
            // Case ID
            // ---------------------------------------------

            // *
            // * This picks the case id to be passed.  If one has
            // * been entered on the fastpath line then it is passed.
            // * If not then the case id in the global area will be
            // * passed.
            // *

            localIdFoundIefSupplied.flag.setValue(TextAttribute.of("N"));
            localSubstrIefSupplied.count.setValue(NumericAttribute.of(1));
            escape60445612:
            for (NumericAttribute i60445612 = NumericAttribute.of(65); localSubstrIefSupplied.count.lessThanOrEqual(i60445612) ; localSubstrIefSupplied.count.setValue(localSubstrIefSupplied.count.plus(NumericAttribute.of(1)))) {
                escape60445619:
                if (localIdFoundIefSupplied.flag.equals(TextAttribute.of("Y")) && (substr(imports.inputFastpath.fastpathCommand, localSubstrIefSupplied.count, NumericAttribute.of(1)).equals(TextAttribute.of(")")))) {
                    localIdEndIefSupplied.count.setValue(localSubstrIefSupplied.count.minus(localIdBeginIefSupplied.count).minus(NumericAttribute.of(1)));
                    break escape60445612;
                }
                escape60445620:
                if (substr(imports.inputFastpath.fastpathCommand, localSubstrIefSupplied.count, NumericAttribute.of(2)).equals(TextAttribute.of("C("))) {
                    localIdFoundIefSupplied.flag.setValue(TextAttribute.of("Y"));
                    localIdBeginIefSupplied.count.setValue(localSubstrIefSupplied.count);
                }
            }

            escape60445613:
            if (localIdFoundIefSupplied.flag.equals(TextAttribute.of("N"))) {
                localAa0012FastpathWorkSet.caseIdText.setValue(substr(textnum(imports.inputCase1.identifier1), NumericAttribute.of(7), NumericAttribute.of(9)));
            } else {
                // *
                // * This sets a local view to the beginning of the case
                // * id entered in the fastpath line.  Then the case id is
                // * stripped out and moved to a local view for
                // * concatenation into the nexttran field.
                // *

                localCaseFastpath.fastpathCommand.setValue(substr(imports.inputFastpath.fastpathCommand, localIdBeginIefSupplied.count.plus(NumericAttribute.of(2)), (NumericAttribute.of(65).minus(localIdBeginIefSupplied.count))));

                // *
                // * If the parenthesis have not been closed for the id,
                // * if the ID is too long, or an alphabetic character
                // * has been entered, an error will be returned.
                // *

                escape60445621:
                if (localIdEndIefSupplied.count.compareTo(NumericAttribute.of(1)) <= 0) {
                    setExitState(AaAdsCommonObjects.AA040_E_INVALID_CASE_ID_IN_FP);
                } else if (localIdEndIefSupplied.count.compareTo(NumericAttribute.of(10)) > 0) {
                    setExitState(AaAdsCommonObjects.AA040_E_INVALID_CASE_ID_IN_FP);
                } else {
                    localAa0012FastpathWorkSet.caseIdText.setValue(substr(localCaseFastpath.fastpathCommand, NumericAttribute.of(1), localIdEndIefSupplied.count.minus(NumericAttribute.of(1))));

                    escape60445628:
                    if (! verify(substr(localCaseFastpath.fastpathCommand, NumericAttribute.of(1), localIdEndIefSupplied.count.minus(NumericAttribute.of(1))), TextAttribute.of("1234567890")).equals(NumericAttribute.of(0))) {
                        setExitState(AaAdsCommonObjects.AA040_E_INVALID_CASE_ID_IN_FP);
                    }
                }
            }

            // ---------------------------------------------
            // Member ID
            // ---------------------------------------------

            // *
            // * This picks the member id to be passed.  If one has
            // * been entered on the fastpath line then it is passed.
            // * If not then the member id in the global area will be
            // * passed.
            // *

            localIdFoundIefSupplied.flag.setValue(TextAttribute.of("N"));
            localSubstrIefSupplied.count.setValue(NumericAttribute.of(1));
            escape60445614:
            for (NumericAttribute i60445614 = NumericAttribute.of(65); localSubstrIefSupplied.count.lessThanOrEqual(i60445614) ; localSubstrIefSupplied.count.setValue(localSubstrIefSupplied.count.plus(NumericAttribute.of(1)))) {
                escape60445622:
                if (localIdFoundIefSupplied.flag.equals(TextAttribute.of("Y")) && (substr(imports.inputFastpath.fastpathCommand, localSubstrIefSupplied.count, NumericAttribute.of(1)).equals(TextAttribute.of(")")))) {
                    localIdEndIefSupplied.count.setValue(localSubstrIefSupplied.count.minus(localIdBeginIefSupplied.count).minus(NumericAttribute.of(1)));
                    break escape60445614;
                }
                escape60445623:
                if (substr(imports.inputFastpath.fastpathCommand, localSubstrIefSupplied.count, NumericAttribute.of(2)).equals(TextAttribute.of("M("))) {
                    localIdFoundIefSupplied.flag.setValue(TextAttribute.of("Y"));
                    localIdBeginIefSupplied.count.setValue(localSubstrIefSupplied.count);
                }
            }

            escape60445615:
            if (localIdFoundIefSupplied.flag.equals(TextAttribute.of("N"))) {
                localAa0012FastpathWorkSet.memberIdText.setValue(substr(textnum(imports.inputMember.identifier1), NumericAttribute.of(7), NumericAttribute.of(9)));
            } else {
                // *
                // * This sets a local view to the beginning of the member
                // * id entered in the fastpath line.  Then the member id is
                // * stripped out and moved to a local view for
                // * concatenation into the nexttran field.
                // *

                localMemberFastpath.fastpathCommand.setValue(substr(imports.inputFastpath.fastpathCommand, localIdBeginIefSupplied.count.plus(NumericAttribute.of(2)), (NumericAttribute.of(65).minus(localIdBeginIefSupplied.count))));

                // *
                // * If the parenthesis have not been closed for the id,
                // * if the ID is too long, or an alphabetic character
                // * has been entered, an error will be returned.
                // *

                escape60445624:
                if (localIdEndIefSupplied.count.compareTo(NumericAttribute.of(1)) <= 0) {
                    setExitState(AaAdsCommonObjects.AA059_E_INVALD_MBR_ID_IN_FASTPTH);
                } else if (localIdEndIefSupplied.count.compareTo(NumericAttribute.of(10)) > 0) {
                    setExitState(AaAdsCommonObjects.AA059_E_INVALD_MBR_ID_IN_FASTPTH);
                } else {
                    localAa0012FastpathWorkSet.memberIdText.setValue(substr(localMemberFastpath.fastpathCommand, NumericAttribute.of(1), localIdEndIefSupplied.count.minus(NumericAttribute.of(1))));
                    escape60445629:
                    if (! verify(substr(localMemberFastpath.fastpathCommand, NumericAttribute.of(1), localIdEndIefSupplied.count.minus(NumericAttribute.of(1))), TextAttribute.of("1234567890")).equals(NumericAttribute.of(0))) {
                        setExitState(AaAdsCommonObjects.AA059_E_INVALD_MBR_ID_IN_FASTPTH);
                    }
                }
            }

            // ---------------------------------------------
            // Docket ID
            // ---------------------------------------------

            // *
            // * This picks the docket id to be passed.  If one has
            // * been entered on the fastpath line then it is passed.
            // * If not then the docket id in the global area will be
            // * passed.
            // *

            localIdFoundIefSupplied.flag.setValue(TextAttribute.of("N"));
            localSubstrIefSupplied.count.setValue(NumericAttribute.of(1));
            escape60445616:
            for (NumericAttribute i60445616 = NumericAttribute.of(65); localSubstrIefSupplied.count.lessThanOrEqual(i60445616) ; localSubstrIefSupplied.count.setValue(localSubstrIefSupplied.count.plus(NumericAttribute.of(1)))) {
                escape60445625:
                if (localIdFoundIefSupplied.flag.equals(TextAttribute.of("Y")) && (substr(imports.inputFastpath.fastpathCommand, localSubstrIefSupplied.count, NumericAttribute.of(1)).equals(TextAttribute.of(")")))) {
                    localIdEndIefSupplied.count.setValue(localSubstrIefSupplied.count.minus(localIdBeginIefSupplied.count).minus(NumericAttribute.of(1)));
                    break escape60445616;
                }
                escape60445626:
                if (substr(imports.inputFastpath.fastpathCommand, localSubstrIefSupplied.count, NumericAttribute.of(2)).equals(TextAttribute.of("D("))) {
                    localIdFoundIefSupplied.flag.setValue(TextAttribute.of("Y"));
                    localIdBeginIefSupplied.count.setValue(localSubstrIefSupplied.count);
                }
            }

            escape60445617:
            if (localIdFoundIefSupplied.flag.equals(TextAttribute.of("N"))) {
                localAa0012FastpathWorkSet.docketIdText.setValue(imports.inputDocket.identifier1);
            } else {
                // *
                // * This sets a local view to the beginning of the docket
                // * id entered in the fastpath line.  Then the docket id is
                // * stripped out and moved to a local view for
                // * concatenation into the nexttran field.
                // *

                localDocketFastpath.fastpathCommand.setValue(substr(imports.inputFastpath.fastpathCommand, localIdBeginIefSupplied.count.plus(NumericAttribute.of(2)), (NumericAttribute.of(65).minus(localIdBeginIefSupplied.count))));

                // *
                // * If the parenthesis have not been closed for the id,
                // * or the ID is too long, an error will be returned.
                // *

                escape60445627:
                if (localIdEndIefSupplied.count.compareTo(NumericAttribute.of(1)) <= 0) {
                    setExitState(AaAdsCommonObjects.AA160_E_INVALID_DOCKET_ID_IN_FP);
                } else if (localIdEndIefSupplied.count.compareTo(NumericAttribute.of(14)) > 0) {
                    setExitState(AaAdsCommonObjects.AA160_E_INVALID_DOCKET_ID_IN_FP);
                } else {
                    localAa0012FastpathWorkSet.docketIdText.setValue(substr(localDocketFastpath.fastpathCommand, NumericAttribute.of(1), localIdEndIefSupplied.count.minus(NumericAttribute.of(1))));
                    escape60445630:
                    if (! verify(substr(localDocketFastpath.fastpathCommand, NumericAttribute.of(1), localIdEndIefSupplied.count.minus(NumericAttribute.of(1))), TextAttribute.of("1234567890 ABCDEFGHIJKLMNOPQRSTUVWXYZ")).equals(NumericAttribute.of(0))) {
                        setExitState(AaAdsCommonObjects.AA160_E_INVALID_DOCKET_ID_IN_FP);
                    }
                }
            }

            escape60435895:
            if (getExitState().equals(AaAdsCommonObjects.AA559_I_ALL_OK)) {
                // *
                // * This strings the case, docket, and member id's
                // * together along with the command to be passed.
                // *

                localFastpath.fastpathCommand.setValue(concat(concat(concat(localAa0012FastpathWorkSet.transactionCode, TextAttribute.of(" ")), concat(concat(concat(concat(TextAttribute.of("C("), localAa0012FastpathWorkSet.caseIdText), TextAttribute.of(")")), TextAttribute.of(" ")), concat(concat(TextAttribute.of("D("), localAa0012FastpathWorkSet.docketIdText), TextAttribute.of(")")))), concat(TextAttribute.of(" "), concat(concat(concat(TextAttribute.of("M("), localAa0012FastpathWorkSet.memberIdText), TextAttribute.of(")")), TextAttribute.of(" FIRSTIME")))));
                setNextTransaction(localFastpath.fastpathCommand);
                setExitState(AaAdsCommonObjects.AA524_I_NEXTTRAN_SET);
            }
        }
    }


    @Override
    public void setImports(Imports imports) {
        this.imports = imports;
    }

    @Override
    public Imports getImports() {
        return this.imports;
    }

    @Override
    public Exports getExports() {
        return this.exports;
    }
}