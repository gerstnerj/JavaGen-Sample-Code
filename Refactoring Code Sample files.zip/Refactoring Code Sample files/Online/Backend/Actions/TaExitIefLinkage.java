package gov.nm.cses.gen.actions;

import com.innowake.gen.cobol.LinkageSection;
import com.innowake.gen.cobol.storage.*;
import com.innowake.gen.cobol.storage.ExportStorage;
import com.innowake.gen.cobol.storage.ImportStorage;
import com.innowake.gen.cobol.storage.Storage;
import java.util.ArrayList;

public class TaExitIefLinkage extends LinkageSection {

    public TaExitIefLinkage(TaExitIef genActionBlock) {
        this.highPerformanceViewMatching = false;
        this.generateMissingFlags = true;
        TaExitIef.Imports imports = genActionBlock.getImports();
        TaExitIef.Exports exports = genActionBlock.getExports();
        this.globals.add(GlobalStorage.builder(genActionBlock.getGlobal()));

    }
}