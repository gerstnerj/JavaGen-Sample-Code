package gov.nm.cses.gen.actions;

import static com.innowake.gen.Functions.*;

import com.innowake.gen.*;
import com.innowake.gen.attributes.*;
import com.innowake.gen.utils.*;
import gov.nm.cses.gen.globals.*;
import gov.nm.cses.gen.globals.exitstate.*;

import static gov.nm.cses.gen.globals.GlobalCommand.*;

import gov.nm.cses.gen.entities.*;

 
public final class TaCheckpointTest extends IntermediateAction<TaCheckpointTest.Imports, TaCheckpointTest.Exports> {

     
    public static final class Imports extends ImportContainer {

         
        public static final class ImportAaRebuildFiles extends EntityView<AaRebuildFiles > {
             public AaRebuildFiles.RebuildFlag rebuildFlag = new AaRebuildFiles.RebuildFlag();
        }
        public static final class InGroupFc extends GroupView {

             
            public static final class ImportAaFileControl extends EntityView<AaFileControl > {
                 public AaFileControl.FcIoFileModId fcIoFileModId = new AaFileControl.FcIoFileModId();
                 public AaFileControl.FcIoCallProcId fcIoCallProcId = new AaFileControl.FcIoCallProcId();
                 public AaFileControl.FcIoRequestCode fcIoRequestCode = new AaFileControl.FcIoRequestCode();
                 public AaFileControl.FcIoFileType fcIoFileType = new AaFileControl.FcIoFileType();
                 public AaFileControl.FcIoFileStatus fcIoFileStatus = new AaFileControl.FcIoFileStatus();
                 public AaFileControl.FcIoReturnCode fcIoReturnCode = new AaFileControl.FcIoReturnCode();
                 public AaFileControl.FcIoFileReturn fcIoFileReturn = new AaFileControl.FcIoFileReturn();
                 public AaFileControl.FcIoRstrtCount fcIoRstrtCount = new AaFileControl.FcIoRstrtCount();
            }

            public final ImportAaFileControl importAaFileControl = new ImportAaFileControl();

        }
         
        public static final class ImportAaCkpointControl extends EntityView<AaCkpointControl > {
             public AaCkpointControl.CpCallingPgmId cpCallingPgmId = new AaCkpointControl.CpCallingPgmId();
             public AaCkpointControl.CpJobNumber cpJobNumber = new AaCkpointControl.CpJobNumber();
             public AaCkpointControl.CpRequestCode cpRequestCode = new AaCkpointControl.CpRequestCode();
             public AaCkpointControl.CpProcessMode cpProcessMode = new AaCkpointControl.CpProcessMode();
             public AaCkpointControl.CpDrivingFileNo cpDrivingFileNo = new AaCkpointControl.CpDrivingFileNo();
             public AaCkpointControl.CpDbOrFileDr cpDbOrFileDr = new AaCkpointControl.CpDbOrFileDr();
             public AaCkpointControl.CpDbRepoData cpDbRepoData = new AaCkpointControl.CpDbRepoData();
        }

        public final ImportAaRebuildFiles importAaRebuildFiles = new ImportAaRebuildFiles();

        public final GroupViewList< InGroupFc > inGroupFc = new GroupViewList<>(InGroupFc.class, 20);

        public final ImportAaCkpointControl importAaCkpointControl = new ImportAaCkpointControl();
    }

    public static final class Exports extends ExportContainer {

         
        public static final class ExportAaRebuildFiles extends EntityView<AaRebuildFiles > {
             public AaRebuildFiles.RebuildFlag rebuildFlag = new AaRebuildFiles.RebuildFlag();
        }
        public static final class OutGroupFc extends GroupView {

             
            public static final class ExportAaFileControl extends EntityView<AaFileControl > {
                 public AaFileControl.FcIoFileModId fcIoFileModId = new AaFileControl.FcIoFileModId();
                 public AaFileControl.FcIoCallProcId fcIoCallProcId = new AaFileControl.FcIoCallProcId();
                 public AaFileControl.FcIoRequestCode fcIoRequestCode = new AaFileControl.FcIoRequestCode();
                 public AaFileControl.FcIoFileType fcIoFileType = new AaFileControl.FcIoFileType();
                 public AaFileControl.FcIoFileStatus fcIoFileStatus = new AaFileControl.FcIoFileStatus();
                 public AaFileControl.FcIoReturnCode fcIoReturnCode = new AaFileControl.FcIoReturnCode();
                 public AaFileControl.FcIoFileReturn fcIoFileReturn = new AaFileControl.FcIoFileReturn();
                 public AaFileControl.FcIoRstrtCount fcIoRstrtCount = new AaFileControl.FcIoRstrtCount();
            }

            public final ExportAaFileControl exportAaFileControl = new ExportAaFileControl();
        }
         
        public static final class ExportAaCkpointControl extends EntityView<AaCkpointControl > {
             public AaCkpointControl.CpCallingPgmId cpCallingPgmId = new AaCkpointControl.CpCallingPgmId();
             public AaCkpointControl.CpJobNumber cpJobNumber = new AaCkpointControl.CpJobNumber();
             public AaCkpointControl.CpRequestCode cpRequestCode = new AaCkpointControl.CpRequestCode();
             public AaCkpointControl.CpProcessMode cpProcessMode = new AaCkpointControl.CpProcessMode();
             public AaCkpointControl.CpDrivingFileNo cpDrivingFileNo = new AaCkpointControl.CpDrivingFileNo();
             public AaCkpointControl.CpDbOrFileDr cpDbOrFileDr = new AaCkpointControl.CpDbOrFileDr();
             public AaCkpointControl.CpDbRepoData cpDbRepoData = new AaCkpointControl.CpDbRepoData();
        }

        public final ExportAaRebuildFiles exportAaRebuildFiles = new ExportAaRebuildFiles();

        public final GroupViewList< OutGroupFc > outGroupFc = new GroupViewList<>(OutGroupFc.class, 20);

        public final ExportAaCkpointControl exportAaCkpointControl = new ExportAaCkpointControl();
    }

    private Imports imports = new Imports();
    private Exports exports = new Exports();

     
    public static final class ActionAaFileControl extends EntityView<AaFileControl >  {
         public AaFileControl.FcIoCallProcId fcIoCallProcId = new AaFileControl.FcIoCallProcId();
    }
     
    public static final class ActionIefSupplied extends EntityView<IefSupplied >  {
         public IefSupplied.Count count = new IefSupplied.Count();
         public IefSupplied.Flag flag = new IefSupplied.Flag();
    }
     
    public static final class ActionProgramNumber extends PersistentEntityView<ProgramNumber > {
         public ProgramNumber.ProcedureIdentifier procedureIdentifier = new ProgramNumber.ProcedureIdentifier();
         public ProgramNumber.ProcedureName procedureName = new ProgramNumber.ProcedureName();
         public ProgramNumber.ProcedureStartTypeCode procedureStartTypeCode = new ProgramNumber.ProcedureStartTypeCode();
         public ProgramNumber.DbOrFileDrCode dbOrFileDrCode = new ProgramNumber.DbOrFileDrCode();
         public ProgramNumber.CheckpointFrequencyCount checkpointFrequencyCount = new ProgramNumber.CheckpointFrequencyCount();
    }
     
    public static final class ActionHistory extends PersistentEntityView<History > {
         public History.ProcedureIdentifier procedureIdentifier = new History.ProcedureIdentifier();
         public History.JobIdentifier jobIdentifier = new History.JobIdentifier();
         public History.StartTimestamp startTimestamp = new History.StartTimestamp();
         public History.EndTimestamp endTimestamp = new History.EndTimestamp();
    }
     
    public static final class ActionFileControl extends PersistentEntityView<FileControl > {
         public FileControl.ProcedureIdentifier procedureIdentifier = new FileControl.ProcedureIdentifier();
         public FileControl.JobIdentifier jobIdentifier = new FileControl.JobIdentifier();
         public FileControl.Count count = new FileControl.Count();
         public FileControl.ModuleIdentifier moduleIdentifier = new FileControl.ModuleIdentifier();
         public FileControl.CallingProcedureIdentifier callingProcedureIdentifier = new FileControl.CallingProcedureIdentifier();
         public FileControl.RequestCode requestCode = new FileControl.RequestCode();
         public FileControl.TypeCode typeCode = new FileControl.TypeCode();
         public FileControl.StatusCode statusCode = new FileControl.StatusCode();
         public FileControl.ReturnCode returnCode = new FileControl.ReturnCode();
         public FileControl.StatusReturnCode statusReturnCode = new FileControl.StatusReturnCode();
         public FileControl.LineRestartCount lineRestartCount = new FileControl.LineRestartCount();
    }
     
    public static final class ActionCheckpointRestart extends PersistentEntityView<CheckpointRestart > {
         public CheckpointRestart.ProcedureIdentifier procedureIdentifier = new CheckpointRestart.ProcedureIdentifier();
         public CheckpointRestart.JobIdentifier jobIdentifier = new CheckpointRestart.JobIdentifier();
         public CheckpointRestart.DatabaseRepositionText databaseRepositionText = new CheckpointRestart.DatabaseRepositionText();
         public CheckpointRestart.CreateTimestamp createTimestamp = new CheckpointRestart.CreateTimestamp();
    }
    public final ActionAaFileControl actionAaFileControl = new ActionAaFileControl();
    public final ActionIefSupplied actionIefSupplied = new ActionIefSupplied();
    public final ActionProgramNumber actionProgramNumber = new ActionProgramNumber();
    public final ActionHistory actionHistory = new ActionHistory();
    public final ActionFileControl actionFileControl = new ActionFileControl();
    public final ActionCheckpointRestart actionCheckpointRestart = new ActionCheckpointRestart();

    @Override
    public void run() {
        exports.exportAaRebuildFiles.rebuildFlag.setValue(imports.importAaRebuildFiles.rebuildFlag);
        // VALIDATE CALLING PROGRAM ID
        escape60435458:
        if (imports.importAaCkpointControl.cpCallingPgmId.equals(TextAttribute.of(Constant.SPACES)) || (imports.importAaCkpointControl.cpJobNumber.equals(TextAttribute.of(Constant.SPACES)))) {
            setExitState(TaTechnicalArchitecture.TA188_B_PARAMETER_ERROR);
            return;
        }
        // VALIDATE REQUEST CODE
        escape60435454:
        if (! imports.importAaCkpointControl.cpRequestCode.equals(TextAttribute.of("PS")) && (! imports.importAaCkpointControl.cpRequestCode.equals(TextAttribute.of("CP"))) && (! imports.importAaCkpointControl.cpRequestCode.equals(TextAttribute.of("WP"))) && (! imports.importAaCkpointControl.cpRequestCode.equals(TextAttribute.of("FS")))) {
            setExitState(TaTechnicalArchitecture.TA188_B_PARAMETER_ERROR);
            return;
        }
        // FORMAT CONTROL RECORD TO EXPORT BACK TO CALLING PROCEDURE WITH THE PREVIOUSLY FORMATTED VALUES
        setExitState(TaTechnicalArchitecture.TA503_I_CHECKPOINT_SUCCESS);
        move(imports.importAaCkpointControl).to(exports.exportAaCkpointControl);
        exports.outGroupFc.setSubscript(NumericAttribute.of(1));
        imports.inGroupFc.initializeSubscript(NumericAttribute.of(1));
        escape60435457:
        for (NumericAttribute i60435457 = NumericAttribute.of(20); imports.inGroupFc.getSubscript().lessThanOrEqual(i60435457) && imports.inGroupFc.getSubscript().lessThanOrEqual(imports.inGroupFc.getMaxSubscript()) && imports.inGroupFc.subscriptIsValid(); imports.inGroupFc.incrementSubscriptBy(NumericAttribute.of(1))) {
            imports.inGroupFc.updateLastSubscript();
            exports.outGroupFc.getCurrent().exportAaFileControl.fcIoCallProcId.setValue(imports.inGroupFc.getCurrent().importAaFileControl.fcIoCallProcId);
            exports.outGroupFc.getCurrent().exportAaFileControl.fcIoFileModId.setValue(imports.inGroupFc.getCurrent().importAaFileControl.fcIoFileModId);
            exports.outGroupFc.getCurrent().exportAaFileControl.fcIoFileReturn.setValue(imports.inGroupFc.getCurrent().importAaFileControl.fcIoFileReturn);
            exports.outGroupFc.getCurrent().exportAaFileControl.fcIoFileStatus.setValue(imports.inGroupFc.getCurrent().importAaFileControl.fcIoFileStatus);
            exports.outGroupFc.getCurrent().exportAaFileControl.fcIoFileType.setValue(imports.inGroupFc.getCurrent().importAaFileControl.fcIoFileType);
            exports.outGroupFc.getCurrent().exportAaFileControl.fcIoRequestCode.setValue(imports.inGroupFc.getCurrent().importAaFileControl.fcIoRequestCode);
            exports.outGroupFc.getCurrent().exportAaFileControl.fcIoReturnCode.setValue(imports.inGroupFc.getCurrent().importAaFileControl.fcIoReturnCode);
            exports.outGroupFc.getCurrent().exportAaFileControl.fcIoRstrtCount.setValue(imports.inGroupFc.getCurrent().importAaFileControl.fcIoRstrtCount);
            exports.outGroupFc.setSubscript(exports.outGroupFc.getSubscript().plus(NumericAttribute.of(1)));
        }
        imports.inGroupFc.capSubscript();

        escape60492005:
        try {
            read( actionProgramNumber ).allowMultiple().where(
                that(actionProgramNumber).attribute(actionProgramNumber.procedureIdentifier).isEqualTo(valueOf(imports.importAaCkpointControl.cpCallingPgmId)) );
        } catch (NotFoundException e60492005) {
            setExitState(TaTechnicalArchitecture.TA186_B_ERROR_EXISTS);
            return;
        }
        escape60435453:
        if (imports.importAaCkpointControl.cpRequestCode.equals(TextAttribute.of("PS")) || (imports.importAaCkpointControl.cpRequestCode.equals(TextAttribute.of("FS")))) {
            escape60492000:
            try {
                read( actionCheckpointRestart ).allowMultiple().where(
                    (that(actionCheckpointRestart).attribute(actionCheckpointRestart.procedureIdentifier).isEqualTo(valueOf(imports.importAaCkpointControl.cpCallingPgmId))).and(that(actionCheckpointRestart).attribute(actionCheckpointRestart.jobIdentifier).isEqualTo(valueOf(imports.importAaCkpointControl.cpJobNumber))) );
                exports.exportAaCkpointControl.cpProcessMode.setValue(TextAttribute.of("RM"));
                // INSERT RESTART LOGIC HERE
                // THE FOLLOWING SET OF "SET" STATEMENTS RESETS THE CONTROL RECORDS WITH THE INFORMATION STORED AT LAST CHECKPOINT. RETURNED DATA WILL BE USED BY THE CALLING PROCEDURE TO RESET EITHER THE DATABASE OR THE FILES.
                exports.outGroupFc.setSubscript(NumericAttribute.of(1));
                escape60435447: try (ReadEachIterator iterator60435447 = readEach(actionFileControl )
                        .distinctDefault()
                        .where( (that(actionFileControl).attribute(actionFileControl.procedureIdentifier).isEqualTo(valueOf(exports.exportAaCkpointControl.cpCallingPgmId))).and(that(actionFileControl).attribute(actionFileControl.jobIdentifier).isEqualTo(valueOf(exports.exportAaCkpointControl.cpJobNumber))))
                        .orderedBy()
                        .targeting()) {
                    while (iterator60435447.hasNext()) {
                        iterator60435447.next();
                        exports.outGroupFc.getCurrent().exportAaFileControl.fcIoCallProcId.setValue(actionFileControl.callingProcedureIdentifier);
                        exports.outGroupFc.getCurrent().exportAaFileControl.fcIoFileModId.setValue(actionFileControl.moduleIdentifier);
                        exports.outGroupFc.getCurrent().exportAaFileControl.fcIoFileReturn.setValue(actionFileControl.statusReturnCode);
                        exports.outGroupFc.getCurrent().exportAaFileControl.fcIoFileStatus.setValue(actionFileControl.statusCode);
                        exports.outGroupFc.getCurrent().exportAaFileControl.fcIoFileType.setValue(actionFileControl.typeCode);
                        exports.outGroupFc.getCurrent().exportAaFileControl.fcIoRequestCode.setValue(actionFileControl.requestCode);
                        exports.outGroupFc.getCurrent().exportAaFileControl.fcIoReturnCode.setValue(actionFileControl.returnCode);
                        exports.outGroupFc.getCurrent().exportAaFileControl.fcIoRstrtCount.setValue(actionFileControl.lineRestartCount);
                        exports.outGroupFc.setSubscript(exports.outGroupFc.getSubscript().plus(NumericAttribute.of(1)));
                    }
                }
                exports.exportAaCkpointControl.cpDbRepoData.setValue(actionCheckpointRestart.databaseRepositionText);

                escape60435462:
                if (getExitState().equals(TaTechnicalArchitecture.TA186_B_ERROR_EXISTS)) {
                    return;
                }
            } catch (NotFoundException e60492000) {
                // INSERT START LOGIC HERE
                escape60435461:
                if (getExitState().equals(TaTechnicalArchitecture.TA186_B_ERROR_EXISTS)) {
                    return;
                }
                exports.exportAaCkpointControl.cpProcessMode.setValue(TextAttribute.of("NM"));
                escape60491997: try {
                    create(actionHistory)
                        .set(actionHistory -> actionHistory.startTimestamp).to(getCurrentTimestamp())
                        .set(actionHistory -> actionHistory.procedureIdentifier).to(exports.exportAaCkpointControl.cpCallingPgmId)
                        .set(actionHistory -> actionHistory.jobIdentifier).to(exports.exportAaCkpointControl.cpJobNumber)
                        .associateWith(actionProgramNumber).which(ProgramNumber.hasHistory())
                    .done();
                    setExitState(TaTechnicalArchitecture.TA503_I_CHECKPOINT_SUCCESS);
                } catch (AlreadyExistsException e60491997) {
                    throw new GenAbortException(e60491997);
                } catch (PermittedValueViolation e60491997) {
                    throw new GenAbortException(e60491997);
                }
            }
        } else {
            escape60435452:
            if (imports.importAaCkpointControl.cpRequestCode.equals(TextAttribute.of("CP"))) {
                // INSERT CHECKPOINT LOGIC HERE

                escape60492003:
                try {
                    read( actionCheckpointRestart ).allowMultiple().where(
                        (that(actionCheckpointRestart).attribute(actionCheckpointRestart.procedureIdentifier).isEqualTo(valueOf(imports.importAaCkpointControl.cpCallingPgmId))).and(that(actionCheckpointRestart).attribute(actionCheckpointRestart.jobIdentifier).isEqualTo(valueOf(imports.importAaCkpointControl.cpJobNumber))) );
                    actionIefSupplied.flag.setValue(TextAttribute.of("N"));
                    exports.outGroupFc.setSubscript(NumericAttribute.of(1));
                    escape60435448: try (ReadEachIterator iterator60435448 = readEach(actionFileControl )
                            .distinctDefault()
                            .where( (that(actionFileControl).attribute(actionFileControl.procedureIdentifier).isEqualTo(valueOf(exports.outGroupFc.getCurrent().exportAaFileControl.fcIoCallProcId))).and(that(actionFileControl).attribute(actionFileControl.jobIdentifier).isEqualTo(valueOf(exports.exportAaCkpointControl.cpJobNumber))))
                            .orderedBy()
                            .targeting()) {
                        while (iterator60435448.hasNext()) {
                            iterator60435448.next();
                            actionIefSupplied.flag.setValue(TextAttribute.of("Y"));
                            escape60491993: try {
                                update(actionFileControl)
                                    .set(actionFileControl -> actionFileControl.callingProcedureIdentifier).to(exports.outGroupFc.getCurrent().exportAaFileControl.fcIoCallProcId)
                                    .set(actionFileControl -> actionFileControl.moduleIdentifier).to(exports.outGroupFc.getCurrent().exportAaFileControl.fcIoFileModId)
                                    .set(actionFileControl -> actionFileControl.statusReturnCode).to(exports.outGroupFc.getCurrent().exportAaFileControl.fcIoFileReturn)
                                    .set(actionFileControl -> actionFileControl.statusCode).to(exports.outGroupFc.getCurrent().exportAaFileControl.fcIoFileStatus)
                                    .set(actionFileControl -> actionFileControl.typeCode).to(exports.outGroupFc.getCurrent().exportAaFileControl.fcIoFileType)
                                    .set(actionFileControl -> actionFileControl.requestCode).to(exports.outGroupFc.getCurrent().exportAaFileControl.fcIoRequestCode)
                                    .set(actionFileControl -> actionFileControl.returnCode).to(exports.outGroupFc.getCurrent().exportAaFileControl.fcIoReturnCode)
                                    .set(actionFileControl -> actionFileControl.lineRestartCount).to(exports.outGroupFc.getCurrent().exportAaFileControl.fcIoRstrtCount)
                                .done();
                                exports.outGroupFc.setSubscript(exports.outGroupFc.getSubscript().plus(NumericAttribute.of(1)));
                            } catch (AlreadyExistsException e60491993) {
                            } catch (PermittedValueViolation e60491993) {
                            }
                        }
                    }
                    escape60435449:
                    if (actionIefSupplied.flag.equals(TextAttribute.of("N"))) {
                        exports.outGroupFc.initializeSubscript(NumericAttribute.of(1));
                        escape60435450:
                        for (NumericAttribute i60435450 = NumericAttribute.of(20); exports.outGroupFc.getSubscript().lessThanOrEqual(i60435450) && exports.outGroupFc.getSubscript().lessThanOrEqual(exports.outGroupFc.getMaxSubscript()) && exports.outGroupFc.subscriptIsValid(); exports.outGroupFc.incrementSubscriptBy(NumericAttribute.of(1))) {
                            exports.outGroupFc.updateLastSubscript();
                            escape60435451:
                            if (exports.outGroupFc.getCurrent().exportAaFileControl.fcIoFileModId.equals(TextAttribute.of(Constant.SPACES))) {
                                break escape60435449;
                            }
                            actionIefSupplied.count.setValueRounded(exports.outGroupFc.getSubscript());
                            escape60491994: try {
                                create(actionFileControl)
                                    .set(actionFileControl -> actionFileControl.procedureIdentifier).to(exports.outGroupFc.getCurrent().exportAaFileControl.fcIoCallProcId)
                                    .set(actionFileControl -> actionFileControl.jobIdentifier).to(exports.exportAaCkpointControl.cpJobNumber)
                                    .set(actionFileControl -> actionFileControl.count).to(actionIefSupplied.count)
                                    .set(actionFileControl -> actionFileControl.moduleIdentifier).to(exports.outGroupFc.getCurrent().exportAaFileControl.fcIoFileModId)
                                    .set(actionFileControl -> actionFileControl.callingProcedureIdentifier).to(exports.outGroupFc.getCurrent().exportAaFileControl.fcIoCallProcId)
                                    .set(actionFileControl -> actionFileControl.statusReturnCode).to(exports.outGroupFc.getCurrent().exportAaFileControl.fcIoFileReturn)
                                    .set(actionFileControl -> actionFileControl.statusCode).to(exports.outGroupFc.getCurrent().exportAaFileControl.fcIoFileStatus)
                                    .set(actionFileControl -> actionFileControl.typeCode).to(exports.outGroupFc.getCurrent().exportAaFileControl.fcIoFileType)
                                    .set(actionFileControl -> actionFileControl.requestCode).to(exports.outGroupFc.getCurrent().exportAaFileControl.fcIoRequestCode)
                                    .set(actionFileControl -> actionFileControl.returnCode).to(exports.outGroupFc.getCurrent().exportAaFileControl.fcIoReturnCode)
                                    .set(actionFileControl -> actionFileControl.lineRestartCount).to(exports.outGroupFc.getCurrent().exportAaFileControl.fcIoRstrtCount)
                                    .associateWith(actionCheckpointRestart).which(CheckpointRestart.hasFileControl())
                                .done();
                            } catch (AlreadyExistsException e60491994) {
                            } catch (PermittedValueViolation e60491994) {
                            }
                        }
                        exports.outGroupFc.capSubscript();
                    }
                    escape60492007: try {
                        update(actionCheckpointRestart)
                            .set(actionCheckpointRestart -> actionCheckpointRestart.createTimestamp).to(getCurrentTimestamp())
                            .set(actionCheckpointRestart -> actionCheckpointRestart.databaseRepositionText).to(imports.importAaCkpointControl.cpDbRepoData)
                        .done();
                        setExitState(TaTechnicalArchitecture.TA503_I_CHECKPOINT_SUCCESS);
                    } catch (AlreadyExistsException e60492007) {
                        setExitState(TaTechnicalArchitecture.TA186_B_ERROR_EXISTS);
                    } catch (PermittedValueViolation e60492007) {
                        setExitState(TaTechnicalArchitecture.TA186_B_ERROR_EXISTS);
                    }
                    escape60435460:
                    if (getExitState().equals(TaTechnicalArchitecture.TA186_B_ERROR_EXISTS)) {
                        return;
                    }
                } catch (NotFoundException e60492003) {
                    escape60492002: try {
                        create(actionCheckpointRestart)
                            .set(actionCheckpointRestart -> actionCheckpointRestart.procedureIdentifier).to(imports.importAaCkpointControl.cpCallingPgmId)
                            .set(actionCheckpointRestart -> actionCheckpointRestart.jobIdentifier).to(imports.importAaCkpointControl.cpJobNumber)
                            .set(actionCheckpointRestart -> actionCheckpointRestart.databaseRepositionText).to(imports.importAaCkpointControl.cpDbRepoData)
                            .set(actionCheckpointRestart -> actionCheckpointRestart.createTimestamp).to(getCurrentTimestamp())
                            .associateWith(actionProgramNumber).which(ProgramNumber.hasCheckpointRestart())
                        .done();
                        exports.outGroupFc.initializeSubscript(NumericAttribute.of(1));
                        escape60435455:
                        for (NumericAttribute i60435455 = NumericAttribute.of(20); exports.outGroupFc.getSubscript().lessThanOrEqual(i60435455) && exports.outGroupFc.getSubscript().lessThanOrEqual(exports.outGroupFc.getMaxSubscript()) && exports.outGroupFc.subscriptIsValid(); exports.outGroupFc.incrementSubscriptBy(NumericAttribute.of(1))) {
                            exports.outGroupFc.updateLastSubscript();
                            escape60435456:
                            if (exports.outGroupFc.getCurrent().exportAaFileControl.fcIoFileModId.equals(TextAttribute.of(Constant.SPACES))) {
                                break escape60435455;
                            }
                            actionIefSupplied.count.setValueRounded(exports.outGroupFc.getSubscript());
                            escape60492008: try {
                                create(actionFileControl)
                                    .set(actionFileControl -> actionFileControl.procedureIdentifier).to(exports.outGroupFc.getCurrent().exportAaFileControl.fcIoCallProcId)
                                    .set(actionFileControl -> actionFileControl.jobIdentifier).to(exports.exportAaCkpointControl.cpJobNumber)
                                    .set(actionFileControl -> actionFileControl.count).to(actionIefSupplied.count)
                                    .set(actionFileControl -> actionFileControl.moduleIdentifier).to(exports.outGroupFc.getCurrent().exportAaFileControl.fcIoFileModId)
                                    .set(actionFileControl -> actionFileControl.callingProcedureIdentifier).to(exports.outGroupFc.getCurrent().exportAaFileControl.fcIoCallProcId)
                                    .set(actionFileControl -> actionFileControl.statusReturnCode).to(exports.outGroupFc.getCurrent().exportAaFileControl.fcIoFileReturn)
                                    .set(actionFileControl -> actionFileControl.statusCode).to(exports.outGroupFc.getCurrent().exportAaFileControl.fcIoFileStatus)
                                    .set(actionFileControl -> actionFileControl.typeCode).to(exports.outGroupFc.getCurrent().exportAaFileControl.fcIoFileType)
                                    .set(actionFileControl -> actionFileControl.requestCode).to(exports.outGroupFc.getCurrent().exportAaFileControl.fcIoRequestCode)
                                    .set(actionFileControl -> actionFileControl.returnCode).to(exports.outGroupFc.getCurrent().exportAaFileControl.fcIoReturnCode)
                                    .set(actionFileControl -> actionFileControl.lineRestartCount).to(exports.outGroupFc.getCurrent().exportAaFileControl.fcIoRstrtCount)
                                    .associateWith(actionCheckpointRestart).which(CheckpointRestart.hasFileControl())
                                .done();
                            } catch (AlreadyExistsException e60492008) {
                                setExitState(TaTechnicalArchitecture.TA186_B_ERROR_EXISTS);
                                return;
                            } catch (PermittedValueViolation e60492008) {
                            }
                        }
                        exports.outGroupFc.capSubscript();
                    } catch (AlreadyExistsException e60492002) {
                        setExitState(TaTechnicalArchitecture.TA186_B_ERROR_EXISTS);
                        return;
                    } catch (PermittedValueViolation e60492002) {
                    }
                }
            } else {
                // INSERT WRAPUP LOGIC HERE


                escape60492009:
                try {
                    read( actionCheckpointRestart ).allowMultiple().where(
                        (that(actionCheckpointRestart).attribute(actionCheckpointRestart.procedureIdentifier).isEqualTo(valueOf(imports.importAaCkpointControl.cpCallingPgmId))).and(that(actionCheckpointRestart).attribute(actionCheckpointRestart.jobIdentifier).isEqualTo(valueOf(imports.importAaCkpointControl.cpJobNumber))) );
                    delete(actionCheckpointRestart);
                } catch (NotFoundException e60492009) {
                }
                escape60435459: try (ReadEachIterator iterator60435459 = readEach(actionHistory )
                        .distinctDefault()
                        .where( ((that(actionHistory).attribute(actionHistory.procedureIdentifier).isEqualTo(valueOf(exports.exportAaCkpointControl.cpCallingPgmId))).and(that(actionHistory).attribute(actionHistory.jobIdentifier).isEqualTo(valueOf(exports.exportAaCkpointControl.cpJobNumber)))).and(that(actionHistory).attribute(actionHistory.startTimestamp).isLessThan(valueOf(getCurrentTimestamp()))))
                        .orderedBy(ascending(desired(actionHistory).attribute(actionHistory.endTimestamp)) , descending(desired(actionHistory).attribute(actionHistory.startTimestamp)) )
                        .targeting()) {
                    while (iterator60435459.hasNext()) {
                        iterator60435459.next();
                        escape60492012: try {
                            update(actionHistory)
                                .set(actionHistory -> actionHistory.endTimestamp).to(getCurrentTimestamp())
                            .done();
                            break escape60435459;
                        } catch (AlreadyExistsException e60492012) {
                        } catch (PermittedValueViolation e60492012) {
                        }
                    }
                }
            }
        }
    }


    @Override
    public void setImports(Imports imports) {
        this.imports = imports;
    }

    @Override
    public Imports getImports() {
        return this.imports;
    }

    @Override
    public Exports getExports() {
        return this.exports;
    }
}