package gov.nm.cses.gen.actions;

import static com.innowake.gen.Functions.*;

import com.innowake.gen.*;
import com.innowake.gen.attributes.*;
import com.innowake.gen.utils.*;
import gov.nm.cses.gen.globals.*;
import gov.nm.cses.gen.globals.exitstate.*;

import static gov.nm.cses.gen.globals.GlobalCommand.*;

import gov.nm.cses.gen.entities.*;

/**
  * This module will be called by all batch 
  * 
  * processes to update the batch parameter each day with a new batch 
  * processing date.
  */ 
public final class TaeUpdateBatchParameter extends IntermediateAction<TaeUpdateBatchParameter.Imports, TaeUpdateBatchParameter.Exports> {

    /**
      * This module will be called by all batch 
      * 
      * processes to update the batch parameter each day with a new batch 
      * processing date.
      */ 
    public static final class Imports extends ImportContainer {

         
        public static final class InputBatchParameter extends EntityView<BatchParameter > {
             public BatchParameter.ProcessIdentifier processIdentifier = new BatchParameter.ProcessIdentifier();
             public BatchParameter.FormatIdentifier formatIdentifier = new BatchParameter.FormatIdentifier();
             public BatchParameter.BatchEffectiveDate batchEffectiveDate = new BatchParameter.BatchEffectiveDate();
             public BatchParameter.ReportName reportName = new BatchParameter.ReportName();
             public BatchParameter.ReportIdentifier reportIdentifier = new BatchParameter.ReportIdentifier();
             public BatchParameter.RequestIndicator requestIndicator = new BatchParameter.RequestIndicator();
             public BatchParameter.CompressionIdentifier compressionIdentifier = new BatchParameter.CompressionIdentifier();
        }

        public final InputBatchParameter inputBatchParameter = new InputBatchParameter();
    }

    public static final class Exports extends ExportContainer {


    }

    private Imports imports = new Imports();
    private Exports exports = new Exports();

     
    public static final class ActionBatchParameter extends PersistentEntityView<BatchParameter > {
         public BatchParameter.ProcessIdentifier processIdentifier = new BatchParameter.ProcessIdentifier();
         public BatchParameter.FormatIdentifier formatIdentifier = new BatchParameter.FormatIdentifier();
         public BatchParameter.BatchEffectiveDate batchEffectiveDate = new BatchParameter.BatchEffectiveDate();
         public BatchParameter.ReportName reportName = new BatchParameter.ReportName();
         public BatchParameter.ReportIdentifier reportIdentifier = new BatchParameter.ReportIdentifier();
         public BatchParameter.RequestIndicator requestIndicator = new BatchParameter.RequestIndicator();
         public BatchParameter.CompressionIdentifier compressionIdentifier = new BatchParameter.CompressionIdentifier();
    }
    public final ActionBatchParameter actionBatchParameter = new ActionBatchParameter();

    @Override
    public void run() {
        // ---------------------------------------------
        // ANDERSEN CONSULTING
        // 
        // Initial Coding		R. Dale Stafford
        // 01/27/1995
        // 
        // Where Used:
        // All batch procedures
        // 
        // Modifications:
        // ---------------------------------------------


        escape60494166:
        try {
            read( actionBatchParameter ).allowMultiple().where(
                that(actionBatchParameter).attribute(actionBatchParameter.processIdentifier).isEqualTo(valueOf(imports.inputBatchParameter.processIdentifier)) );
            escape60494168: try {
                update(actionBatchParameter)
                    .set(actionBatchParameter -> actionBatchParameter.formatIdentifier).to(imports.inputBatchParameter.formatIdentifier)
                    .set(actionBatchParameter -> actionBatchParameter.batchEffectiveDate).to(imports.inputBatchParameter.batchEffectiveDate)
                    .set(actionBatchParameter -> actionBatchParameter.reportName).to(imports.inputBatchParameter.reportName)
                    .set(actionBatchParameter -> actionBatchParameter.reportIdentifier).to(imports.inputBatchParameter.reportIdentifier)
                    .set(actionBatchParameter -> actionBatchParameter.requestIndicator).to(imports.inputBatchParameter.requestIndicator)
                    .set(actionBatchParameter -> actionBatchParameter.compressionIdentifier).to(imports.inputBatchParameter.compressionIdentifier)
                .done();
                setExitState(AaAdsCommonObjects.AA541_I_SUCCESSFUL_UPDATE);
            } catch (AlreadyExistsException e60494168) {
                setExitState(TaTechnicalArchitecture.TA171_E_BATCH_PARAMETER_AE);
            } catch (PermittedValueViolation e60494168) {
                setExitState(TaTechnicalArchitecture.TA172_E_BATCH_PARAMTER_PV);
            }
        } catch (NotFoundException e60494166) {
            setExitState(TaTechnicalArchitecture.TA169_E_BATCH_PARAMTER_NF);
        }
    }


    @Override
    public void setImports(Imports imports) {
        this.imports = imports;
    }

    @Override
    public Imports getImports() {
        return this.imports;
    }

    @Override
    public Exports getExports() {
        return this.exports;
    }
}