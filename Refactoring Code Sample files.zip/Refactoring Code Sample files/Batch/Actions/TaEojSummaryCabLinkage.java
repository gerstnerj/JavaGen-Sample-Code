package gov.nm.cses.gen.actions;

import com.innowake.gen.cobol.LinkageSection;
import com.innowake.gen.cobol.storage.*;
import com.innowake.gen.cobol.storage.ExportStorage;
import com.innowake.gen.cobol.storage.ImportStorage;
import com.innowake.gen.cobol.storage.Storage;
import java.util.ArrayList;

public class TaEojSummaryCabLinkage extends LinkageSection {

    public TaEojSummaryCabLinkage(TaEojSummaryCab genActionBlock) {
        this.highPerformanceViewMatching = false;
        this.generateMissingFlags = true;
        TaEojSummaryCab.Imports imports = genActionBlock.getImports();
        TaEojSummaryCab.Exports exports = genActionBlock.getExports();
        this.globals.add(GlobalStorage.builder(genActionBlock.getGlobal()));

        this.imports.add(ImportStorage.builder(imports)
            .entity(e -> e.inputAaRebuildFiles)
                .textAttribute(e -> e.rebuildFlag)
            .endEntity()
            .entity(e -> e.inputTa0022EojSummaryFields)
                .textAttribute(e -> e.fileMode)
                .textAttribute(e -> e.programId)
                .textAttribute(e -> e.controlAreaType)
                .textAttribute(e -> e.filename)
                .textAttribute(e -> e.controlType)
                .textAttribute(e -> e.format)
                .numericAttribute(e -> e.expectedValue)
                .numericAttribute(e -> e.actualValue)
                .textAttribute(e -> e.difference)
                .textAttribute(e -> e.previousAreaType)
                .textAttribute(e -> e.previousFilename)
                .textAttribute(e -> e.problemOpeningDoc)
                .textAttribute(e -> e.problemWritingDoc)
                .textAttribute(e -> e.noRecordsDoc)
                .textAttribute(e -> e.noMatchDoc)
                .textAttribute(e -> e.firstTime)
            .endEntity()
        );

        this.exports.add(ExportStorage.builder(exports)
            .entity(e -> e.outputAaRebuildFiles)
                .textAttribute(e -> e.rebuildFlag)
            .endEntity()
            .entity(e -> e.outputTa0022EojSummaryFields)
                .numericAttribute(e -> e.returnCode)
                .textAttribute(e -> e.previousAreaType)
                .textAttribute(e -> e.previousFilename)
            .endEntity()
        );

    }
}