package gov.nm.cses.gen.actions;

import static com.innowake.gen.Functions.*;

import com.innowake.gen.*;
import com.innowake.gen.attributes.*;
import com.innowake.gen.utils.*;
import com.innowake.gen.annotation.ExternalActionBlock;
import com.innowake.gen.annotation.ExternalActionBlock.GenerateMissingFlags;
import gov.nm.cses.gen.globals.*;
import gov.nm.cses.gen.globals.exitstate.*;

import static gov.nm.cses.gen.globals.GlobalCommand.*;

import gov.nm.cses.gen.entities.*;
import com.innowake.gen.integration.MeeIntegrationBean;
import gov.nm.cses.gen.eab.HSTAACRC;

 
@ExternalActionBlock(generateMissingFlags = GenerateMissingFlags.TRUE)
public final class TaEojSummaryCab extends IntermediateAction<TaEojSummaryCab.Imports, TaEojSummaryCab.Exports> {

     
    public static final class Imports extends ImportContainer {

         
        public static final class InputAaRebuildFiles extends EntityView<AaRebuildFiles > {
             public AaRebuildFiles.RebuildFlag rebuildFlag = new AaRebuildFiles.RebuildFlag();
        }
         
        public static final class InputTa0022EojSummaryFields extends EntityView<Ta0022EojSummaryFields > {
             public Ta0022EojSummaryFields.FileMode fileMode = new Ta0022EojSummaryFields.FileMode();
             public Ta0022EojSummaryFields.ProgramId programId = new Ta0022EojSummaryFields.ProgramId();
             public Ta0022EojSummaryFields.ControlAreaType controlAreaType = new Ta0022EojSummaryFields.ControlAreaType();
             public Ta0022EojSummaryFields.Filename filename = new Ta0022EojSummaryFields.Filename();
             public Ta0022EojSummaryFields.ControlType controlType = new Ta0022EojSummaryFields.ControlType();
             public Ta0022EojSummaryFields.Format format = new Ta0022EojSummaryFields.Format();
             public Ta0022EojSummaryFields.ExpectedValue expectedValue = new Ta0022EojSummaryFields.ExpectedValue();
             public Ta0022EojSummaryFields.ActualValue actualValue = new Ta0022EojSummaryFields.ActualValue();
             public Ta0022EojSummaryFields.Difference difference = new Ta0022EojSummaryFields.Difference();
             public Ta0022EojSummaryFields.PreviousAreaType previousAreaType = new Ta0022EojSummaryFields.PreviousAreaType();
             public Ta0022EojSummaryFields.PreviousFilename previousFilename = new Ta0022EojSummaryFields.PreviousFilename();
             public Ta0022EojSummaryFields.ProblemOpeningDoc problemOpeningDoc = new Ta0022EojSummaryFields.ProblemOpeningDoc();
             public Ta0022EojSummaryFields.ProblemWritingDoc problemWritingDoc = new Ta0022EojSummaryFields.ProblemWritingDoc();
             public Ta0022EojSummaryFields.NoRecordsDoc noRecordsDoc = new Ta0022EojSummaryFields.NoRecordsDoc();
             public Ta0022EojSummaryFields.NoMatchDoc noMatchDoc = new Ta0022EojSummaryFields.NoMatchDoc();
             public Ta0022EojSummaryFields.FirstTime firstTime = new Ta0022EojSummaryFields.FirstTime();
        }

        public final InputAaRebuildFiles inputAaRebuildFiles = new InputAaRebuildFiles();
        public final InputTa0022EojSummaryFields inputTa0022EojSummaryFields = new InputTa0022EojSummaryFields();
    }

    public static final class Exports extends ExportContainer {

         
        public static final class OutputAaRebuildFiles extends EntityView<AaRebuildFiles > {
             public AaRebuildFiles.RebuildFlag rebuildFlag = new AaRebuildFiles.RebuildFlag();
        }
         
        public static final class OutputTa0022EojSummaryFields extends EntityView<Ta0022EojSummaryFields > {
             public Ta0022EojSummaryFields.ReturnCode returnCode = new Ta0022EojSummaryFields.ReturnCode();
             public Ta0022EojSummaryFields.PreviousAreaType previousAreaType = new Ta0022EojSummaryFields.PreviousAreaType();
             public Ta0022EojSummaryFields.PreviousFilename previousFilename = new Ta0022EojSummaryFields.PreviousFilename();
        }

        public final OutputAaRebuildFiles outputAaRebuildFiles = new OutputAaRebuildFiles();
        public final OutputTa0022EojSummaryFields outputTa0022EojSummaryFields = new OutputTa0022EojSummaryFields();
    }

    private Imports imports = new Imports();
    private Exports exports = new Exports();



    @Override
    public void run() {
        MeeIntegrationBean integrationBean = getGlobal().getMeeIntegrationBean();
        integrationBean.runProgram(HSTAACRC.class, integrationBean.getLinkage(this));
    }

    @Override
    public void setImports(Imports imports) {
        this.imports = imports;
    }

    @Override
    public Imports getImports() {
        return this.imports;
    }

    @Override
    public Exports getExports() {
        return this.exports;
    }
}