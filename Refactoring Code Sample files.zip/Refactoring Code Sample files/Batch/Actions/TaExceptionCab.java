package gov.nm.cses.gen.actions;

import static com.innowake.gen.Functions.*;

import com.innowake.gen.*;
import com.innowake.gen.attributes.*;
import com.innowake.gen.utils.*;
import com.innowake.gen.annotation.ExternalActionBlock;
import com.innowake.gen.annotation.ExternalActionBlock.GenerateMissingFlags;
import gov.nm.cses.gen.globals.*;
import gov.nm.cses.gen.globals.exitstate.*;

import static gov.nm.cses.gen.globals.GlobalCommand.*;

import gov.nm.cses.gen.entities.*;
import com.innowake.gen.integration.MeeIntegrationBean;
import gov.nm.cses.gen.eab.HSTAACSC;

 
@ExternalActionBlock(generateMissingFlags = GenerateMissingFlags.TRUE)
public final class TaExceptionCab extends IntermediateAction<TaExceptionCab.Imports, TaExceptionCab.Exports> {

     
    public static final class Imports extends ImportContainer {

         
        public static final class InputAaRebuildFiles extends EntityView<AaRebuildFiles > {
             public AaRebuildFiles.RebuildFlag rebuildFlag = new AaRebuildFiles.RebuildFlag();
        }
         
        public static final class InputTa0027ExceptionFields extends EntityView<Ta0027ExceptionFields > {
             public Ta0027ExceptionFields.FileMode fileMode = new Ta0027ExceptionFields.FileMode();
             public Ta0027ExceptionFields.ProgramId programId = new Ta0027ExceptionFields.ProgramId();
             public Ta0027ExceptionFields.RecordKeyName recordKeyName = new Ta0027ExceptionFields.RecordKeyName();
             public Ta0027ExceptionFields.RecordKeyValue recordKeyValue = new Ta0027ExceptionFields.RecordKeyValue();
             public Ta0027ExceptionFields.SourceCode sourceCode = new Ta0027ExceptionFields.SourceCode();
             public Ta0027ExceptionFields.ErrorCode errorCode = new Ta0027ExceptionFields.ErrorCode();
             public Ta0027ExceptionFields.ErrorDescription errorDescription = new Ta0027ExceptionFields.ErrorDescription();
        }

        public final InputAaRebuildFiles inputAaRebuildFiles = new InputAaRebuildFiles();
        public final InputTa0027ExceptionFields inputTa0027ExceptionFields = new InputTa0027ExceptionFields();
    }

    public static final class Exports extends ExportContainer {

         
        public static final class OutputTa0027ExceptionFields extends EntityView<Ta0027ExceptionFields > {
             public Ta0027ExceptionFields.ReturnCode returnCode = new Ta0027ExceptionFields.ReturnCode();
        }

        public final OutputTa0027ExceptionFields outputTa0027ExceptionFields = new OutputTa0027ExceptionFields();
    }

    private Imports imports = new Imports();
    private Exports exports = new Exports();



    @Override
    public void run() {
        MeeIntegrationBean integrationBean = getGlobal().getMeeIntegrationBean();
        integrationBean.runProgram(HSTAACSC.class, integrationBean.getLinkage(this));
    }

    @Override
    public void setImports(Imports imports) {
        this.imports = imports;
    }

    @Override
    public Imports getImports() {
        return this.imports;
    }

    @Override
    public Exports getExports() {
        return this.exports;
    }
}