package gov.nm.cses.gen.actions;

import static com.innowake.gen.Functions.*;

import com.innowake.gen.*;
import com.innowake.gen.attributes.*;
import com.innowake.gen.utils.*;
import gov.nm.cses.gen.globals.*;
import gov.nm.cses.gen.globals.exitstate.*;

import static gov.nm.cses.gen.globals.GlobalCommand.*;

import gov.nm.cses.gen.entities.*;

 
public final class AaConvertDateToText extends IntermediateAction<AaConvertDateToText.Imports, AaConvertDateToText.Exports> {

     
    public static final class Imports extends ImportContainer {

         
        public static final class InputAa0003ValidatedDates extends EntityView<Aa0003ValidatedDates > {
             public Aa0003ValidatedDates.Date1 date1 = new Aa0003ValidatedDates.Date1();
        }

        public final InputAa0003ValidatedDates inputAa0003ValidatedDates = new InputAa0003ValidatedDates();
    }

    public static final class Exports extends ExportContainer {

         
        public static final class OutputAa0003ValidatedDates extends EntityView<Aa0003ValidatedDates > {
             public Aa0003ValidatedDates.TextDays textDays = new Aa0003ValidatedDates.TextDays();
             public Aa0003ValidatedDates.TextMonth textMonth = new Aa0003ValidatedDates.TextMonth();
             public Aa0003ValidatedDates.TextYearYyyy textYearYyyy = new Aa0003ValidatedDates.TextYearYyyy();
             public Aa0003ValidatedDates.TextYearYy textYearYy = new Aa0003ValidatedDates.TextYearYy();
             public Aa0003ValidatedDates.ReturnCode returnCode = new Aa0003ValidatedDates.ReturnCode();
        }

        public final OutputAa0003ValidatedDates outputAa0003ValidatedDates = new OutputAa0003ValidatedDates();
    }

    private Imports imports = new Imports();
    private Exports exports = new Exports();

     
    public static final class LocalTextDateAaVarText extends EntityView<AaVarText >  {
         public AaVarText.TextLength8 textLength8 = new AaVarText.TextLength8();
    }
     
    public static final class LocalAa0003ValidatedDates extends EntityView<Aa0003ValidatedDates >  {
         public Aa0003ValidatedDates.Date1 date1 = new Aa0003ValidatedDates.Date1();
    }
    public final LocalTextDateAaVarText localTextDateAaVarText = new LocalTextDateAaVarText();
    public final LocalAa0003ValidatedDates localAa0003ValidatedDates = new LocalAa0003ValidatedDates();

    @Override
    public void run() {
        // ---------------------------------------------
        // ANDERSEN CONSULTING
        // 28 JANUARY, 1994
        // R. Dale Stafford
        // ---------------------------------------------
        // ---------------------------------------------
        // Use work set WS0003_Validated_Dates
        // ---------------------------------------------
        // ---------------------------------------------
        // This module takes the date value in DATE_1
        // and break it into its year, month, and day
        // components.  These values will be placed in
        // the attributes text_year_yyyy, text_year_yy,
        // text_month, and text_days of the work set.
        // ---------------------------------------------


        escape60444568:
        if (imports.inputAa0003ValidatedDates.date1.equals(datenum(NumericAttribute.of(0)))) {
            exports.outputAa0003ValidatedDates.textDays.setValue(TextAttribute.of(Constant.SPACES));
            exports.outputAa0003ValidatedDates.textMonth.setValue(TextAttribute.of(Constant.SPACES));
            exports.outputAa0003ValidatedDates.textYearYy.setValue(TextAttribute.of(Constant.SPACES));
            exports.outputAa0003ValidatedDates.textYearYyyy.setValue(TextAttribute.of(Constant.SPACES));

        } else {
            exports.outputAa0003ValidatedDates.textYearYyyy.setValue(substr(textnum(year(imports.inputAa0003ValidatedDates.date1)), NumericAttribute.of(12), NumericAttribute.of(4)));
            exports.outputAa0003ValidatedDates.textYearYy.setValue(substr(textnum(year(imports.inputAa0003ValidatedDates.date1)), NumericAttribute.of(14), NumericAttribute.of(4)));
            exports.outputAa0003ValidatedDates.textMonth.setValue(substr(textnum(month(imports.inputAa0003ValidatedDates.date1)), NumericAttribute.of(14), NumericAttribute.of(2)));
            exports.outputAa0003ValidatedDates.textDays.setValue(substr(textnum(day(imports.inputAa0003ValidatedDates.date1)), NumericAttribute.of(14), NumericAttribute.of(2)));
        }
        exports.outputAa0003ValidatedDates.returnCode.setValue(TextAttribute.of("0"));

    }


    @Override
    public void setImports(Imports imports) {
        this.imports = imports;
    }

    @Override
    public Imports getImports() {
        return this.imports;
    }

    @Override
    public Exports getExports() {
        return this.exports;
    }
}