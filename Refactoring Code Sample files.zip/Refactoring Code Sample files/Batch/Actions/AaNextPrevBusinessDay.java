package gov.nm.cses.gen.actions;

import static com.innowake.gen.Functions.*;

import com.innowake.gen.*;
import com.innowake.gen.attributes.*;
import com.innowake.gen.utils.*;
import gov.nm.cses.gen.globals.*;
import gov.nm.cses.gen.globals.exitstate.*;

import static gov.nm.cses.gen.globals.GlobalCommand.*;

import gov.nm.cses.gen.entities.*;

 
public final class AaNextPrevBusinessDay extends IntermediateAction<AaNextPrevBusinessDay.Imports, AaNextPrevBusinessDay.Exports> {

     
    public static final class Imports extends ImportContainer {

         
        public static final class InputAa0009NextPrevBusinessDay extends EntityView<Aa0009NextPrevBusinessDay > {
             public Aa0009NextPrevBusinessDay.Indicator indicator = new Aa0009NextPrevBusinessDay.Indicator();
             public Aa0009NextPrevBusinessDay.EnterDate enterDate = new Aa0009NextPrevBusinessDay.EnterDate();
        }

        public final InputAa0009NextPrevBusinessDay inputAa0009NextPrevBusinessDay = new InputAa0009NextPrevBusinessDay();
    }

    public static final class Exports extends ExportContainer {

         
        public static final class OutputAa0009NextPrevBusinessDay extends EntityView<Aa0009NextPrevBusinessDay > {
             public Aa0009NextPrevBusinessDay.DayOfWeek dayOfWeek = new Aa0009NextPrevBusinessDay.DayOfWeek();
             public Aa0009NextPrevBusinessDay.ReturnCode returnCode = new Aa0009NextPrevBusinessDay.ReturnCode();
             public Aa0009NextPrevBusinessDay.ReturnedDate returnedDate = new Aa0009NextPrevBusinessDay.ReturnedDate();
        }

        public final OutputAa0009NextPrevBusinessDay outputAa0009NextPrevBusinessDay = new OutputAa0009NextPrevBusinessDay();
    }

    private Imports imports = new Imports();
    private Exports exports = new Exports();

     
    public static final class LocalDaysIefSupplied extends EntityView<IefSupplied >  {
         public IefSupplied.TotalInteger totalInteger = new IefSupplied.TotalInteger();
    }
     
    public static final class LocalIefSupplied extends EntityView<IefSupplied >  {
         public IefSupplied.Count count = new IefSupplied.Count();
         public IefSupplied.Flag flag = new IefSupplied.Flag();
    }
     
    public static final class LocalAa0009NextPrevBusinessDay extends EntityView<Aa0009NextPrevBusinessDay >  {
         public Aa0009NextPrevBusinessDay.TextDays textDays = new Aa0009NextPrevBusinessDay.TextDays();
         public Aa0009NextPrevBusinessDay.TextMonth textMonth = new Aa0009NextPrevBusinessDay.TextMonth();
         public Aa0009NextPrevBusinessDay.TextYear textYear = new Aa0009NextPrevBusinessDay.TextYear();
         public Aa0009NextPrevBusinessDay.DayOfWeek dayOfWeek = new Aa0009NextPrevBusinessDay.DayOfWeek();
         public Aa0009NextPrevBusinessDay.Indicator indicator = new Aa0009NextPrevBusinessDay.Indicator();
         public Aa0009NextPrevBusinessDay.ReturnCode returnCode = new Aa0009NextPrevBusinessDay.ReturnCode();
         public Aa0009NextPrevBusinessDay.EnterDate enterDate = new Aa0009NextPrevBusinessDay.EnterDate();
         public Aa0009NextPrevBusinessDay.ReturnedDate returnedDate = new Aa0009NextPrevBusinessDay.ReturnedDate();
    }
     
    public static final class ActionMasterCalendar extends PersistentEntityView<MasterCalendar > {
         public MasterCalendar.HolidayDate holidayDate = new MasterCalendar.HolidayDate();
    }
    public final LocalDaysIefSupplied localDaysIefSupplied = new LocalDaysIefSupplied();
    public final LocalIefSupplied localIefSupplied = new LocalIefSupplied();
    public final LocalAa0009NextPrevBusinessDay localAa0009NextPrevBusinessDay = new LocalAa0009NextPrevBusinessDay();
    public final ActionMasterCalendar actionMasterCalendar = new ActionMasterCalendar();

    @Override
    public void run() {
        // ---------------------------------------------
        // ANDERSEN CONSULTING
        // 2 FEBRUARY, 1994
        // R. Dale Stafford
        // 
        // Modifications:
        // ---------------------------------------------
        // ---------------------------------------------
        // This module computes the next or previous
        // business day from a date input by the user.
        // Because it checks against the master
        // calendar, the date must be converted to text
        // fields, as they are stored in this way on the
        // master calendar.  If the newly computed date
        // exists on the master calendar, or it is a
        // Saturday or Sunday, then the newly computed
        // date is not a valid business day, and the
        // next date is computed.
        // ---------------------------------------------


        exports.outputAa0009NextPrevBusinessDay.returnCode.setValue(TextAttribute.of("0"));
        localIefSupplied.flag.setValue(TextAttribute.of(Constant.SPACES));

        escape60434427:
        if (imports.inputAa0009NextPrevBusinessDay.indicator.equals(TextAttribute.of("N"))) {
            localIefSupplied.count.setValueRounded(NumericAttribute.of(1));
            escape60434428:continue60434428:
            while (! localIefSupplied.flag.equals(TextAttribute.of("1"))) {
                localDaysIefSupplied.totalInteger.setValueRounded(days(imports.inputAa0009NextPrevBusinessDay.enterDate).plus(localIefSupplied.count));
                // ---------------------------------------------
                // The local enter date attribute will hold all
                // temporary dates throughout the module until
                // a valid day is found
                // ---------------------------------------------
                localAa0009NextPrevBusinessDay.enterDate.setValue(datedays(localDaysIefSupplied.totalInteger));
                localAa0009NextPrevBusinessDay.dayOfWeek.setValue(dayofweek(localAa0009NextPrevBusinessDay.enterDate));
                // ---------------------------------------------
                // Saturday and Sunday are not valid business
                // days.  Try the next day.
                // ---------------------------------------------
                escape60434429:
                if (localAa0009NextPrevBusinessDay.dayOfWeek.equals(TextAttribute.of("SATURDAY")) || (localAa0009NextPrevBusinessDay.dayOfWeek.equals(TextAttribute.of("SUNDAY")))) {
                    localIefSupplied.count.setValueRounded(localIefSupplied.count.plus(NumericAttribute.of(1)));
                    continue continue60434428;
                } else {
                    // ---------------------------------------------
                    // Master Calendar contains all state holdiays
                    // ---------------------------------------------

                    escape60492375:
                    try {
                        read( actionMasterCalendar ).allowMultiple().where(
                            that(actionMasterCalendar).attribute(actionMasterCalendar.holidayDate).isEqualTo(valueOf(localAa0009NextPrevBusinessDay.enterDate)) );
                        // ---------------------------------------------
                        // If the date exists on the calendar, then it
                        // is a holdiay.  Try the next day
                        // ---------------------------------------------
                        localIefSupplied.count.setValueRounded(localIefSupplied.count.plus(NumericAttribute.of(1)));
                        continue continue60434428;
                    } catch (NotFoundException e60492375) {
                        // ---------------------------------------------
                        // If not Saturday and not Sunday and not on
                        // Master Calendar, then it is a valid business
                        // day
                        // ---------------------------------------------
                        localIefSupplied.flag.setValue(TextAttribute.of("1"));
                        exports.outputAa0009NextPrevBusinessDay.returnedDate.setValue(localAa0009NextPrevBusinessDay.enterDate);
                        exports.outputAa0009NextPrevBusinessDay.dayOfWeek.setValue(dayofweek(localAa0009NextPrevBusinessDay.enterDate));
                    }
                }
            }
        } else if (imports.inputAa0009NextPrevBusinessDay.indicator.equals(TextAttribute.of("P"))) {
            localIefSupplied.count.setValueRounded(NumericAttribute.of(-1));
            escape60434430:continue60434430:
            while (! localIefSupplied.flag.equals(TextAttribute.of("1"))) {
                localDaysIefSupplied.totalInteger.setValueRounded(days(imports.inputAa0009NextPrevBusinessDay.enterDate).plus(localIefSupplied.count));
                // ---------------------------------------------
                // The local enter date attribute will hold all
                // temporary dates throughout the module until
                // a valid day is found
                // ---------------------------------------------
                localAa0009NextPrevBusinessDay.enterDate.setValue(datedays(localDaysIefSupplied.totalInteger));
                localAa0009NextPrevBusinessDay.dayOfWeek.setValue(dayofweek(localAa0009NextPrevBusinessDay.enterDate));
                escape60434431:
                if (localAa0009NextPrevBusinessDay.dayOfWeek.equals(TextAttribute.of("SATURDAY")) || (localAa0009NextPrevBusinessDay.dayOfWeek.equals(TextAttribute.of("SUNDAY")))) {
                    localIefSupplied.count.setValueRounded(localIefSupplied.count.minus(NumericAttribute.of(1)));
                    continue continue60434430;
                } else {

                    escape60492371:
                    try {
                        read( actionMasterCalendar ).allowMultiple().where(
                            that(actionMasterCalendar).attribute(actionMasterCalendar.holidayDate).isEqualTo(valueOf(localAa0009NextPrevBusinessDay.enterDate)) );
                        localIefSupplied.count.setValueRounded(localIefSupplied.count.minus(NumericAttribute.of(1)));
                        continue continue60434430;
                    } catch (NotFoundException e60492371) {
                        localIefSupplied.flag.setValue(TextAttribute.of("1"));
                        exports.outputAa0009NextPrevBusinessDay.returnedDate.setValue(localAa0009NextPrevBusinessDay.enterDate);
                        exports.outputAa0009NextPrevBusinessDay.dayOfWeek.setValue(dayofweek(localAa0009NextPrevBusinessDay.enterDate));
                    }
                }
            }
        } else {
            exports.outputAa0009NextPrevBusinessDay.returnCode.setValue(TextAttribute.of("1"));
            setExitState(AaAdsCommonObjects.AA055_E_INVALID_INPUT_INDICATOR);
        }
    }


    @Override
    public void setImports(Imports imports) {
        this.imports = imports;
    }

    @Override
    public Imports getImports() {
        return this.imports;
    }

    @Override
    public Exports getExports() {
        return this.exports;
    }
}