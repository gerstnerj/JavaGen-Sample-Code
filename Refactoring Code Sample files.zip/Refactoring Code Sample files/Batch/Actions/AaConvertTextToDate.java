package gov.nm.cses.gen.actions;

import static com.innowake.gen.Functions.*;

import com.innowake.gen.*;
import com.innowake.gen.attributes.*;
import com.innowake.gen.utils.*;
import gov.nm.cses.gen.globals.*;
import gov.nm.cses.gen.globals.exitstate.*;

import static gov.nm.cses.gen.globals.GlobalCommand.*;

import gov.nm.cses.gen.entities.*;

/**
  * This CAB inputs a date in the form of three text fields (TEXT_YEAR_YYYY, 
  * TEXT_YEAR_YY, TEXT_MONTH, TEXT_DAYS), validates the values as a valid date,
  *  then converts the values to a date and places them in  the concatenated date attribute of the work set.  Additionally (and optionally), the new date is checked against values placed in date1 and date2 to see if the new date lies within the range of these two dates.
  */ 
public final class AaConvertTextToDate extends IntermediateAction<AaConvertTextToDate.Imports, AaConvertTextToDate.Exports> {

    /**
      * This CAB inputs a date in the form of three text fields (TEXT_YEAR_YYYY, 
      * TEXT_YEAR_YY, TEXT_MONTH, TEXT_DAYS), validates the values as a valid date,
      *  then converts the values to a date and places them in  the concatenated date attribute of the work set.  Additionally (and optionally), the new date is checked against values placed in date1 and date2 to see if the new date lies within the range of these two dates.
      */ 
    public static final class Imports extends ImportContainer {

         
        public static final class InputAa0003ValidatedDates extends EntityView<Aa0003ValidatedDates > {
             public Aa0003ValidatedDates.Date2 date2 = new Aa0003ValidatedDates.Date2();
             public Aa0003ValidatedDates.Date1 date1 = new Aa0003ValidatedDates.Date1();
             public Aa0003ValidatedDates.TextDays textDays = new Aa0003ValidatedDates.TextDays();
             public Aa0003ValidatedDates.TextMonth textMonth = new Aa0003ValidatedDates.TextMonth();
             public Aa0003ValidatedDates.TextYearYyyy textYearYyyy = new Aa0003ValidatedDates.TextYearYyyy();
             public Aa0003ValidatedDates.TextYearYy textYearYy = new Aa0003ValidatedDates.TextYearYy();
        }

        public final InputAa0003ValidatedDates inputAa0003ValidatedDates = new InputAa0003ValidatedDates();
    }

    public static final class Exports extends ExportContainer {

         
        public static final class OutputAa0003ValidatedDates extends EntityView<Aa0003ValidatedDates > {
             public Aa0003ValidatedDates.ReturnCode returnCode = new Aa0003ValidatedDates.ReturnCode();
             public Aa0003ValidatedDates.NumericMonth numericMonth = new Aa0003ValidatedDates.NumericMonth();
             public Aa0003ValidatedDates.NumericDays numericDays = new Aa0003ValidatedDates.NumericDays();
             public Aa0003ValidatedDates.NumericYear numericYear = new Aa0003ValidatedDates.NumericYear();
             public Aa0003ValidatedDates.ConcatenatedDate concatenatedDate = new Aa0003ValidatedDates.ConcatenatedDate();
        }

        public final OutputAa0003ValidatedDates outputAa0003ValidatedDates = new OutputAa0003ValidatedDates();
    }

    private Imports imports = new Imports();
    private Exports exports = new Exports();

     
    public static final class LocalLeapFunction1IefSupplied extends EntityView<IefSupplied >  {
         public IefSupplied.TotalReal totalReal = new IefSupplied.TotalReal();
    }
     
    public static final class LocalLeapFunction2IefSupplied extends EntityView<IefSupplied >  {
         public IefSupplied.TotalReal totalReal = new IefSupplied.TotalReal();
    }
     
    public static final class LocalLeapFunction3IefSupplied extends EntityView<IefSupplied >  {
         public IefSupplied.TotalInteger totalInteger = new IefSupplied.TotalInteger();
    }
     
    public static final class LocalYearCountIefSupplied extends EntityView<IefSupplied >  {
         public IefSupplied.Flag flag = new IefSupplied.Flag();
    }
     
    public static final class LocalAa0003ValidatedDates extends EntityView<Aa0003ValidatedDates >  {
         public Aa0003ValidatedDates.TextDays textDays = new Aa0003ValidatedDates.TextDays();
         public Aa0003ValidatedDates.TextMonth textMonth = new Aa0003ValidatedDates.TextMonth();
         public Aa0003ValidatedDates.TextYearYyyy textYearYyyy = new Aa0003ValidatedDates.TextYearYyyy();
    }
    public final LocalLeapFunction1IefSupplied localLeapFunction1IefSupplied = new LocalLeapFunction1IefSupplied();
    public final LocalLeapFunction2IefSupplied localLeapFunction2IefSupplied = new LocalLeapFunction2IefSupplied();
    public final LocalLeapFunction3IefSupplied localLeapFunction3IefSupplied = new LocalLeapFunction3IefSupplied();
    public final LocalYearCountIefSupplied localYearCountIefSupplied = new LocalYearCountIefSupplied();
    public final LocalAa0003ValidatedDates localAa0003ValidatedDates = new LocalAa0003ValidatedDates();

    @Override
    public void run() {
        // ---------------------------------------------
        // ANDERSEN CONSULTING
        // 28 JANUARY, 1994
        // R. Dale Stafford
        // ---------------------------------------------
        // ---------------------------------------------
        // Use work set WS0003_Validated_Dates
        // ---------------------------------------------
        // ---------------------------------------------
        // This module takes as input a date in the form
        // of three text fields (TEXT_YEAR_YYYY, TEXT_
        // YEAR_YY, TEXT_MONTH, TEXT_DAYS), validates
        // the values as a valid date, then converts
        // the values to a date and places them in
        // the concatenated date attribute of the work
        // set.  Additionally (and optionally), the
        // new date is checked against values placed in
        // date1 and date2 to see if the new date lies
        // within the range of these two dates.
        // ---------------------------------------------
        // ---------------------------------------------
        // This section accommodates year fields of
        // length 4 or 2.  If the programmer is
        // designing a procedure in which the text field
        // holding the year value is of length 2, the
        // programmer must move the value entered
        // by the user into WS0003 attribute
        // TEXT_YEAR_YY.  If the field has length 4,
        // The programmer must move the value entered
        // into TEXT_YEAR_YYYY.
        // ---------------------------------------------
        // ---------------------------------------------
        // The following statements check that the
        // information entered by the user (in the text
        // field reserved for a date) is actually a
        // set of numbers.  IEF cannot convert the
        // fields to numeric fields otherwise.
        // ---------------------------------------------


        // ---------------------------------------------
        // The logic checks to see if the
        // programmer is using the 2-byte year field
        // or the 4-byte year field.  If he or she is
        // using the 2-byte field, the logic checks that
        // it is numeric.  If so, it then checks the
        // first chatacter to see if it is in the range
        // 5 through 9, or 0 through 4.  If it is in
        // the first range, the value is concatenated
        // with '19' (TWENTIETH CENTURY).  Otherwise it
        // is concatenated with '20'.  The concatenated
        // value is then placed in the local 4-byte
        // field for the remaining validation.
        // ---------------------------------------------


        // ---------------------------------------------
        // The module begins with a series of if_else
        // structures in order to avoid using IEF's
        // ESCAPE statement.
        // ---------------------------------------------

        exports.outputAa0003ValidatedDates.returnCode.setValue(TextAttribute.of("0"));

        // Hillje 1/17/97----------------------------
        // This module has become corrupted due to a
        // command incompatibility with the IEF upgrade
        // on the encyclopedia.  Necessary changes
        // cannot be made because the corruption
        // has created a protection violation. This entire
        // module has been copied to aa_convert text_
        // to_date_ii, which is immediately called at
        // the top of this module, and an escape stmnt
        // all the way out avoids traversing any code in
        // this module. The copied module will remain in
        // effect until this module can be successfully
        // modified correctly.
        // -----------------------------------------------

        use(action(AaConvertTextToDateIi.class)
                .whichImportsView(imports.inputAa0003ValidatedDates).to(imports -> imports.inputAa0003ValidatedDates)
                .whichExportsView(exports.outputAa0003ValidatedDates).from(exports -> exports.outputAa0003ValidatedDates)
            );

        return;


//        escape60435999:
//        if (! imports.inputAa0003ValidatedDates.textYearYy.equals(TextAttribute.of(Constant.SPACES))) {
//            escape60436000:
//            if (! find(imports.inputAa0003ValidatedDates.textYearYy, TextAttribute.of(" ")).equals(NumericAttribute.of(0))) {
//                exports.outputAa0003ValidatedDates.returnCode.setValue(TextAttribute.of("1"));
//                setExitState(AaAdsCommonObjects.AA042_E_INVALID_DATE);
//            }
//        } else if (! imports.inputAa0003ValidatedDates.textYearYyyy.equals(TextAttribute.of(Constant.SPACES))) {
//            escape60436001:
//            if (! find(imports.inputAa0003ValidatedDates.textYearYyyy, TextAttribute.of(" ")).equals(NumericAttribute.of(0))) {
//                exports.outputAa0003ValidatedDates.returnCode.setValue(TextAttribute.of("1"));
//                setExitState(AaAdsCommonObjects.AA042_E_INVALID_DATE);
//            }
//        } else {
//            exports.outputAa0003ValidatedDates.returnCode.setValue(TextAttribute.of("1"));
//            setExitState(AaAdsCommonObjects.AA042_E_INVALID_DATE);
//        }
//        escape60436002:
//        if (exports.outputAa0003ValidatedDates.returnCode.equals(TextAttribute.of("0"))) {
//            escape60436004:
//            if (! find(imports.inputAa0003ValidatedDates.textMonth, TextAttribute.of(" ")).equals(NumericAttribute.of(0))) {
//                exports.outputAa0003ValidatedDates.returnCode.setValue(TextAttribute.of("1"));
//                setExitState(AaAdsCommonObjects.AA042_E_INVALID_DATE);
//            } else {
//                escape60436005:
//                if (! find(imports.inputAa0003ValidatedDates.textDays, TextAttribute.of(" ")).equals(NumericAttribute.of(0))) {
//                    exports.outputAa0003ValidatedDates.returnCode.setValue(TextAttribute.of("1"));
//                    setExitState(AaAdsCommonObjects.AA042_E_INVALID_DATE);
//                }
//            }
//        }
//        escape60436003:
//        if (exports.outputAa0003ValidatedDates.returnCode.equals(TextAttribute.of("0"))) {
//            escape60435941:
//            if (! imports.inputAa0003ValidatedDates.textYearYy.equals(TextAttribute.of(Constant.SPACES))) {
//                escape60435944:
//                if (! verify(imports.inputAa0003ValidatedDates.textYearYy, TextAttribute.of("0123456789")).equals(NumericAttribute.of(0))) {
//                    exports.outputAa0003ValidatedDates.returnCode.setValue(TextAttribute.of("1"));
//                    setExitState(AaAdsCommonObjects.AA012_E_DATE_NOT_NUMERIC);
//                }
//            } else if (! imports.inputAa0003ValidatedDates.textYearYyyy.equals(TextAttribute.of(Constant.SPACES))) {
//                escape60435945:
//                if (! verify(imports.inputAa0003ValidatedDates.textYearYyyy, TextAttribute.of("0123456789")).equals(NumericAttribute.of(0))) {
//                    exports.outputAa0003ValidatedDates.returnCode.setValue(TextAttribute.of("1"));
//                    setExitState(AaAdsCommonObjects.AA012_E_DATE_NOT_NUMERIC);
//                }
//
//                escape60436096:
//                if (imports.inputAa0003ValidatedDates.textYearYyyy.equals(TextAttribute.of("0000"))) {
//                    exports.outputAa0003ValidatedDates.returnCode.setValue(TextAttribute.of("1"));
//                    setExitState(AaAdsCommonObjects.AA014_E_DATE_OUT_OF_RANGE);
//                }
//            }
//        }

//        escape60435953:
//        if (exports.outputAa0003ValidatedDates.returnCode.equals(TextAttribute.of("0"))) {
//            escape60435946:
//            if (! verify(imports.inputAa0003ValidatedDates.textMonth, TextAttribute.of("0123456789")).equals(NumericAttribute.of(0))) {
//                exports.outputAa0003ValidatedDates.returnCode.setValue(TextAttribute.of("1"));
//                setExitState(AaAdsCommonObjects.AA012_E_DATE_NOT_NUMERIC);
//            } else {
//                escape60435947:
//                if (! verify(imports.inputAa0003ValidatedDates.textDays, TextAttribute.of("0123456789")).equals(NumericAttribute.of(0))) {
//                    exports.outputAa0003ValidatedDates.returnCode.setValue(TextAttribute.of("1"));
//                    setExitState(AaAdsCommonObjects.AA012_E_DATE_NOT_NUMERIC);
//                }
//            }
//        }

//        escape60435950:
//        if (exports.outputAa0003ValidatedDates.returnCode.equals(TextAttribute.of("0"))) {
//            localAa0003ValidatedDates.textDays.setValue(imports.inputAa0003ValidatedDates.textDays);
//            localAa0003ValidatedDates.textMonth.setValue(imports.inputAa0003ValidatedDates.textMonth);
//            escape60435951:
//            if (! imports.inputAa0003ValidatedDates.textYearYy.equals(TextAttribute.of(Constant.SPACES))) {
//                escape60435952:
//                if (imports.inputAa0003ValidatedDates.textYearYy.compareTo(TextAttribute.of("50")) >= 0 && (imports.inputAa0003ValidatedDates.textYearYy.compareTo(TextAttribute.of("99")) <= 0)) {
//                    localAa0003ValidatedDates.textYearYyyy.setValue(concat(TextAttribute.of("19"), imports.inputAa0003ValidatedDates.textYearYy));
//                } else {
//                    localAa0003ValidatedDates.textYearYyyy.setValue(concat(TextAttribute.of("20"), imports.inputAa0003ValidatedDates.textYearYy));
//                }
//            } else {
//                localAa0003ValidatedDates.textYearYyyy.setValue(imports.inputAa0003ValidatedDates.textYearYyyy);
//            }
//        }
        // ---------------------------------------------
        // Convert the text fields to numeric fields.
        // ---------------------------------------------
//        escape60435948:
//        if (exports.outputAa0003ValidatedDates.returnCode.equals(TextAttribute.of("0"))) {
//            exports.outputAa0003ValidatedDates.numericYear.setValueRounded(numtext(localAa0003ValidatedDates.textYearYyyy));
//            exports.outputAa0003ValidatedDates.numericMonth.setValueRounded(numtext(localAa0003ValidatedDates.textMonth));
//            exports.outputAa0003ValidatedDates.numericDays.setValueRounded(numtext(localAa0003ValidatedDates.textDays));
//
//
//            // ---------------------------------------------
//            // The following statements insure that the user
//            // has entered a date that, though perhaps not
//            // valid within the system, is a logically valid
//            // date.
//            // ---------------------------------------------
//            escape60435938:
//            if (exports.outputAa0003ValidatedDates.numericMonth.compareTo(NumericAttribute.of(1)) < 0 || (exports.outputAa0003ValidatedDates.numericMonth.compareTo(NumericAttribute.of(12)) > 0)) {
//                setExitState(AaAdsCommonObjects.AA042_E_INVALID_DATE);
//                exports.outputAa0003ValidatedDates.returnCode.setValue(TextAttribute.of("1"));
//                break escape60435948;
//            }
//
//            escape60435935:
//            if (exports.outputAa0003ValidatedDates.numericMonth.equals(NumericAttribute.of(1)) || (exports.outputAa0003ValidatedDates.numericMonth.equals(NumericAttribute.of(3))) || (exports.outputAa0003ValidatedDates.numericMonth.equals(NumericAttribute.of(5))) || (exports.outputAa0003ValidatedDates.numericMonth.equals(NumericAttribute.of(7))) || (exports.outputAa0003ValidatedDates.numericMonth.equals(NumericAttribute.of(8))) || (exports.outputAa0003ValidatedDates.numericMonth.equals(NumericAttribute.of(10))) || (exports.outputAa0003ValidatedDates.numericMonth.equals(NumericAttribute.of(12)))) {
//                escape60435936:
//                if (exports.outputAa0003ValidatedDates.numericDays.compareTo(NumericAttribute.of(1)) < 0 || (exports.outputAa0003ValidatedDates.numericDays.compareTo(NumericAttribute.of(31)) > 0)) {
//                    setExitState(AaAdsCommonObjects.AA042_E_INVALID_DATE);
//                    exports.outputAa0003ValidatedDates.returnCode.setValue(TextAttribute.of("1"));
//                }
//            } else if (exports.outputAa0003ValidatedDates.numericMonth.equals(NumericAttribute.of(4)) || (exports.outputAa0003ValidatedDates.numericMonth.equals(NumericAttribute.of(6))) || (exports.outputAa0003ValidatedDates.numericMonth.equals(NumericAttribute.of(9))) || (exports.outputAa0003ValidatedDates.numericMonth.equals(NumericAttribute.of(11)))) {
//                escape60435937:
//                if (exports.outputAa0003ValidatedDates.numericDays.compareTo(NumericAttribute.of(1)) < 0 || (exports.outputAa0003ValidatedDates.numericDays.compareTo(NumericAttribute.of(30)) > 0)) {
//                    setExitState(AaAdsCommonObjects.AA042_E_INVALID_DATE);
//                    exports.outputAa0003ValidatedDates.returnCode.setValue(TextAttribute.of("1"));
//                }
//            } else if (exports.outputAa0003ValidatedDates.numericMonth.equals(NumericAttribute.of(2))) {
//                localYearCountIefSupplied.flag.setValue(TextAttribute.of("F"));
//                localLeapFunction1IefSupplied.totalReal.setValueRounded(exports.outputAa0003ValidatedDates.numericYear.divide(NumericAttribute.of(4)));
//                localLeapFunction2IefSupplied.totalReal.setValue((exports.outputAa0003ValidatedDates.numericYear.divide(NumericAttribute.of(4))).minus(NumericAttribute.of(".5")));
//                localLeapFunction3IefSupplied.totalInteger.setValueRounded(localLeapFunction2IefSupplied.totalReal);
//                escape60435934:
//                if (localLeapFunction1IefSupplied.totalReal.minus(localLeapFunction3IefSupplied.totalInteger).equals(NumericAttribute.of(0)) && (! exports.outputAa0003ValidatedDates.numericYear.equals(NumericAttribute.of(2000)))) {
//                    localYearCountIefSupplied.flag.setValue(TextAttribute.of("T"));
//                }
//                escape60435942:
//                if (localYearCountIefSupplied.flag.equals(TextAttribute.of("T"))) {
//                    escape60435943:
//                    if (exports.outputAa0003ValidatedDates.numericDays.compareTo(NumericAttribute.of(1)) < 0 || (exports.outputAa0003ValidatedDates.numericDays.compareTo(NumericAttribute.of(29)) > 0)) {
//                        setExitState(AaAdsCommonObjects.AA042_E_INVALID_DATE);
//                        exports.outputAa0003ValidatedDates.returnCode.setValue(TextAttribute.of("1"));
//                    }
//                } else if (exports.outputAa0003ValidatedDates.numericDays.compareTo(NumericAttribute.of(1)) < 0 || (exports.outputAa0003ValidatedDates.numericDays.compareTo(NumericAttribute.of(28)) > 0)) {
//                    exports.outputAa0003ValidatedDates.returnCode.setValue(TextAttribute.of("1"));
//                    setExitState(AaAdsCommonObjects.AA042_E_INVALID_DATE);
//                }
//            } else {
//                exports.outputAa0003ValidatedDates.returnCode.setValue(TextAttribute.of("1"));
//                setExitState(AaAdsCommonObjects.AA042_E_INVALID_DATE);
//            }
//        }

        // ---------------------------------------------
        // At this point, the information entered by
        // the user is deemed to be a valid date and
        // will now be compared to the date in input
        // view date_1 to see which date is greater
        // ---------------------------------------------

//        escape60435949:
//        if (exports.outputAa0003ValidatedDates.returnCode.equals(TextAttribute.of("0"))) {
//            exports.outputAa0003ValidatedDates.concatenatedDate.setValue(datetext(concat(localAa0003ValidatedDates.textYearYyyy, concat(TextAttribute.of("-"), concat(localAa0003ValidatedDates.textMonth, concat(TextAttribute.of("-"), localAa0003ValidatedDates.textDays))))));
//
//            // ---------------------------------------------
//            // If DATE1 and DATE2 are not equal to spaces,
//            // then the new date is checked to see if it
//            // falls in the range of the these two dates.
//            // If either DATE1 or DATE2 is spaces, then the
//            // logic is skipped and the exit state does not
//            // change.
//            // ---------------------------------------------
//
//            escape60435940:
//            if (! imports.inputAa0003ValidatedDates.date1.equals(datenum(NumericAttribute.of(0))) && (! imports.inputAa0003ValidatedDates.date2.equals(datenum(NumericAttribute.of(0))))) {
//                setExitState(AaAdsCommonObjects.AA513_I_DATE_IS_WITHIN_THE_RANGE);
//
//                escape60435939:
//                if (exports.outputAa0003ValidatedDates.concatenatedDate.compareTo(imports.inputAa0003ValidatedDates.date1) < 0) {
//                    setExitState(AaAdsCommonObjects.AA514_I_DATE_OUTSIDE_RANGE);
//                }
//                escape60435933:
//                if (exports.outputAa0003ValidatedDates.concatenatedDate.compareTo(imports.inputAa0003ValidatedDates.date2) > 0) {
//                    setExitState(AaAdsCommonObjects.AA514_I_DATE_OUTSIDE_RANGE);
//                }
//            }
//        }
    }


    @Override
    public void setImports(Imports imports) {
        this.imports = imports;
    }

    @Override
    public Imports getImports() {
        return this.imports;
    }

    @Override
    public Exports getExports() {
        return this.exports;
    }
}