package gov.nm.cses.gen.actions;

import com.innowake.gen.cobol.LinkageSection;
import com.innowake.gen.cobol.storage.*;
import com.innowake.gen.cobol.storage.ExportStorage;
import com.innowake.gen.cobol.storage.ImportStorage;
import com.innowake.gen.cobol.storage.Storage;
import java.util.ArrayList;

public class TaCheckRebuildFlagLinkage extends LinkageSection {

    public TaCheckRebuildFlagLinkage(TaCheckRebuildFlag genActionBlock) {
        this.highPerformanceViewMatching = false;
        this.generateMissingFlags = true;
        TaCheckRebuildFlag.Imports imports = genActionBlock.getImports();
        TaCheckRebuildFlag.Exports exports = genActionBlock.getExports();
        this.globals.add(GlobalStorage.builder(genActionBlock.getGlobal()));

        this.exports.add(ExportStorage.builder(exports)
            .entity(e -> e.outputAaCkpointControl)
                .textAttribute(e -> e.cpJobNumber)
            .endEntity()
            .entity(e -> e.outputAaRebuildFiles)
                .textAttribute(e -> e.rebuildFlag)
            .endEntity()
            .entity(e -> e.outputAaFileControl)
                .textAttribute(e -> e.fcIoFileStatus)
                .textAttribute(e -> e.fcIoReturnCode)
                .textAttribute(e -> e.fcIoFileReturn)
            .endEntity()
        );

    }
}