package gov.nm.cses.gen.actions;

import static com.innowake.gen.Functions.*;

import com.innowake.gen.*;
import com.innowake.gen.attributes.*;
import com.innowake.gen.utils.*;
import gov.nm.cses.gen.globals.*;
import gov.nm.cses.gen.globals.exitstate.*;

import static gov.nm.cses.gen.globals.GlobalCommand.*;

import gov.nm.cses.gen.entities.*;

 
public final class HsAaValGenericCodes extends IntermediateAction<HsAaValGenericCodes.Imports, HsAaValGenericCodes.Exports> {

     
    public static final class Imports extends ImportContainer {

         
        public static final class InputAa0010ActiveHelp extends EntityView<Aa0010ActiveHelp > {
             public Aa0010ActiveHelp.SearchCriteria searchCriteria = new Aa0010ActiveHelp.SearchCriteria();
             public Aa0010ActiveHelp.Helpid helpid = new Aa0010ActiveHelp.Helpid();
             public Aa0010ActiveHelp.Code code = new Aa0010ActiveHelp.Code();
        }

        public final InputAa0010ActiveHelp inputAa0010ActiveHelp = new InputAa0010ActiveHelp();
    }

    public static final class Exports extends ExportContainer {

         
        public static final class OutputAa0010ActiveHelp extends EntityView<Aa0010ActiveHelp > {
             public Aa0010ActiveHelp.Code code = new Aa0010ActiveHelp.Code();
             public Aa0010ActiveHelp.Decode decode = new Aa0010ActiveHelp.Decode();
             public Aa0010ActiveHelp.Helpid helpid = new Aa0010ActiveHelp.Helpid();
             public Aa0010ActiveHelp.ReturnCode returnCode = new Aa0010ActiveHelp.ReturnCode();
        }

        public final OutputAa0010ActiveHelp outputAa0010ActiveHelp = new OutputAa0010ActiveHelp();
    }

    private Imports imports = new Imports();
    private Exports exports = new Exports();

     
    public static final class ActionField extends PersistentEntityView<Field > {
         public Field.HelpIdentifier helpIdentifier = new Field.HelpIdentifier();
         public Field.ShortDescriptionText shortDescriptionText = new Field.ShortDescriptionText();
    }
     
    public static final class ActionPermittedValue1 extends PersistentEntityView<PermittedValue1 > {
         public PermittedValue1.Code code = new PermittedValue1.Code();
         public PermittedValue1.ShortDescriptionText shortDescriptionText = new PermittedValue1.ShortDescriptionText();
    }
    public final ActionField actionField = new ActionField();
    public final ActionPermittedValue1 actionPermittedValue1 = new ActionPermittedValue1();

    @Override
    public void run() {
        // --------------------------------------------
        // Andersen Consulting
        // 03/01/94	     R. Dale Stafford
        // Initial Coding
        // Where Used:
        // Functional Common Module
        // 
        // Modifications:
        // 1	05/26/94	R. Dale Stafford
        // Added return codes
        // --------------------------------------------
        // ---------------------------------------------
        // This module validates all generic codes
        // entered by the user
        // ---------------------------------------------
        // ---------------------------------------------
        // Initialize return code to 0
        // ---------------------------------------------
        exports.outputAa0010ActiveHelp.returnCode.setValue(TextAttribute.of("0"));


        escape60491373:
        try {
            read( actionPermittedValue1 , actionField ).allowMultiple().where(
                ((that(actionPermittedValue1).attribute(actionPermittedValue1.code).isEqualTo(valueOf(imports.inputAa0010ActiveHelp.code))).and(desired(actionPermittedValue1).relatesAs(PermittedValue1.areAllowedInputsToField()).to(desired(actionField)))).and(that(actionField).attribute(actionField.helpIdentifier).isEqualTo(valueOf(imports.inputAa0010ActiveHelp.helpid))) );
            exports.outputAa0010ActiveHelp.decode.setValue(actionPermittedValue1.shortDescriptionText);
        } catch (NotFoundException e60491373) {
            exports.outputAa0010ActiveHelp.returnCode.setValue(TextAttribute.of("1"));
            setExitState(ApplicationHelp.AH002_E_INVALID_VALUE);
        }
    }


    @Override
    public void setImports(Imports imports) {
        this.imports = imports;
    }

    @Override
    public Imports getImports() {
        return this.imports;
    }

    @Override
    public Exports getExports() {
        return this.exports;
    }
}