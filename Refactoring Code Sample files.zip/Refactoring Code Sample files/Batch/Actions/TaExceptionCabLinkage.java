package gov.nm.cses.gen.actions;

import com.innowake.gen.cobol.LinkageSection;
import com.innowake.gen.cobol.storage.*;
import com.innowake.gen.cobol.storage.ExportStorage;
import com.innowake.gen.cobol.storage.ImportStorage;
import com.innowake.gen.cobol.storage.Storage;
import java.util.ArrayList;

public class TaExceptionCabLinkage extends LinkageSection {

    public TaExceptionCabLinkage(TaExceptionCab genActionBlock) {
        this.highPerformanceViewMatching = false;
        this.generateMissingFlags = true;
        TaExceptionCab.Imports imports = genActionBlock.getImports();
        TaExceptionCab.Exports exports = genActionBlock.getExports();
        this.globals.add(GlobalStorage.builder(genActionBlock.getGlobal()));

        this.imports.add(ImportStorage.builder(imports)
            .entity(e -> e.inputAaRebuildFiles)
                .textAttribute(e -> e.rebuildFlag)
            .endEntity()
            .entity(e -> e.inputTa0027ExceptionFields)
                .textAttribute(e -> e.fileMode)
                .textAttribute(e -> e.programId)
                .textAttribute(e -> e.recordKeyName)
                .textAttribute(e -> e.recordKeyValue)
                .textAttribute(e -> e.sourceCode)
                .textAttribute(e -> e.errorCode)
                .textAttribute(e -> e.errorDescription)
            .endEntity()
        );

        this.exports.add(ExportStorage.builder(exports)
            .entity(e -> e.outputTa0027ExceptionFields)
                .textAttribute(e -> e.returnCode)
            .endEntity()
        );

    }
}