package gov.nm.cses.gen.actions;

import static com.innowake.gen.Functions.*;

import com.innowake.gen.*;
import com.innowake.gen.attributes.*;
import com.innowake.gen.utils.*;
import gov.nm.cses.gen.globals.*;
import gov.nm.cses.gen.globals.exitstate.*;

import static gov.nm.cses.gen.globals.GlobalCommand.*;

import gov.nm.cses.gen.entities.*;

/**
  * Delete Morning Mail Summary
  * 
  * DEF:  This process deletes any Morning Mail Summary record that is greater 
  * than thirty days old. This process will check the date and determine if it 
  * is older than 30 days then delete the occurrence.
  * 
  * 
  */ 
public final class CmeDeleteMorningMailSumm extends IntermediateAction<CmeDeleteMorningMailSumm.Imports, CmeDeleteMorningMailSumm.Exports> {

    /**
      * Delete Morning Mail Summary
      * 
      * DEF:  This process deletes any Morning Mail Summary record that is greater 
      * than thirty days old. This process will check the date and determine if it 
      * is older than 30 days then delete the occurrence.
      * 
      * 
      */ 
    public static final class Imports extends ImportContainer {

         
        public static final class InputMorningMailSummary extends EntityView<MorningMailSummary > {
             public MorningMailSummary.ActivityCode activityCode = new MorningMailSummary.ActivityCode();
             public MorningMailSummary.OfficeCode officeCode = new MorningMailSummary.OfficeCode();
             public MorningMailSummary.SubsystemIdentifier subsystemIdentifier = new MorningMailSummary.SubsystemIdentifier();
             public MorningMailSummary.SummaryDate summaryDate = new MorningMailSummary.SummaryDate();
             public MorningMailSummary.UserIdentifier userIdentifier = new MorningMailSummary.UserIdentifier();
        }

        public final InputMorningMailSummary inputMorningMailSummary = new InputMorningMailSummary();
    }

    public static final class Exports extends ExportContainer {


    }

    private Imports imports = new Imports();
    private Exports exports = new Exports();

     
    public static final class ActionMorningMailSummary extends PersistentEntityView<MorningMailSummary > {
         public MorningMailSummary.ActivityCode activityCode = new MorningMailSummary.ActivityCode();
         public MorningMailSummary.OfficeCode officeCode = new MorningMailSummary.OfficeCode();
         public MorningMailSummary.SummaryDate summaryDate = new MorningMailSummary.SummaryDate();
         public MorningMailSummary.SubsystemIdentifier subsystemIdentifier = new MorningMailSummary.SubsystemIdentifier();
         public MorningMailSummary.UserIdentifier userIdentifier = new MorningMailSummary.UserIdentifier();
         public MorningMailSummary.StaffTypeCode staffTypeCode = new MorningMailSummary.StaffTypeCode();
         public MorningMailSummary.DueTotalCount dueTotalCount = new MorningMailSummary.DueTotalCount();
         public MorningMailSummary.WorkerOverdueTotalCount workerOverdueTotalCount = new MorningMailSummary.WorkerOverdueTotalCount();
         public MorningMailSummary.ManagerOverdueCount managerOverdueCount = new MorningMailSummary.ManagerOverdueCount();
         public MorningMailSummary.DueCompletedTotalCount dueCompletedTotalCount = new MorningMailSummary.DueCompletedTotalCount();
         public MorningMailSummary.WorkerOverdueCompleteTtlCnt workerOverdueCompleteTtlCnt = new MorningMailSummary.WorkerOverdueCompleteTtlCnt();
         public MorningMailSummary.ManagerOverdueCompletedCount managerOverdueCompletedCount = new MorningMailSummary.ManagerOverdueCompletedCount();
    }
    public final ActionMorningMailSummary actionMorningMailSummary = new ActionMorningMailSummary();

    @Override
    public void run() {
        // ---------------------------------------------
        // ANDERSEN CONSULTING
        // 
        // Initial Coding
        // 3/94
        // 
        // Modifications:
        // ---------------------------------------------

        escape60492050:
        try {
            read( actionMorningMailSummary ).allowMultiple().where(
                ((((that(actionMorningMailSummary).attribute(actionMorningMailSummary.activityCode).isEqualTo(valueOf(imports.inputMorningMailSummary.activityCode))).and(that(actionMorningMailSummary).attribute(actionMorningMailSummary.officeCode).isEqualTo(valueOf(imports.inputMorningMailSummary.officeCode)))).and(that(actionMorningMailSummary).attribute(actionMorningMailSummary.subsystemIdentifier).isEqualTo(valueOf(imports.inputMorningMailSummary.subsystemIdentifier)))).and(that(actionMorningMailSummary).attribute(actionMorningMailSummary.summaryDate).isEqualTo(valueOf(imports.inputMorningMailSummary.summaryDate)))).and(that(actionMorningMailSummary).attribute(actionMorningMailSummary.userIdentifier).isEqualTo(valueOf(imports.inputMorningMailSummary.userIdentifier))) );
            delete(actionMorningMailSummary);
            setExitState(AaAdsCommonObjects.AA538_I_SUCCESSFUL_DELETE);

        } catch (NotFoundException e60492050) {
            setExitState(CmCaseManagement.CM135_E_MORNING_MAIL_SUMMARY_NF);

        }
    }


    @Override
    public void setImports(Imports imports) {
        this.imports = imports;
    }

    @Override
    public Imports getImports() {
        return this.imports;
    }

    @Override
    public Exports getExports() {
        return this.exports;
    }
}