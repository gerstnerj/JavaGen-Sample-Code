package gov.nm.cses.gen.actions;

import static com.innowake.gen.Functions.*;

import com.innowake.gen.*;
import com.innowake.gen.attributes.*;
import com.innowake.gen.utils.*;
import gov.nm.cses.gen.globals.*;
import gov.nm.cses.gen.globals.exitstate.*;

import static gov.nm.cses.gen.globals.GlobalCommand.*;

import gov.nm.cses.gen.entities.*;

 
public final class AaValidBusinessDay extends IntermediateAction<AaValidBusinessDay.Imports, AaValidBusinessDay.Exports> {

     
    public static final class Imports extends ImportContainer {

         
        public static final class InputAa0009NextPrevBusinessDay extends EntityView<Aa0009NextPrevBusinessDay > {
             public Aa0009NextPrevBusinessDay.Indicator indicator = new Aa0009NextPrevBusinessDay.Indicator();
             public Aa0009NextPrevBusinessDay.ReturnCode returnCode = new Aa0009NextPrevBusinessDay.ReturnCode();
             public Aa0009NextPrevBusinessDay.EnterDate enterDate = new Aa0009NextPrevBusinessDay.EnterDate();
        }

        public final InputAa0009NextPrevBusinessDay inputAa0009NextPrevBusinessDay = new InputAa0009NextPrevBusinessDay();
    }

    public static final class Exports extends ExportContainer {

         
        public static final class OutputAa0009NextPrevBusinessDay extends EntityView<Aa0009NextPrevBusinessDay > {
             public Aa0009NextPrevBusinessDay.Indicator indicator = new Aa0009NextPrevBusinessDay.Indicator();
             public Aa0009NextPrevBusinessDay.ReturnCode returnCode = new Aa0009NextPrevBusinessDay.ReturnCode();
             public Aa0009NextPrevBusinessDay.ReturnedDate returnedDate = new Aa0009NextPrevBusinessDay.ReturnedDate();
        }

        public final OutputAa0009NextPrevBusinessDay outputAa0009NextPrevBusinessDay = new OutputAa0009NextPrevBusinessDay();
    }

    private Imports imports = new Imports();
    private Exports exports = new Exports();

     
    public static final class LocalAa0009NextPrevBusinessDay extends EntityView<Aa0009NextPrevBusinessDay >  {
         public Aa0009NextPrevBusinessDay.TextDays textDays = new Aa0009NextPrevBusinessDay.TextDays();
         public Aa0009NextPrevBusinessDay.TextMonth textMonth = new Aa0009NextPrevBusinessDay.TextMonth();
         public Aa0009NextPrevBusinessDay.TextYear textYear = new Aa0009NextPrevBusinessDay.TextYear();
         public Aa0009NextPrevBusinessDay.DayOfWeek dayOfWeek = new Aa0009NextPrevBusinessDay.DayOfWeek();
    }
     
    public static final class ActionMasterCalendar extends PersistentEntityView<MasterCalendar > {
         public MasterCalendar.HolidayDate holidayDate = new MasterCalendar.HolidayDate();
    }
    public final LocalAa0009NextPrevBusinessDay localAa0009NextPrevBusinessDay = new LocalAa0009NextPrevBusinessDay();
    public final ActionMasterCalendar actionMasterCalendar = new ActionMasterCalendar();

    @Override
    public void run() {
        // ---------------------------------------------
        // Andersen Consulting
        // 23 February, 1994
        // R. Dale Stafford
        // ---------------------------------------------

        // ---------------------------------------------
        // This module takes a date as input and checks
        // that it is a valid business day (ie, that it
        // is not a Saturday or Sunday and that it does
        // not exist on the system's Master Calendar).
        // If the date is a valid business day, then
        // this same date is returned to the calling
        // program.  If the date is not a business day,
        // then a null date value is returned
        // (datenum(0)).
        // ---------------------------------------------

        exports.outputAa0009NextPrevBusinessDay.returnCode.setValue(TextAttribute.of("0"));
        move(imports.inputAa0009NextPrevBusinessDay).to(exports.outputAa0009NextPrevBusinessDay);
        localAa0009NextPrevBusinessDay.dayOfWeek.setValue(dayofweek(imports.inputAa0009NextPrevBusinessDay.enterDate));
        escape60435919:
        if (localAa0009NextPrevBusinessDay.dayOfWeek.equals(TextAttribute.of("SATURDAY")) || (localAa0009NextPrevBusinessDay.dayOfWeek.equals(TextAttribute.of("SUNDAY")))) {
            exports.outputAa0009NextPrevBusinessDay.returnCode.setValue(TextAttribute.of("1"));
            exports.outputAa0009NextPrevBusinessDay.returnedDate.setValue(datenum(NumericAttribute.of(0)));
            setExitState(AaAdsCommonObjects.AA015_E_DAY_INVALID_BUSINESS_DAY);
        }

        escape60435972:
        if (exports.outputAa0009NextPrevBusinessDay.returnCode.equals(TextAttribute.of("0"))) {
            escape60492373:
            try {
                read( actionMasterCalendar ).allowMultiple().where(
                    that(actionMasterCalendar).attribute(actionMasterCalendar.holidayDate).isEqualTo(valueOf(imports.inputAa0009NextPrevBusinessDay.enterDate)) );
                setExitState(AaAdsCommonObjects.AA015_E_DAY_INVALID_BUSINESS_DAY);
                exports.outputAa0009NextPrevBusinessDay.returnCode.setValue(TextAttribute.of("1"));
                exports.outputAa0009NextPrevBusinessDay.returnedDate.setValue(datenum(NumericAttribute.of(0)));
            } catch (NotFoundException e60492373) {
                setExitState(AaAdsCommonObjects.AA546_I_DAY_A_VALID_BUSINESS_DAY);
                exports.outputAa0009NextPrevBusinessDay.returnedDate.setValue(imports.inputAa0009NextPrevBusinessDay.enterDate);
            }
        }
    }


    @Override
    public void setImports(Imports imports) {
        this.imports = imports;
    }

    @Override
    public Imports getImports() {
        return this.imports;
    }

    @Override
    public Exports getExports() {
        return this.exports;
    }
}