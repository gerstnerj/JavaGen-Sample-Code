package gov.nm.cses.gen.actions;

import static com.innowake.gen.Functions.*;

import com.innowake.gen.*;
import com.innowake.gen.attributes.*;
import com.innowake.gen.utils.*;
import com.innowake.gen.annotation.ExternalActionBlock;
import com.innowake.gen.annotation.ExternalActionBlock.GenerateMissingFlags;
import gov.nm.cses.gen.globals.*;
import gov.nm.cses.gen.globals.exitstate.*;

import static gov.nm.cses.gen.globals.GlobalCommand.*;

import gov.nm.cses.gen.entities.*;
import com.innowake.gen.integration.MeeIntegrationBean;
import gov.nm.cses.gen.eab.HSTAAAAC;

 
@ExternalActionBlock(generateMissingFlags = GenerateMissingFlags.TRUE)
public final class TaCheckRebuildFlag extends IntermediateAction<TaCheckRebuildFlag.Imports, TaCheckRebuildFlag.Exports> {

     
    public static final class Imports extends ImportContainer {


    }

    public static final class Exports extends ExportContainer {

         
        public static final class OutputAaCkpointControl extends EntityView<AaCkpointControl > {
             public AaCkpointControl.CpJobNumber cpJobNumber = new AaCkpointControl.CpJobNumber();
        }
         
        public static final class OutputAaRebuildFiles extends EntityView<AaRebuildFiles > {
             public AaRebuildFiles.RebuildFlag rebuildFlag = new AaRebuildFiles.RebuildFlag();
        }
         
        public static final class OutputAaFileControl extends EntityView<AaFileControl > {
             public AaFileControl.FcIoFileStatus fcIoFileStatus = new AaFileControl.FcIoFileStatus();
             public AaFileControl.FcIoReturnCode fcIoReturnCode = new AaFileControl.FcIoReturnCode();
             public AaFileControl.FcIoFileReturn fcIoFileReturn = new AaFileControl.FcIoFileReturn();
        }

        public final OutputAaCkpointControl outputAaCkpointControl = new OutputAaCkpointControl();
        public final OutputAaRebuildFiles outputAaRebuildFiles = new OutputAaRebuildFiles();
        public final OutputAaFileControl outputAaFileControl = new OutputAaFileControl();
    }

    private Imports imports = new Imports();
    private Exports exports = new Exports();



    @Override
    public void run() {
        MeeIntegrationBean integrationBean = getGlobal().getMeeIntegrationBean();
        integrationBean.runProgram(HSTAAAAC.class, integrationBean.getLinkage(this));
    }

    @Override
    public void setImports(Imports imports) {
        this.imports = imports;
    }

    @Override
    public Imports getImports() {
        return this.imports;
    }

    @Override
    public Exports getExports() {
        return this.exports;
    }
}