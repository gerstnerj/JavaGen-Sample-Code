package gov.nm.cses.gen.procedures;

import static com.innowake.gen.Functions.*;

import com.innowake.gen.*;
import com.innowake.gen.attributes.*;
import com.innowake.gen.Attribute.VideoAttribute;
import com.innowake.gen.utils.*;
import gov.nm.cses.gen.globals.GlobalCommand;
import gov.nm.cses.gen.globals.exitstate.*;
import gov.nm.cses.gen.entities.*;
import gov.nm.cses.gen.actions.*;
import java.util.Iterator;
import org.springframework.stereotype.Component;
import org.springframework.context.annotation.Scope;
/**
  * Delete Morning Mail Summary
  * 
  * DEF:  This batch procedure will delete MORNING MAIL SUMMARY files that are 
  * 30 days old or older.
  * 
  * 
  * FREQ: nightly
  */ 
@Component
@Scope("prototype")
public class CmMorningMailSummaryDelete extends IntermediateProcedureStep<CmMorningMailSummaryDelete.Imports, CmMorningMailSummaryDelete.Exports> {

    /**
      * Delete Morning Mail Summary
      * 
      * DEF:  This batch procedure will delete MORNING MAIL SUMMARY files that are 
      * 30 days old or older.
      * 
      * 
      * FREQ: nightly
      */ 
    public static final class Imports extends ImportContainer {

         
        public static final class InputAaRebuildFiles extends EntityView<AaRebuildFiles > {
             public AaRebuildFiles.RebuildFlag rebuildFlag = new AaRebuildFiles.RebuildFlag();
        }
         
        public static final class InputBadRecordMorningMailSummary extends EntityView<MorningMailSummary > {
             public MorningMailSummary.OfficeCode officeCode = new MorningMailSummary.OfficeCode();
             public MorningMailSummary.ActivityCode activityCode = new MorningMailSummary.ActivityCode();
             public MorningMailSummary.SubsystemIdentifier subsystemIdentifier = new MorningMailSummary.SubsystemIdentifier();
             public MorningMailSummary.SummaryDate summaryDate = new MorningMailSummary.SummaryDate();
             public MorningMailSummary.UserIdentifier userIdentifier = new MorningMailSummary.UserIdentifier();
        }
         
        public static final class InputRecordsReadIefSupplied extends EntityView<IefSupplied > {
             public IefSupplied.Count count = new IefSupplied.Count();
        }
         
        public static final class InputRecordsDeletedIefSupplied extends EntityView<IefSupplied > {
             public IefSupplied.Count count = new IefSupplied.Count();
        }
         
        public static final class InputTa0022EojSummaryFields extends EntityView<Ta0022EojSummaryFields > {
             public Ta0022EojSummaryFields.FileMode fileMode = new Ta0022EojSummaryFields.FileMode();
             public Ta0022EojSummaryFields.ProgramId programId = new Ta0022EojSummaryFields.ProgramId();
             public Ta0022EojSummaryFields.ControlAreaType controlAreaType = new Ta0022EojSummaryFields.ControlAreaType();
             public Ta0022EojSummaryFields.Filename filename = new Ta0022EojSummaryFields.Filename();
             public Ta0022EojSummaryFields.ControlType controlType = new Ta0022EojSummaryFields.ControlType();
             public Ta0022EojSummaryFields.Format format = new Ta0022EojSummaryFields.Format();
             public Ta0022EojSummaryFields.ActualValue actualValue = new Ta0022EojSummaryFields.ActualValue();
             public Ta0022EojSummaryFields.Difference difference = new Ta0022EojSummaryFields.Difference();
             public Ta0022EojSummaryFields.ReturnCode returnCode = new Ta0022EojSummaryFields.ReturnCode();
             public Ta0022EojSummaryFields.PreviousAreaType previousAreaType = new Ta0022EojSummaryFields.PreviousAreaType();
             public Ta0022EojSummaryFields.PreviousFilename previousFilename = new Ta0022EojSummaryFields.PreviousFilename();
             public Ta0022EojSummaryFields.NoRecordsDoc noRecordsDoc = new Ta0022EojSummaryFields.NoRecordsDoc();
             public Ta0022EojSummaryFields.FirstTime firstTime = new Ta0022EojSummaryFields.FirstTime();
        }
         
        public static final class InputAaCkpointControl extends EntityView<AaCkpointControl > {
             public AaCkpointControl.CpCallingPgmId cpCallingPgmId = new AaCkpointControl.CpCallingPgmId();
             public AaCkpointControl.CpJobNumber cpJobNumber = new AaCkpointControl.CpJobNumber();
             public AaCkpointControl.CpRequestCode cpRequestCode = new AaCkpointControl.CpRequestCode();
             public AaCkpointControl.CpProcessMode cpProcessMode = new AaCkpointControl.CpProcessMode();
             public AaCkpointControl.CpDrivingFileNo cpDrivingFileNo = new AaCkpointControl.CpDrivingFileNo();
             public AaCkpointControl.CpDbOrFileDr cpDbOrFileDr = new AaCkpointControl.CpDbOrFileDr();
             public AaCkpointControl.CpDbRepoData cpDbRepoData = new AaCkpointControl.CpDbRepoData();
        }
         
        public static final class InputErrorsIefSupplied extends EntityView<IefSupplied > {
             public IefSupplied.Count count = new IefSupplied.Count();
        }
         
        public static final class DeletemeInputPreviousDateMorningMailSummary extends EntityView<MorningMailSummary > {
             public MorningMailSummary.SummaryDate summaryDate = new MorningMailSummary.SummaryDate();
        }
         
        public static final class DeletemeInputRecordDeletedIefSupplied extends EntityView<IefSupplied > {
             public IefSupplied.Flag flag = new IefSupplied.Flag();
        }

        public final InputAaRebuildFiles inputAaRebuildFiles = new InputAaRebuildFiles();
        public final InputBadRecordMorningMailSummary inputBadRecordMorningMailSummary = new InputBadRecordMorningMailSummary();
        public final InputRecordsReadIefSupplied inputRecordsReadIefSupplied = new InputRecordsReadIefSupplied();
        public final InputRecordsDeletedIefSupplied inputRecordsDeletedIefSupplied = new InputRecordsDeletedIefSupplied();
        public final InputTa0022EojSummaryFields inputTa0022EojSummaryFields = new InputTa0022EojSummaryFields();
        public final InputAaCkpointControl inputAaCkpointControl = new InputAaCkpointControl();
        public final InputErrorsIefSupplied inputErrorsIefSupplied = new InputErrorsIefSupplied();
        public final DeletemeInputPreviousDateMorningMailSummary deletemeInputPreviousDateMorningMailSummary = new DeletemeInputPreviousDateMorningMailSummary();
        public final DeletemeInputRecordDeletedIefSupplied deletemeInputRecordDeletedIefSupplied = new DeletemeInputRecordDeletedIefSupplied();
    }

    public static final class Exports extends ExportContainer {

         
        public static final class OutputBatchParameter extends EntityView<BatchParameter > {
             public BatchParameter.ProcessIdentifier processIdentifier = new BatchParameter.ProcessIdentifier();
             public BatchParameter.BatchEffectiveDate batchEffectiveDate = new BatchParameter.BatchEffectiveDate();
             public BatchParameter.ReportName reportName = new BatchParameter.ReportName();
        }
         
        public static final class OutputBadRecordMorningMailSummary extends EntityView<MorningMailSummary > {
             public MorningMailSummary.OfficeCode officeCode = new MorningMailSummary.OfficeCode();
             public MorningMailSummary.ActivityCode activityCode = new MorningMailSummary.ActivityCode();
             public MorningMailSummary.SubsystemIdentifier subsystemIdentifier = new MorningMailSummary.SubsystemIdentifier();
             public MorningMailSummary.SummaryDate summaryDate = new MorningMailSummary.SummaryDate();
             public MorningMailSummary.UserIdentifier userIdentifier = new MorningMailSummary.UserIdentifier();
        }
         
        public static final class OutputRecordsReadIefSupplied extends EntityView<IefSupplied > {
             public IefSupplied.Count count = new IefSupplied.Count();
        }
         
        public static final class OutputRecordsDeletedIefSupplied extends EntityView<IefSupplied > {
             public IefSupplied.Count count = new IefSupplied.Count();
        }
         
        public static final class OutputTa0022EojSummaryFields extends EntityView<Ta0022EojSummaryFields > {
             public Ta0022EojSummaryFields.FileMode fileMode = new Ta0022EojSummaryFields.FileMode();
             public Ta0022EojSummaryFields.ProgramId programId = new Ta0022EojSummaryFields.ProgramId();
             public Ta0022EojSummaryFields.ControlAreaType controlAreaType = new Ta0022EojSummaryFields.ControlAreaType();
             public Ta0022EojSummaryFields.Filename filename = new Ta0022EojSummaryFields.Filename();
             public Ta0022EojSummaryFields.ControlType controlType = new Ta0022EojSummaryFields.ControlType();
             public Ta0022EojSummaryFields.Format format = new Ta0022EojSummaryFields.Format();
             public Ta0022EojSummaryFields.ExpectedValue expectedValue = new Ta0022EojSummaryFields.ExpectedValue();
             public Ta0022EojSummaryFields.ActualValue actualValue = new Ta0022EojSummaryFields.ActualValue();
             public Ta0022EojSummaryFields.Difference difference = new Ta0022EojSummaryFields.Difference();
             public Ta0022EojSummaryFields.ReturnCode returnCode = new Ta0022EojSummaryFields.ReturnCode();
             public Ta0022EojSummaryFields.PreviousAreaType previousAreaType = new Ta0022EojSummaryFields.PreviousAreaType();
             public Ta0022EojSummaryFields.PreviousFilename previousFilename = new Ta0022EojSummaryFields.PreviousFilename();
             public Ta0022EojSummaryFields.ProblemOpeningDoc problemOpeningDoc = new Ta0022EojSummaryFields.ProblemOpeningDoc();
             public Ta0022EojSummaryFields.ProblemWritingDoc problemWritingDoc = new Ta0022EojSummaryFields.ProblemWritingDoc();
             public Ta0022EojSummaryFields.NoRecordsDoc noRecordsDoc = new Ta0022EojSummaryFields.NoRecordsDoc();
             public Ta0022EojSummaryFields.NoMatchDoc noMatchDoc = new Ta0022EojSummaryFields.NoMatchDoc();
             public Ta0022EojSummaryFields.FirstTime firstTime = new Ta0022EojSummaryFields.FirstTime();
        }
         
        public static final class OutputAaRebuildFiles extends EntityView<AaRebuildFiles > {
             public AaRebuildFiles.RebuildFlag rebuildFlag = new AaRebuildFiles.RebuildFlag();
        }
         
        public static final class OutputAaCkpointControl extends EntityView<AaCkpointControl > {
             public AaCkpointControl.CpCallingPgmId cpCallingPgmId = new AaCkpointControl.CpCallingPgmId();
             public AaCkpointControl.CpRequestCode cpRequestCode = new AaCkpointControl.CpRequestCode();
             public AaCkpointControl.CpProcessMode cpProcessMode = new AaCkpointControl.CpProcessMode();
             public AaCkpointControl.CpJobNumber cpJobNumber = new AaCkpointControl.CpJobNumber();
             public AaCkpointControl.CpDrivingFileNo cpDrivingFileNo = new AaCkpointControl.CpDrivingFileNo();
             public AaCkpointControl.CpDbOrFileDr cpDbOrFileDr = new AaCkpointControl.CpDbOrFileDr();
             public AaCkpointControl.CpDbRepoData cpDbRepoData = new AaCkpointControl.CpDbRepoData();
        }
         
        public static final class DeletemeOutputRecordDeletedIefSupplied extends EntityView<IefSupplied > {
             public IefSupplied.Flag flag = new IefSupplied.Flag();
        }
         
        public static final class DeletemeOutputPreviousDateMorningMailSummary extends EntityView<MorningMailSummary > {
             public MorningMailSummary.SummaryDate summaryDate = new MorningMailSummary.SummaryDate();
        }
         
        public static final class OutputErrorsIefSupplied extends EntityView<IefSupplied > {
             public IefSupplied.Count count = new IefSupplied.Count();
        }
         
        public static final class DeletemeOutputAa0003ValidatedDates extends EntityView<Aa0003ValidatedDates > {
             public Aa0003ValidatedDates.FunctionCode functionCode = new Aa0003ValidatedDates.FunctionCode();
             public Aa0003ValidatedDates.TotalMonths totalMonths = new Aa0003ValidatedDates.TotalMonths();
             public Aa0003ValidatedDates.TotalDays totalDays = new Aa0003ValidatedDates.TotalDays();
             public Aa0003ValidatedDates.TotalYears totalYears = new Aa0003ValidatedDates.TotalYears();
             public Aa0003ValidatedDates.Date2 date2 = new Aa0003ValidatedDates.Date2();
             public Aa0003ValidatedDates.Date1 date1 = new Aa0003ValidatedDates.Date1();
        }

        public final OutputBatchParameter outputBatchParameter = new OutputBatchParameter();
        public final OutputBadRecordMorningMailSummary outputBadRecordMorningMailSummary = new OutputBadRecordMorningMailSummary();
        public final OutputRecordsReadIefSupplied outputRecordsReadIefSupplied = new OutputRecordsReadIefSupplied();
        public final OutputRecordsDeletedIefSupplied outputRecordsDeletedIefSupplied = new OutputRecordsDeletedIefSupplied();
        public final OutputTa0022EojSummaryFields outputTa0022EojSummaryFields = new OutputTa0022EojSummaryFields();
        public final OutputAaRebuildFiles outputAaRebuildFiles = new OutputAaRebuildFiles();
        public final OutputAaCkpointControl outputAaCkpointControl = new OutputAaCkpointControl();
        public final DeletemeOutputRecordDeletedIefSupplied deletemeOutputRecordDeletedIefSupplied = new DeletemeOutputRecordDeletedIefSupplied();
        public final DeletemeOutputPreviousDateMorningMailSummary deletemeOutputPreviousDateMorningMailSummary = new DeletemeOutputPreviousDateMorningMailSummary();
        public final OutputErrorsIefSupplied outputErrorsIefSupplied = new OutputErrorsIefSupplied();
        public final DeletemeOutputAa0003ValidatedDates deletemeOutputAa0003ValidatedDates = new DeletemeOutputAa0003ValidatedDates();
    }

    private Imports imports = new Imports();
    private Exports exports = new Exports();

     
    public static final class LocalUpdateBatchParameter extends EntityView<BatchParameter >  {
         public BatchParameter.BatchEffectiveDate batchEffectiveDate = new BatchParameter.BatchEffectiveDate();
    }
     
    public static final class LocalCheckpointProgramNumber extends EntityView<ProgramNumber >  {
         public ProgramNumber.CheckpointFrequencyCount checkpointFrequencyCount = new ProgramNumber.CheckpointFrequencyCount();
    }
     
    public static final class LocalTakeChkpntIefSupplied extends EntityView<IefSupplied >  {
         public IefSupplied.Flag flag = new IefSupplied.Flag();
    }
     
    public static final class LocalAa0010ActiveHelp extends EntityView<Aa0010ActiveHelp >  {
         public Aa0010ActiveHelp.Code code = new Aa0010ActiveHelp.Code();
         public Aa0010ActiveHelp.Decode decode = new Aa0010ActiveHelp.Decode();
         public Aa0010ActiveHelp.Helpid helpid = new Aa0010ActiveHelp.Helpid();
         public Aa0010ActiveHelp.ReturnCode returnCode = new Aa0010ActiveHelp.ReturnCode();
    }
     
    public static final class LocalWriteExcptRptIndIefSupplied extends EntityView<IefSupplied >  {
         public IefSupplied.Flag flag = new IefSupplied.Flag();
    }
     
    public static final class LocalTa0027ExceptionFields extends EntityView<Ta0027ExceptionFields >  {
         public Ta0027ExceptionFields.ErrorCode errorCode = new Ta0027ExceptionFields.ErrorCode();
         public Ta0027ExceptionFields.FileMode fileMode = new Ta0027ExceptionFields.FileMode();
         public Ta0027ExceptionFields.RecordKeyName recordKeyName = new Ta0027ExceptionFields.RecordKeyName();
         public Ta0027ExceptionFields.RecordKeyValue recordKeyValue = new Ta0027ExceptionFields.RecordKeyValue();
         public Ta0027ExceptionFields.ErrorDescription errorDescription = new Ta0027ExceptionFields.ErrorDescription();
         public Ta0027ExceptionFields.ReturnCode returnCode = new Ta0027ExceptionFields.ReturnCode();
         public Ta0027ExceptionFields.SourceCode sourceCode = new Ta0027ExceptionFields.SourceCode();
         public Ta0027ExceptionFields.ProgramId programId = new Ta0027ExceptionFields.ProgramId();
    }
     
    public static final class LocalMorningMailSummary extends EntityView<MorningMailSummary >  {
         public MorningMailSummary.ActivityCode activityCode = new MorningMailSummary.ActivityCode();
         public MorningMailSummary.OfficeCode officeCode = new MorningMailSummary.OfficeCode();
         public MorningMailSummary.SummaryDate summaryDate = new MorningMailSummary.SummaryDate();
         public MorningMailSummary.SubsystemIdentifier subsystemIdentifier = new MorningMailSummary.SubsystemIdentifier();
         public MorningMailSummary.UserIdentifier userIdentifier = new MorningMailSummary.UserIdentifier();
         public MorningMailSummary.StaffTypeCode staffTypeCode = new MorningMailSummary.StaffTypeCode();
         public MorningMailSummary.DueTotalCount dueTotalCount = new MorningMailSummary.DueTotalCount();
         public MorningMailSummary.WorkerOverdueTotalCount workerOverdueTotalCount = new MorningMailSummary.WorkerOverdueTotalCount();
         public MorningMailSummary.ManagerOverdueCount managerOverdueCount = new MorningMailSummary.ManagerOverdueCount();
         public MorningMailSummary.DueCompletedTotalCount dueCompletedTotalCount = new MorningMailSummary.DueCompletedTotalCount();
         public MorningMailSummary.WorkerOverdueCompleteTtlCnt workerOverdueCompleteTtlCnt = new MorningMailSummary.WorkerOverdueCompleteTtlCnt();
         public MorningMailSummary.ManagerOverdueCompletedCount managerOverdueCompletedCount = new MorningMailSummary.ManagerOverdueCompletedCount();
    }
     
    public static final class LocalAaFileControl extends EntityView<AaFileControl >  {
         public AaFileControl.FcIoFileStatus fcIoFileStatus = new AaFileControl.FcIoFileStatus();
         public AaFileControl.FcIoReturnCode fcIoReturnCode = new AaFileControl.FcIoReturnCode();
         public AaFileControl.FcIoFileReturn fcIoFileReturn = new AaFileControl.FcIoFileReturn();
    }
     
    public static final class LocalRecordDeletedIefSupplied extends EntityView<IefSupplied >  {
         public IefSupplied.Flag flag = new IefSupplied.Flag();
    }
     
    public static final class LocalPreviousMorningMailSummary extends EntityView<MorningMailSummary >  {
         public MorningMailSummary.OfficeCode officeCode = new MorningMailSummary.OfficeCode();
         public MorningMailSummary.ActivityCode activityCode = new MorningMailSummary.ActivityCode();
         public MorningMailSummary.SubsystemIdentifier subsystemIdentifier = new MorningMailSummary.SubsystemIdentifier();
         public MorningMailSummary.SummaryDate summaryDate = new MorningMailSummary.SummaryDate();
         public MorningMailSummary.UserIdentifier userIdentifier = new MorningMailSummary.UserIdentifier();
    }
     
    public static final class LocalRecordsReadIefSupplied extends EntityView<IefSupplied >  {
         public IefSupplied.Count count = new IefSupplied.Count();
    }
     
    public static final class LocalRecordsDeletedIefSupplied extends EntityView<IefSupplied >  {
         public IefSupplied.Count count = new IefSupplied.Count();
    }
     
    public static final class LocalIefSupplied extends EntityView<IefSupplied >  {
         public IefSupplied.Count count = new IefSupplied.Count();
         public IefSupplied.Flag flag = new IefSupplied.Flag();
    }
     
    public static final class Local30dayMorningMailSummary extends EntityView<MorningMailSummary >  {
         public MorningMailSummary.ActivityCode activityCode = new MorningMailSummary.ActivityCode();
         public MorningMailSummary.OfficeCode officeCode = new MorningMailSummary.OfficeCode();
         public MorningMailSummary.SummaryDate summaryDate = new MorningMailSummary.SummaryDate();
         public MorningMailSummary.SubsystemIdentifier subsystemIdentifier = new MorningMailSummary.SubsystemIdentifier();
         public MorningMailSummary.UserIdentifier userIdentifier = new MorningMailSummary.UserIdentifier();
    }
     
    public static final class LocalAa0009NextPrevBusinessDay extends EntityView<Aa0009NextPrevBusinessDay >  {
         public Aa0009NextPrevBusinessDay.ReturnCode returnCode = new Aa0009NextPrevBusinessDay.ReturnCode();
         public Aa0009NextPrevBusinessDay.EnterDate enterDate = new Aa0009NextPrevBusinessDay.EnterDate();
         public Aa0009NextPrevBusinessDay.ReturnedDate returnedDate = new Aa0009NextPrevBusinessDay.ReturnedDate();
         public Aa0009NextPrevBusinessDay.Indicator indicator = new Aa0009NextPrevBusinessDay.Indicator();
    }
     
    public static final class Local1Aa0009NextPrevBusinessDay extends EntityView<Aa0009NextPrevBusinessDay >  {
         public Aa0009NextPrevBusinessDay.Indicator indicator = new Aa0009NextPrevBusinessDay.Indicator();
         public Aa0009NextPrevBusinessDay.ReturnCode returnCode = new Aa0009NextPrevBusinessDay.ReturnCode();
         public Aa0009NextPrevBusinessDay.EnterDate enterDate = new Aa0009NextPrevBusinessDay.EnterDate();
         public Aa0009NextPrevBusinessDay.ReturnedDate returnedDate = new Aa0009NextPrevBusinessDay.ReturnedDate();
    }
     
    public static final class LocalAa0003ValidatedDates extends EntityView<Aa0003ValidatedDates >  {
         public Aa0003ValidatedDates.Date1 date1 = new Aa0003ValidatedDates.Date1();
         public Aa0003ValidatedDates.ReturnCode returnCode = new Aa0003ValidatedDates.ReturnCode();
         public Aa0003ValidatedDates.TextDays textDays = new Aa0003ValidatedDates.TextDays();
         public Aa0003ValidatedDates.TextMonth textMonth = new Aa0003ValidatedDates.TextMonth();
         public Aa0003ValidatedDates.TextYearYyyy textYearYyyy = new Aa0003ValidatedDates.TextYearYyyy();
         public Aa0003ValidatedDates.ConcatenatedDate concatenatedDate = new Aa0003ValidatedDates.ConcatenatedDate();
    }
     
    public static final class LocalExceptionIefSupplied extends EntityView<IefSupplied >  {
         public IefSupplied.Count count = new IefSupplied.Count();
    }
     
    public static final class DeleteMeNextEndDateAaDatetimeAttributes extends EntityView<AaDatetimeAttributes >  {
         public AaDatetimeAttributes.Date date = new AaDatetimeAttributes.Date();
    }
     
    public static final class DeletemeLocalOfficeChangeIefSupplied extends EntityView<IefSupplied >  {
         public IefSupplied.Flag flag = new IefSupplied.Flag();
    }
     
    public static final class DeleteMeLocalHoldBadRecAaCkpointControl extends EntityView<AaCkpointControl >  {
         public AaCkpointControl.CpDbRepoData cpDbRepoData = new AaCkpointControl.CpDbRepoData();
    }
     
    public static final class ActionBatchParameter extends PersistentEntityView<BatchParameter > {
         public BatchParameter.ProcessIdentifier processIdentifier = new BatchParameter.ProcessIdentifier();
         public BatchParameter.BatchEffectiveDate batchEffectiveDate = new BatchParameter.BatchEffectiveDate();
         public BatchParameter.ReportName reportName = new BatchParameter.ReportName();
    }
     
    public static final class ActionMorningMailSummary extends PersistentEntityView<MorningMailSummary > {
         public MorningMailSummary.ActivityCode activityCode = new MorningMailSummary.ActivityCode();
         public MorningMailSummary.OfficeCode officeCode = new MorningMailSummary.OfficeCode();
         public MorningMailSummary.SummaryDate summaryDate = new MorningMailSummary.SummaryDate();
         public MorningMailSummary.SubsystemIdentifier subsystemIdentifier = new MorningMailSummary.SubsystemIdentifier();
         public MorningMailSummary.UserIdentifier userIdentifier = new MorningMailSummary.UserIdentifier();
    }
     
    public static final class ActionProgramNumber extends PersistentEntityView<ProgramNumber > {
         public ProgramNumber.ProcedureIdentifier procedureIdentifier = new ProgramNumber.ProcedureIdentifier();
         public ProgramNumber.ProcedureName procedureName = new ProgramNumber.ProcedureName();
         public ProgramNumber.ProcedureStartTypeCode procedureStartTypeCode = new ProgramNumber.ProcedureStartTypeCode();
         public ProgramNumber.DbOrFileDrCode dbOrFileDrCode = new ProgramNumber.DbOrFileDrCode();
         public ProgramNumber.CheckpointFrequencyCount checkpointFrequencyCount = new ProgramNumber.CheckpointFrequencyCount();
    }
    public final LocalUpdateBatchParameter localUpdateBatchParameter = new LocalUpdateBatchParameter();
    public final LocalCheckpointProgramNumber localCheckpointProgramNumber = new LocalCheckpointProgramNumber();
    public final LocalTakeChkpntIefSupplied localTakeChkpntIefSupplied = new LocalTakeChkpntIefSupplied();
    public final LocalAa0010ActiveHelp localAa0010ActiveHelp = new LocalAa0010ActiveHelp();
    public final LocalWriteExcptRptIndIefSupplied localWriteExcptRptIndIefSupplied = new LocalWriteExcptRptIndIefSupplied();
    public final LocalTa0027ExceptionFields localTa0027ExceptionFields = new LocalTa0027ExceptionFields();
    public final LocalMorningMailSummary localMorningMailSummary = new LocalMorningMailSummary();
    public final LocalAaFileControl localAaFileControl = new LocalAaFileControl();
    public final LocalRecordDeletedIefSupplied localRecordDeletedIefSupplied = new LocalRecordDeletedIefSupplied();
    public final LocalPreviousMorningMailSummary localPreviousMorningMailSummary = new LocalPreviousMorningMailSummary();
    public final LocalRecordsReadIefSupplied localRecordsReadIefSupplied = new LocalRecordsReadIefSupplied();
    public final LocalRecordsDeletedIefSupplied localRecordsDeletedIefSupplied = new LocalRecordsDeletedIefSupplied();
    public final LocalIefSupplied localIefSupplied = new LocalIefSupplied();
    public final Local30dayMorningMailSummary local30dayMorningMailSummary = new Local30dayMorningMailSummary();
    public final LocalAa0009NextPrevBusinessDay localAa0009NextPrevBusinessDay = new LocalAa0009NextPrevBusinessDay();
    public final Local1Aa0009NextPrevBusinessDay local1Aa0009NextPrevBusinessDay = new Local1Aa0009NextPrevBusinessDay();
    public final LocalAa0003ValidatedDates localAa0003ValidatedDates = new LocalAa0003ValidatedDates();
    public final LocalExceptionIefSupplied localExceptionIefSupplied = new LocalExceptionIefSupplied();
    public final DeleteMeNextEndDateAaDatetimeAttributes deleteMeNextEndDateAaDatetimeAttributes = new DeleteMeNextEndDateAaDatetimeAttributes();
    public final DeletemeLocalOfficeChangeIefSupplied deletemeLocalOfficeChangeIefSupplied = new DeletemeLocalOfficeChangeIefSupplied();
    public final DeleteMeLocalHoldBadRecAaCkpointControl deleteMeLocalHoldBadRecAaCkpointControl = new DeleteMeLocalHoldBadRecAaCkpointControl();
    public final ActionBatchParameter actionBatchParameter = new ActionBatchParameter();
    public final ActionMorningMailSummary actionMorningMailSummary = new ActionMorningMailSummary();
    public final ActionProgramNumber actionProgramNumber = new ActionProgramNumber();

    @Override
    public void run() {
        // DELETEMEDELETEMEDELETEMEDELETEMEDELETEME
        // 
        // These attributes need to be deleted.  The
        // entities are used but the specific attributes
        // are not.
        // 
        // OUTPUT TA0022 EOJ SUMMARY FIELDS
        // EXPECTED VALUE
        // PROBLEM OPENING DOC
        // PROBLEM WRITING DOC
        // NO MATCH DOC
        // 
        // LOCAL MORNING MAIL SUMMARY
        // STAFF TYPE CODE
        // DUE TOTAL COUNT
        // WORKER OVERDUE TOTAL COUNT
        // MANAGER OVERDUE COUNT
        // DUE COMPLETED TOTAL COUNT
        // WORKER OVERDUE COMPLETE TTL CNT
        // MANAGER OVERDUE COMPLETED COUNT
        // 
        // LOCAL 30DAY MORNING MAIL SUMMARY
        // IDENTIFIER K ACTIVITY CODE
        // OFFICE CODE
        // SUBSYSTEM IDENTIFIER
        // USER IDENTIFIER
        // 
        // ---------------------------------------------
        // ---------------------------------------------
        // ANDERSEN CONSULTING
        // 03/28/94        Valerie Eby
        // Initial Coding
        // 
        // Modifications:
        // 08/31/95	Chad M. Lindsey
        // Including Error Handling and Exception
        // Reporting.
        // 11/20/95	Jana Brown
        // Changed control area type from "O" to "P".
        // 11/21/95	Jana Brown
        // Set the first time indicator to "N" so that
        // the program will not try to re-open a file.
        // 01/03/96	Jana Brown
        // Removed the DELETE logic the was outside of
        // the READ EACH for mail summary.
        // 01/08/96	Jana Brown
        // Modified checkpointing and exception logic.
        // Added check for valid business day before
        // updating the batch parameter date.
        // 02/29/96	Jana Brown
        // NM SIR #924 - Added error count and
        // exception source code.
        // 06/06/96	Jana Brown
        // NM SIR #1294 - Modified the body of the
        // program to read and evaluate each morning
        // mail summary record. This is necessary so
        // that all records greater than 30 days old
        // will be deleted. Also had to modify the
        // checkpointing to include the summary date.
        // 
        // NM SIR #1564	D Wadhwani	03/10/98
        // Added the program name to the heading in
        // the exception report.
        // ---------------------------------------------

        // ---------------------------------------------
        // THIS MODULE READS THE MORNING_MAIL_SUMMARY
        // TABLE AND DELETES ANY RECORDS THAT ARE OVER
        // THIRTY-ONE DAYS OLD.
        // ---------------------------------------------

        // *
        // *  THIS IS THE HOUSEKEEPING SECTION OF LOGIC
        // *
        setExitState(AaAdsCommonObjects.AA559_I_ALL_OK);
        move(imports.inputTa0022EojSummaryFields).to(exports.outputTa0022EojSummaryFields);
        move(imports.inputAaCkpointControl).to(exports.outputAaCkpointControl);
        move(imports.inputAaRebuildFiles).to(exports.outputAaRebuildFiles);

        // ------------
        // NM SIR #924
        // ------------
        move(imports.inputErrorsIefSupplied).to(exports.outputErrorsIefSupplied);

        move(imports.inputRecordsDeletedIefSupplied).to(localRecordsDeletedIefSupplied);
        move(imports.inputRecordsDeletedIefSupplied).to(exports.outputRecordsDeletedIefSupplied);

        move(imports.inputRecordsReadIefSupplied).to(localRecordsReadIefSupplied);
        move(imports.inputRecordsReadIefSupplied).to(exports.outputRecordsReadIefSupplied);


        escape60492014:
        try {
            read( actionProgramNumber ).allowMultiple().where(
                that(actionProgramNumber).attribute(actionProgramNumber.procedureIdentifier).isEqualTo(valueOf(getTransactionCode())) );
            exports.outputTa0022EojSummaryFields.programId.setValue(getTransactionCode());
            exports.outputTa0022EojSummaryFields.difference.setValue(TextAttribute.of("N"));

            exports.outputAaCkpointControl.cpCallingPgmId.setValue(actionProgramNumber.procedureIdentifier);
            exports.outputAaCkpointControl.cpDbOrFileDr.setValue(actionProgramNumber.dbOrFileDrCode);
            exports.outputAaCkpointControl.cpRequestCode.setValue(actionProgramNumber.procedureStartTypeCode);

            // ---------------------------------------------
            // NM SIR #1564	D Wadhwani	03/10/98
            // Added SET statement to provide program name
            // on batch exception reports.
            // ---------------------------------------------

            localTa0027ExceptionFields.programId.setValue(getTransactionCode());


            escape60496528:
            try {
                read( actionBatchParameter ).allowMultiple().where(
                    that(actionBatchParameter).attribute(actionBatchParameter.processIdentifier).isEqualTo(valueOf(getTransactionCode())) );
                move(actionBatchParameter).to(exports.outputBatchParameter);
            } catch (NotFoundException e60496528) {
                setExitState(TaTechnicalArchitecture.TA903_A_BATCH_PARAMETER_NF);
                return;
            }

            escape60442995:
            if (exports.outputAaCkpointControl.cpProcessMode.equals(TextAttribute.of("NM")) && (exports.outputAaRebuildFiles.rebuildFlag.equals(TextAttribute.of("X")))) {
                exports.outputAaRebuildFiles.rebuildFlag.setValue(TextAttribute.of(Constant.SPACES));

            } else {
                // ---------------------------------------------
                // The job number and rebuild flag are read from
                // an external file which is created by the JCL.
                // ---------------------------------------------

                use(action(TaCheckRebuildFlag.class)
                        .whichExportsView(exports.outputAaCkpointControl).from(exports -> exports.outputAaCkpointControl)
                        .whichExportsView(exports.outputAaRebuildFiles).from(exports -> exports.outputAaRebuildFiles)
                        .whichExportsView(localAaFileControl).from(exports -> exports.outputAaFileControl)
                    );

                escape60435524:
                if (localAaFileControl.fcIoReturnCode.equals(TextAttribute.of("PE")) || (localAaFileControl.fcIoReturnCode.equals(TextAttribute.of("OE"))) || (localAaFileControl.fcIoReturnCode.equals(TextAttribute.of("SE"))) || (localAaFileControl.fcIoReturnCode.equals(TextAttribute.of("DE")))) {
                    setExitState(TaTechnicalArchitecture.TA900_A_ERROR_EXISTS);
                    return;
                }

                use(action(TaCheckpointTest.class)
                        .whichImportsView(exports.outputAaRebuildFiles).to(imports -> imports.importAaRebuildFiles)
                        .whichImportsView(exports.outputAaCkpointControl).to(imports -> imports.importAaCkpointControl)
                        .whichExportsView(exports.outputAaRebuildFiles).from(exports -> exports.exportAaRebuildFiles)
                        .whichExportsView(exports.outputAaCkpointControl).from(exports -> exports.exportAaCkpointControl)
                    );

                // ---------------------------------------------
                // IF THE MODULE IS IN RESTART MODE, THE KEY
                // IDENTIFIERS OF THE MORNING_MAIL_SUMMARY
                // RECORD LAST DELETED MUST BE UNSTRUNG.
                // ---------------------------------------------


                escape60435463:
                if (getExitState().equals(TaTechnicalArchitecture.TA503_I_CHECKPOINT_SUCCESS) && (exports.outputAaCkpointControl.cpProcessMode.equals(TextAttribute.of("RM")))) {
                    // ---------------------------------------------
                    // Unstring the checkpoint data
                    // ---------------------------------------------

                    localAa0003ValidatedDates.textYearYyyy.setValue(substr(exports.outputAaCkpointControl.cpDbRepoData, NumericAttribute.of(1), NumericAttribute.of(4)));
                    localAa0003ValidatedDates.textMonth.setValue(substr(exports.outputAaCkpointControl.cpDbRepoData, NumericAttribute.of(5), NumericAttribute.of(6)));
                    localAa0003ValidatedDates.textDays.setValue(substr(exports.outputAaCkpointControl.cpDbRepoData, NumericAttribute.of(7), NumericAttribute.of(8)));
                    localPreviousMorningMailSummary.officeCode.setValue(substr(exports.outputAaCkpointControl.cpDbRepoData, NumericAttribute.of(9), NumericAttribute.of(13)));
                    localPreviousMorningMailSummary.userIdentifier.setValue(substr(exports.outputAaCkpointControl.cpDbRepoData, NumericAttribute.of(14), NumericAttribute.of(21)));
                    localPreviousMorningMailSummary.activityCode.setValue(substr(exports.outputAaCkpointControl.cpDbRepoData, NumericAttribute.of(22), NumericAttribute.of(26)));
                    localPreviousMorningMailSummary.subsystemIdentifier.setValue(substr(exports.outputAaCkpointControl.cpDbRepoData, NumericAttribute.of(27), NumericAttribute.of(28)));

                    use(action(AaConvertTextToDate.class)
                            .whichImportsView(localAa0003ValidatedDates).to(imports -> imports.inputAa0003ValidatedDates)
                            .whichExportsView(localAa0003ValidatedDates).from(exports -> exports.outputAa0003ValidatedDates)
                        );

                    escape60444726:
                    if (localAa0003ValidatedDates.returnCode.compareTo(TextAttribute.of("0")) > 0) {
                        setExitState(TaTechnicalArchitecture.TA900_A_ERROR_EXISTS);
                        return;
                    }

                    localPreviousMorningMailSummary.summaryDate.setValue(localAa0003ValidatedDates.concatenatedDate);
                } else {
                    escape60443040:
                    if (! getExitState().equals(TaTechnicalArchitecture.TA503_I_CHECKPOINT_SUCCESS)) {
                        setExitState(TaTechnicalArchitecture.TA900_A_ERROR_EXISTS);
                        return;
                    }
                }
                exports.outputTa0022EojSummaryFields.fileMode.setValue(TextAttribute.of(Constant.SPACES));

                escape60435464:
                if (exports.outputAaCkpointControl.cpProcessMode.equals(TextAttribute.of("RM")) && (exports.outputAaRebuildFiles.rebuildFlag.equals(TextAttribute.of("Y")))) {
                    exports.outputTa0022EojSummaryFields.fileMode.setValue(TextAttribute.of("RS"));

                } else if (! exports.outputTa0022EojSummaryFields.firstTime.equals(TextAttribute.of("N"))) {
                    exports.outputTa0022EojSummaryFields.fileMode.setValue(TextAttribute.of("OP"));
                    localTa0027ExceptionFields.fileMode.setValue(TextAttribute.of("OP"));

                }

                escape60435532:
                if (! exports.outputTa0022EojSummaryFields.fileMode.equals(TextAttribute.of(Constant.SPACES))) {
                    use(action(TaEojSummaryCab.class)
                            .whichImportsView(exports.outputAaRebuildFiles).to(imports -> imports.inputAaRebuildFiles)
                            .whichImportsView(exports.outputTa0022EojSummaryFields).to(imports -> imports.inputTa0022EojSummaryFields)
                            .whichExportsView(exports.outputAaRebuildFiles).from(exports -> exports.outputAaRebuildFiles)
                            .whichExportsView(exports.outputTa0022EojSummaryFields).from(exports -> exports.outputTa0022EojSummaryFields)
                        );

                    use(action(TaExceptionCab.class)
                            .whichImportsView(exports.outputAaRebuildFiles).to(imports -> imports.inputAaRebuildFiles)
                            .whichImportsView(localTa0027ExceptionFields).to(imports -> imports.inputTa0027ExceptionFields)
                            .whichExportsView(localTa0027ExceptionFields).from(exports -> exports.outputTa0027ExceptionFields)
                        );

                    escape60443028:
                    if (exports.outputTa0022EojSummaryFields.returnCode.compareTo(NumericAttribute.of(0)) > 0 || (localTa0027ExceptionFields.returnCode.compareTo(TextAttribute.of("00")) > 0)) {
                        setExitState(TaTechnicalArchitecture.TA900_A_ERROR_EXISTS);
                        return;
                    }
                }

                // ---------------------------------------------
                // Set the first time indicator to "N" so that
                // the program will not try to re-open a file.
                // ---------------------------------------------
                exports.outputTa0022EojSummaryFields.firstTime.setValue(TextAttribute.of("N"));

            }

        } catch (NotFoundException e60492014) {
            setExitState(TaTechnicalArchitecture.TA900_A_ERROR_EXISTS);
            return;
        }

        localIefSupplied.count.setValueRounded(NumericAttribute.of(0));

        // ---------------------------------------------
        // EACH RECORD ON MORNING_MAIL_SUMMARY IS READ.
        // IF THE RECORD'S SUMMARY_DATE IS GREATER THAN
        // THIRTY-ONE DAYS FROM THE CURRENT DATE, IT IS
        // DELETED.
        // ---------------------------------------------

        escape60444717: try (ReadEachIterator iterator60444717 = readEach(actionMorningMailSummary )
                .distinctDefault()
                .where( (((that(actionMorningMailSummary).attribute(actionMorningMailSummary.summaryDate).isEqualTo(valueOf(localPreviousMorningMailSummary.summaryDate))).and(that(actionMorningMailSummary).attribute(actionMorningMailSummary.officeCode).isEqualTo(valueOf(localPreviousMorningMailSummary.officeCode)))).and(that(actionMorningMailSummary).attribute(actionMorningMailSummary.userIdentifier).isEqualTo(valueOf(localPreviousMorningMailSummary.userIdentifier)))).and(bracket((that(actionMorningMailSummary).attribute(actionMorningMailSummary.activityCode).isGreaterThan(valueOf(localPreviousMorningMailSummary.activityCode))).or(bracket((that(actionMorningMailSummary).attribute(actionMorningMailSummary.activityCode).isEqualTo(valueOf(localPreviousMorningMailSummary.activityCode))).and(that(actionMorningMailSummary).attribute(actionMorningMailSummary.subsystemIdentifier).isGreaterThan(valueOf(localPreviousMorningMailSummary.subsystemIdentifier))))))))
                .orderedBy(ascending(desired(actionMorningMailSummary).attribute(actionMorningMailSummary.summaryDate)) , ascending(desired(actionMorningMailSummary).attribute(actionMorningMailSummary.officeCode)) , ascending(desired(actionMorningMailSummary).attribute(actionMorningMailSummary.userIdentifier)) , ascending(desired(actionMorningMailSummary).attribute(actionMorningMailSummary.activityCode)) , ascending(desired(actionMorningMailSummary).attribute(actionMorningMailSummary.subsystemIdentifier)) )
                .targeting()) {
            while (iterator60444717.hasNext()) {
                iterator60444717.next();
                move(actionMorningMailSummary).to(localPreviousMorningMailSummary);

                // --------------------------------------------------------
                // Check for Bad Record, If found commit database and skip.
                // --------------------------------------------------------

                escape60444719:
                if (actionMorningMailSummary.summaryDate.equals(imports.inputBadRecordMorningMailSummary.summaryDate) && (actionMorningMailSummary.officeCode.equals(imports.inputBadRecordMorningMailSummary.officeCode)) && (actionMorningMailSummary.userIdentifier.equals(imports.inputBadRecordMorningMailSummary.userIdentifier)) && (actionMorningMailSummary.activityCode.equals(imports.inputBadRecordMorningMailSummary.activityCode)) && (actionMorningMailSummary.subsystemIdentifier.equals(imports.inputBadRecordMorningMailSummary.subsystemIdentifier))) {
                    localTakeChkpntIefSupplied.flag.setValue(TextAttribute.of("Y"));

                    break escape60444717;
                }

                local30dayMorningMailSummary.summaryDate.setValue(actionMorningMailSummary.summaryDate.plus(days(NumericAttribute.of(30))));
                localRecordsReadIefSupplied.count.setValueRounded(localRecordsReadIefSupplied.count.plus(NumericAttribute.of(1)));
                localRecordDeletedIefSupplied.flag.setValue(TextAttribute.of("N"));

                escape60435467:
                if (exports.outputBatchParameter.batchEffectiveDate.compareTo(local30dayMorningMailSummary.summaryDate) > 0) {
                    move(actionMorningMailSummary).to(localMorningMailSummary);

                    setExitState(AaAdsCommonObjects.AA152_B_UNEXPECTED_ERROR);

                    use(action(CmeDeleteMorningMailSumm.class)
                            .whichImportsView(localMorningMailSummary).to(imports -> imports.inputMorningMailSummary)
                        );

                    escape60443029:
                    if (getExitState().equals(AaAdsCommonObjects.AA538_I_SUCCESSFUL_DELETE)) {
                        localRecordsDeletedIefSupplied.count.setValueRounded(localRecordsDeletedIefSupplied.count.plus(NumericAttribute.of(1)));
                        localRecordDeletedIefSupplied.flag.setValue(TextAttribute.of("Y"));

                    } else if (getExitState().equals(CmCaseManagement.CM135_E_MORNING_MAIL_SUMMARY_NF)) {
                        setExitState(CmCaseManagement.CM135_B_MORNING_MAIL_SUMMARY_NF);
                        localTa0027ExceptionFields.errorCode.setValue(TextAttribute.of("DU"));
                        localTa0027ExceptionFields.sourceCode.setValue(TextAttribute.of("SUMD"));

                    } else {
                        localTa0027ExceptionFields.errorCode.setValue(TextAttribute.of("91"));
                        setExitState(AaAdsCommonObjects.AA152_B_UNEXPECTED_ERROR);
                        localTa0027ExceptionFields.sourceCode.setValue(TextAttribute.of("SUMD"));
                    }

                    escape60435550:
                    if (! getExitState().equals(AaAdsCommonObjects.AA538_I_SUCCESSFUL_DELETE)) {
                        localWriteExcptRptIndIefSupplied.flag.setValue(TextAttribute.of("Y"));
                        break escape60444717;
                    }
                }

                exports.outputTa0022EojSummaryFields.firstTime.setValue(TextAttribute.of("N"));
                localIefSupplied.count.setValueRounded(localIefSupplied.count.plus(NumericAttribute.of(1)));
                localCheckpointProgramNumber.checkpointFrequencyCount.setValueRounded(localIefSupplied.count);

                escape60435465:
                if (localCheckpointProgramNumber.checkpointFrequencyCount.compareTo(actionProgramNumber.checkpointFrequencyCount) >= 0) {
                    localTakeChkpntIefSupplied.flag.setValue(TextAttribute.of("Y"));
                    break escape60444717;
                }

            }
        }

        escape60444718:
        if (! localTakeChkpntIefSupplied.flag.equals(TextAttribute.of("Y")) && (! localWriteExcptRptIndIefSupplied.flag.equals(TextAttribute.of("Y")))) {
            // -------------------------------------
            // Find the next userid to process.
            // -------------------------------------
            escape60444720: try (ReadEachIterator iterator60444720 = readEach(actionMorningMailSummary )
                    .distinctDefault()
                    .where( ((that(actionMorningMailSummary).attribute(actionMorningMailSummary.summaryDate).isEqualTo(valueOf(localPreviousMorningMailSummary.summaryDate))).and(that(actionMorningMailSummary).attribute(actionMorningMailSummary.officeCode).isEqualTo(valueOf(localPreviousMorningMailSummary.officeCode)))).and(that(actionMorningMailSummary).attribute(actionMorningMailSummary.userIdentifier).isGreaterThan(valueOf(localPreviousMorningMailSummary.userIdentifier))))
                    .orderedBy(ascending(desired(actionMorningMailSummary).attribute(actionMorningMailSummary.summaryDate)) , ascending(desired(actionMorningMailSummary).attribute(actionMorningMailSummary.officeCode)) , ascending(desired(actionMorningMailSummary).attribute(actionMorningMailSummary.userIdentifier)) )
                    .targeting()) {
                while (iterator60444720.hasNext()) {
                    iterator60444720.next();
                    localPreviousMorningMailSummary.userIdentifier.setValue(actionMorningMailSummary.userIdentifier);
                    localPreviousMorningMailSummary.activityCode.setValue(TextAttribute.of(Constant.SPACES));
                    localTakeChkpntIefSupplied.flag.setValue(TextAttribute.of("Y"));
                    break escape60444718;
                }
            }

            // -------------------------------------
            // Find the next office to process.
            // -------------------------------------
            escape60444721: try (ReadEachIterator iterator60444721 = readEach(actionMorningMailSummary )
                    .distinctDefault()
                    .where( (that(actionMorningMailSummary).attribute(actionMorningMailSummary.summaryDate).isEqualTo(valueOf(localPreviousMorningMailSummary.summaryDate))).and(that(actionMorningMailSummary).attribute(actionMorningMailSummary.officeCode).isGreaterThan(valueOf(localPreviousMorningMailSummary.officeCode))))
                    .orderedBy(ascending(desired(actionMorningMailSummary).attribute(actionMorningMailSummary.summaryDate)) , ascending(desired(actionMorningMailSummary).attribute(actionMorningMailSummary.officeCode)) )
                    .targeting()) {
                while (iterator60444721.hasNext()) {
                    iterator60444721.next();
                    localPreviousMorningMailSummary.officeCode.setValue(actionMorningMailSummary.officeCode);
                    localPreviousMorningMailSummary.userIdentifier.setValue(TextAttribute.of(Constant.SPACES));
                    localPreviousMorningMailSummary.activityCode.setValue(TextAttribute.of(Constant.SPACES));
                    localTakeChkpntIefSupplied.flag.setValue(TextAttribute.of("Y"));
                    break escape60444718;
                }
            }

            // ---------------------------------------
            // Find the next summary date to process.
            // ---------------------------------------
            escape60444722: try (ReadEachIterator iterator60444722 = readEach(actionMorningMailSummary )
                    .distinctDefault()
                    .where( that(actionMorningMailSummary).attribute(actionMorningMailSummary.summaryDate).isGreaterThan(valueOf(localPreviousMorningMailSummary.summaryDate)))
                    .orderedBy(ascending(desired(actionMorningMailSummary).attribute(actionMorningMailSummary.summaryDate)) )
                    .targeting()) {
                while (iterator60444722.hasNext()) {
                    iterator60444722.next();
                    localPreviousMorningMailSummary.summaryDate.setValue(actionMorningMailSummary.summaryDate);
                    localPreviousMorningMailSummary.officeCode.setValue(TextAttribute.of(Constant.SPACES));
                    localPreviousMorningMailSummary.userIdentifier.setValue(TextAttribute.of(Constant.SPACES));
                    localPreviousMorningMailSummary.activityCode.setValue(TextAttribute.of(Constant.SPACES));
                    localTakeChkpntIefSupplied.flag.setValue(TextAttribute.of("Y"));
                    break escape60444718;
                }
            }
        }


        escape60442996:
        if (localWriteExcptRptIndIefSupplied.flag.equals(TextAttribute.of("Y"))) {
            // ------------
            // NM SIR #924
            // ------------
            exports.outputErrorsIefSupplied.count.setValue(exports.outputErrorsIefSupplied.count.plus(NumericAttribute.of(1)));

            escape60442997:
            if (exports.outputAaCkpointControl.cpProcessMode.equals(TextAttribute.of("NM"))) {
                exports.outputAaRebuildFiles.rebuildFlag.setValue(TextAttribute.of("X"));
            }


            // ---------------------------------------------
            // This REPEAT and CASE OF statement will write
            // out the four lines of the Exception Report
            // needed when check pointing on four different
            // entity identifiers.
            // ---------------------------------------------

            escape60444723:
            do {
                localExceptionIefSupplied.count.setValue(localExceptionIefSupplied.count.plus(NumericAttribute.of(1)));

                escape60444725:
                if (localExceptionIefSupplied.count.equals(NumericAttribute.of(1))) {
                    localAa0003ValidatedDates.date1.setValue(localPreviousMorningMailSummary.summaryDate);

                    use(action(AaConvertDateToText.class)
                            .whichImportsView(localAa0003ValidatedDates).to(imports -> imports.inputAa0003ValidatedDates)
                            .whichExportsView(localAa0003ValidatedDates).from(exports -> exports.outputAa0003ValidatedDates)
                        );

                    escape60444727:
                    if (localAa0003ValidatedDates.returnCode.compareTo(TextAttribute.of("0")) > 0) {
                        setExitState(TaTechnicalArchitecture.TA900_A_ERROR_EXISTS);
                        return;
                    }

                    localTa0027ExceptionFields.recordKeyName.setValue(TextAttribute.of("SUMMARY DATE"));
                    localTa0027ExceptionFields.recordKeyValue.setValue(concat(concat(localAa0003ValidatedDates.textYearYyyy, localAa0003ValidatedDates.textMonth), localAa0003ValidatedDates.textDays));

                } else if (localExceptionIefSupplied.count.equals(NumericAttribute.of(2))) {
                    localTa0027ExceptionFields.recordKeyName.setValue(TextAttribute.of("OFFICE\\USER"));
                    localTa0027ExceptionFields.recordKeyValue.setValue(concat(concat(localPreviousMorningMailSummary.officeCode, TextAttribute.of("\\")), localPreviousMorningMailSummary.userIdentifier));

                } else if (localExceptionIefSupplied.count.equals(NumericAttribute.of(3))) {
                    localTa0027ExceptionFields.recordKeyName.setValue(TextAttribute.of("SUBSYS\\ACTIVITY"));
                    localTa0027ExceptionFields.recordKeyValue.setValue(concat(concat(localPreviousMorningMailSummary.subsystemIdentifier, TextAttribute.of("\\")), localPreviousMorningMailSummary.activityCode));

                } else {
                    setExitState(TaTechnicalArchitecture.TA900_A_ERROR_EXISTS);
                    return;
                }

                localAa0010ActiveHelp.code.setValue(localTa0027ExceptionFields.errorCode);
                localAa0010ActiveHelp.helpid.setValue(TextAttribute.of("HIDSHS000700"));

                use(action(HsAaValGenericCodes.class)
                        .whichImportsView(localAa0010ActiveHelp).to(imports -> imports.inputAa0010ActiveHelp)
                        .whichExportsView(localAa0010ActiveHelp).from(exports -> exports.outputAa0010ActiveHelp)
                    );

                escape60443030:
                if (localAa0010ActiveHelp.returnCode.compareTo(TextAttribute.of("0")) > 0) {
                    localAa0010ActiveHelp.decode.setValue(TextAttribute.of("XXXXXXXXXXXX"));
                }

                localTa0027ExceptionFields.errorDescription.setValue(localAa0010ActiveHelp.decode);
                localTa0027ExceptionFields.fileMode.setValue(TextAttribute.of("WR"));

                use(action(TaExceptionCab.class)
                        .whichImportsView(exports.outputAaRebuildFiles).to(imports -> imports.inputAaRebuildFiles)
                        .whichImportsView(localTa0027ExceptionFields).to(imports -> imports.inputTa0027ExceptionFields)
                        .whichExportsView(localTa0027ExceptionFields).from(exports -> exports.outputTa0027ExceptionFields)
                    );

                escape60443035:
                if (localTa0027ExceptionFields.returnCode.compareTo(TextAttribute.of("00")) > 0) {
                    setExitState(TaTechnicalArchitecture.TA900_A_ERROR_EXISTS);
                    return;
                }
            } while (!(localExceptionIefSupplied.count.equals(NumericAttribute.of(3))));


            exports.outputBadRecordMorningMailSummary.summaryDate.setValue(localPreviousMorningMailSummary.summaryDate);
            exports.outputBadRecordMorningMailSummary.officeCode.setValue(localPreviousMorningMailSummary.officeCode);
            exports.outputBadRecordMorningMailSummary.userIdentifier.setValue(localPreviousMorningMailSummary.userIdentifier);
            exports.outputBadRecordMorningMailSummary.activityCode.setValue(localPreviousMorningMailSummary.activityCode);
            exports.outputBadRecordMorningMailSummary.subsystemIdentifier.setValue(localPreviousMorningMailSummary.subsystemIdentifier);


            setExitState(TaTechnicalArchitecture.TA186_B_ERROR_EXISTS);
            return;
        }

        escape60443003:
        if (localTakeChkpntIefSupplied.flag.equals(TextAttribute.of("Y"))) {
            localAa0003ValidatedDates.date1.setValue(localPreviousMorningMailSummary.summaryDate);

            use(action(AaConvertDateToText.class)
                    .whichImportsView(localAa0003ValidatedDates).to(imports -> imports.inputAa0003ValidatedDates)
                    .whichExportsView(localAa0003ValidatedDates).from(exports -> exports.outputAa0003ValidatedDates)
                );

            escape60444724:
            if (localAa0003ValidatedDates.returnCode.compareTo(TextAttribute.of("0")) > 0) {
                setExitState(TaTechnicalArchitecture.TA900_A_ERROR_EXISTS);
                return;
            }

            exports.outputAaCkpointControl.cpDbRepoData.setValue(concat(concat(concat(concat(concat(concat(localAa0003ValidatedDates.textYearYyyy, localAa0003ValidatedDates.textMonth), localAa0003ValidatedDates.textDays), localPreviousMorningMailSummary.officeCode), localPreviousMorningMailSummary.userIdentifier), localPreviousMorningMailSummary.activityCode), localPreviousMorningMailSummary.subsystemIdentifier));


            exports.outputAaCkpointControl.cpRequestCode.setValue(TextAttribute.of("CP"));


            use(action(TaCheckpointTest.class)
                    .whichImportsView(exports.outputAaRebuildFiles).to(imports -> imports.importAaRebuildFiles)
                    .whichImportsView(exports.outputAaCkpointControl).to(imports -> imports.importAaCkpointControl)
                    .whichExportsView(exports.outputAaRebuildFiles).from(exports -> exports.exportAaRebuildFiles)
                    .whichExportsView(exports.outputAaCkpointControl).from(exports -> exports.exportAaCkpointControl)
                );


            escape60435466:
            if (getExitState().equals(TaTechnicalArchitecture.TA503_I_CHECKPOINT_SUCCESS)) {
                setExitState(TaTechnicalArchitecture.TA504_I_COMMIT_DB);
                exports.outputTa0022EojSummaryFields.firstTime.setValue(TextAttribute.of("N"));
                move(localRecordsDeletedIefSupplied).to(exports.outputRecordsDeletedIefSupplied);
                move(localRecordsReadIefSupplied).to(exports.outputRecordsReadIefSupplied);
                return;
            } else {
                setExitState(TaTechnicalArchitecture.TA900_A_ERROR_EXISTS);
                return;
            }
        }


        escape60435468:
        if (localRecordsReadIefSupplied.count.equals(NumericAttribute.of(0))) {
            exports.outputTa0022EojSummaryFields.noRecordsDoc.setValue(TextAttribute.of("Y"));
        }


        // ------------------
        // Final Checkpoint
        // ------------------
        exports.outputAaCkpointControl.cpRequestCode.setValue(TextAttribute.of("WP"));

        use(action(TaCheckpointTest.class)
                .whichImportsView(exports.outputAaRebuildFiles).to(imports -> imports.importAaRebuildFiles)
                .whichImportsView(exports.outputAaCkpointControl).to(imports -> imports.importAaCkpointControl)
                .whichExportsView(exports.outputAaRebuildFiles).from(exports -> exports.exportAaRebuildFiles)
                .whichExportsView(exports.outputAaCkpointControl).from(exports -> exports.exportAaCkpointControl)
            );

        escape60443041:
        if (! getExitState().equals(TaTechnicalArchitecture.TA503_I_CHECKPOINT_SUCCESS)) {
            setExitState(TaTechnicalArchitecture.TA900_A_ERROR_EXISTS);
            return;
        }

        // ---------------------------------------------
        // Update the Batch Parameter Table
        // ---------------------------------------------


        localUpdateBatchParameter.batchEffectiveDate.setValue(exports.outputBatchParameter.batchEffectiveDate.plus(days(NumericAttribute.of(1))));
        localAa0009NextPrevBusinessDay.enterDate.setValue(localUpdateBatchParameter.batchEffectiveDate);

        // ---------------------------------------------
        // Use aa_valid_business_day
        // ---------------------------------------------
        // ------------------------
        // Initialize return code.
        // ------------------------
        localAa0009NextPrevBusinessDay.returnCode.setValue(TextAttribute.of("0"));


        use(action(AaValidBusinessDay.class)
                .whichImportsView(localAa0009NextPrevBusinessDay).to(imports -> imports.inputAa0009NextPrevBusinessDay)
                .whichExportsView(localAa0009NextPrevBusinessDay).from(exports -> exports.outputAa0009NextPrevBusinessDay)
            );

        escape60443051:
        if (! localAa0009NextPrevBusinessDay.returnedDate.equals(localUpdateBatchParameter.batchEffectiveDate)) {
            local1Aa0009NextPrevBusinessDay.indicator.setValue(TextAttribute.of("N"));
            local1Aa0009NextPrevBusinessDay.enterDate.setValue(localAa0009NextPrevBusinessDay.enterDate);

            use(action(AaNextPrevBusinessDay.class)
                    .whichImportsView(local1Aa0009NextPrevBusinessDay).to(imports -> imports.inputAa0009NextPrevBusinessDay)
                    .whichExportsView(local1Aa0009NextPrevBusinessDay).from(exports -> exports.outputAa0009NextPrevBusinessDay)
                );

            localUpdateBatchParameter.batchEffectiveDate.setValue(local1Aa0009NextPrevBusinessDay.returnedDate);
        }


        escape60496530:
        try {
            read( actionBatchParameter ).allowMultiple().where(
                that(actionBatchParameter).attribute(actionBatchParameter.processIdentifier).isEqualTo(valueOf(getTransactionCode())) );
            move(actionBatchParameter).to(exports.outputBatchParameter);
            exports.outputBatchParameter.batchEffectiveDate.setValue(localUpdateBatchParameter.batchEffectiveDate);

            use(action(TaeUpdateBatchParameter.class)
                    .whichImportsView(exports.outputBatchParameter).to(imports -> imports.inputBatchParameter)
                );

            escape60443042:
            if (! getExitState().equals(AaAdsCommonObjects.AA541_I_SUCCESSFUL_UPDATE)) {
                setExitState(TaTechnicalArchitecture.TA901_A_PARAMETER_ERROR);
                return;
            }
        } catch (NotFoundException e60496530) {
            setExitState(TaTechnicalArchitecture.TA903_A_BATCH_PARAMETER_NF);
            return;
        }

        // *
        // *  WRITE DETAIL LINES OF THE EOJ SUMMARY
        // *
        exports.outputTa0022EojSummaryFields.fileMode.setValue(TextAttribute.of("CL"));
        exports.outputTa0022EojSummaryFields.controlAreaType.setValue(TextAttribute.of("P"));
        exports.outputTa0022EojSummaryFields.filename.setValue(TextAttribute.of("MMSUMMRY"));
        exports.outputTa0022EojSummaryFields.controlType.setValue(TextAttribute.of("RECORDS READ"));
        exports.outputTa0022EojSummaryFields.format.setValue(TextAttribute.of("I"));
        exports.outputTa0022EojSummaryFields.actualValue.setValueRounded(localRecordsReadIefSupplied.count);
        exports.outputTa0022EojSummaryFields.difference.setValue(TextAttribute.of("N"));

        use(action(TaEojSummaryCab.class)
                .whichImportsView(exports.outputAaRebuildFiles).to(imports -> imports.inputAaRebuildFiles)
                .whichImportsView(exports.outputTa0022EojSummaryFields).to(imports -> imports.inputTa0022EojSummaryFields)
                .whichExportsView(exports.outputAaRebuildFiles).from(exports -> exports.outputAaRebuildFiles)
                .whichExportsView(exports.outputTa0022EojSummaryFields).from(exports -> exports.outputTa0022EojSummaryFields)
            );

        escape60443034:
        if (exports.outputTa0022EojSummaryFields.returnCode.compareTo(NumericAttribute.of(0)) > 0) {
            setExitState(TaTechnicalArchitecture.TA900_A_ERROR_EXISTS);
            return;
        }

        // ---------------------------------------------
        // Changed control area type from "O" to "P".
        // ---------------------------------------------
        exports.outputTa0022EojSummaryFields.controlAreaType.setValue(TextAttribute.of("P"));
        exports.outputTa0022EojSummaryFields.filename.setValue(TextAttribute.of("MMSUMMRY"));
        exports.outputTa0022EojSummaryFields.controlType.setValue(TextAttribute.of("RECORDS DELETED"));
        exports.outputTa0022EojSummaryFields.actualValue.setValueRounded(localRecordsDeletedIefSupplied.count);

        use(action(TaEojSummaryCab.class)
                .whichImportsView(exports.outputAaRebuildFiles).to(imports -> imports.inputAaRebuildFiles)
                .whichImportsView(exports.outputTa0022EojSummaryFields).to(imports -> imports.inputTa0022EojSummaryFields)
                .whichExportsView(exports.outputAaRebuildFiles).from(exports -> exports.outputAaRebuildFiles)
                .whichExportsView(exports.outputTa0022EojSummaryFields).from(exports -> exports.outputTa0022EojSummaryFields)
            );


        escape60443033:
        if (exports.outputTa0022EojSummaryFields.returnCode.compareTo(NumericAttribute.of(0)) > 0) {
            setExitState(TaTechnicalArchitecture.TA900_A_ERROR_EXISTS);
            return;
        }

        exports.outputTa0022EojSummaryFields.controlAreaType.setValue(TextAttribute.of("W"));

        use(action(TaEojSummaryCab.class)
                .whichImportsView(exports.outputAaRebuildFiles).to(imports -> imports.inputAaRebuildFiles)
                .whichImportsView(exports.outputTa0022EojSummaryFields).to(imports -> imports.inputTa0022EojSummaryFields)
                .whichExportsView(exports.outputAaRebuildFiles).from(exports -> exports.outputAaRebuildFiles)
                .whichExportsView(exports.outputTa0022EojSummaryFields).from(exports -> exports.outputTa0022EojSummaryFields)
            );


        escape60443032:
        if (exports.outputTa0022EojSummaryFields.returnCode.compareTo(NumericAttribute.of(0)) > 0) {
            setExitState(TaTechnicalArchitecture.TA900_A_ERROR_EXISTS);
            return;
        }


        // ---------------------------------------------
        // THIS IS THE WRAP-UP SECTION OF THE MODULE.
        // ---------------------------------------------
        // ------------
        // NM SIR #924
        // ------------
        escape60444435:
        if (exports.outputErrorsIefSupplied.count.equals(NumericAttribute.of(0))) {
            localTa0027ExceptionFields.errorDescription.setValue(TextAttribute.of("NO ERRORS REPORTED"));
        }
        localTa0027ExceptionFields.fileMode.setValue(TextAttribute.of("CL"));

        use(action(TaExceptionCab.class)
                .whichImportsView(localTa0027ExceptionFields).to(imports -> imports.inputTa0027ExceptionFields)
                .whichExportsView(localTa0027ExceptionFields).from(exports -> exports.outputTa0027ExceptionFields)
            );


        escape60443031:
        if (localTa0027ExceptionFields.returnCode.compareTo(TextAttribute.of("00")) > 0) {
            setExitState(TaTechnicalArchitecture.TA900_A_ERROR_EXISTS);
            return;
        } else {
            setExitState(TaTechnicalArchitecture.TA140_N_END_OF_FILE);
        }
    }


    protected void setImports(Imports imports) {
        this.imports = imports;
    }

    @Override
    public Imports getImports() {
        return imports;
    }

    @Override
    public Exports getExports() {
        return exports;
    }

    @Override
    protected void resetExports() {
        this.exports = new Exports();
    }

    @Override
    protected String getTranCode() {
        return "HSCM003A";
    }

}